/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  ArrowRight, 
  ChevronRight, 
  Settings, 
} from "lucide-react";

// Components
const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <motion.nav
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? "bg-white/90 backdrop-blur-md py-4 shadow-sm" : "bg-transparent py-8"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-16 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center gap-3 cursor-pointer group">
          <div className="w-10 h-10 bg-pkg-red flex items-center justify-center p-2 relative overflow-hidden">
            <div className="w-full h-full border-2 border-white transform rotate-45 group-hover:rotate-0 transition-transform duration-500" />
            <span className="absolute inset-0 flex items-center justify-center text-white font-bold text-[8px] uppercase tracking-tighter">PKG</span>
          </div>
          <span className="font-display text-xl font-extrabold tracking-tighter text-graphite">
            PKG BATTERY
          </span>
        </div>

        {/* Links */}
        <div className="hidden md:flex items-center gap-10">
          {[
            { label: "Trang chủ", active: true },
            { label: "Giải pháp" },
            { label: "Năng lực" },
            { label: "Dự án" },
            { label: "Tin tức" }
          ].map((item) => (
            <a
              key={item.label}
              href="#"
              className={`text-[11px] font-bold uppercase tracking-[0.2em] transition-colors duration-300 ${
                item.active ? "text-pkg-red border-b border-pkg-red pb-1" : "text-graphite/60 hover:text-pkg-red"
              }`}
            >
              {item.label}
            </a>
          ))}
        </div>

        {/* Action */}
        <div className="flex items-center gap-6">
          <button className="hidden sm:block px-6 py-3 bg-graphite text-white text-[11px] font-bold uppercase tracking-widest hover:bg-pkg-red transition-all duration-300">
            Liên hệ hợp tác
          </button>
          <button className="md:hidden p-2 text-graphite group">
            <div className="w-6 h-0.5 bg-graphite mb-1 group-hover:bg-pkg-red transition-colors" />
            <div className="w-4 h-0.5 bg-graphite mb-1 group-hover:bg-pkg-red transition-colors" />
            <div className="w-6 h-0.5 bg-graphite group-hover:bg-pkg-red transition-colors" />
          </button>
        </div>
      </div>
    </motion.nav>
  );
};

const TrustSignalsFooter = () => {
  const signals = [
    { label: "IEC 62619 Standard", badge: "IEC" },
    { label: "UN38.3 Certified", badge: "!", color: "text-pkg-red" },
    { label: "ISO Quality Guaranteed", badge: "ISO" },
  ];

  return (
    <footer className="w-full px-6 lg:px-16 py-10 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center bg-white/40 backdrop-blur-sm z-20">
      <div className="flex flex-wrap gap-6 lg:gap-12 items-center justify-center">
        {signals.map((s) => (
          <div key={s.label} className="flex items-center gap-2">
            <div className={`w-5 h-5 border border-graphite/30 rounded-full flex items-center justify-center text-[8px] font-extrabold ${s.color || ""}`}>
              {s.badge}
            </div>
            <span className="text-[10px] font-bold text-graphite/60 tracking-wider uppercase">
              {s.label}
            </span>
          </div>
        ))}
      </div>
      
      <div className="hidden lg:flex items-center gap-4 text-graphite/40">
        <span className="text-[10px] font-bold uppercase tracking-widest italic">Innovation in Energy Storage</span>
        <div className="h-4 w-[1px] bg-gray-300" />
        <div className="flex gap-1">
          <div className="w-1 h-1 bg-pkg-red"></div>
          <div className="w-1 h-1 bg-pkg-red opacity-60"></div>
          <div className="w-1 h-1 bg-pkg-red opacity-30"></div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="min-h-screen selection:bg-pkg-red/10 selection:text-pkg-red font-sans text-graphite relative flex flex-col">
      {/* Background Subtle Grid & Depth */}
      <div className="fixed inset-0 bg-grid opacity-30 pointer-events-none" />
      <div className="fixed inset-0 industrial-gradient pointer-events-none" />
      
      <Navbar />

      <main className="relative flex-grow flex items-center pt-32 pb-20 px-6 lg:px-16 max-w-7xl mx-auto z-10 w-full">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 items-center w-full">
          
          {/* Content Area - Left */}
          <div className="col-span-12 lg:col-span-7 flex flex-col pt-10">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="flex items-center gap-3 mb-6"
            >
              <div className="h-[1px] w-8 bg-pkg-red" />
              <span className="text-[10px] font-bold tracking-[0.3em] uppercase text-pkg-red">
                PKG BATTERY
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="font-display text-[32px] sm:text-[42px] lg:text-[54px] xl:text-[62px] leading-[1.1] font-extrabold text-[#111111] mb-8 tracking-tight uppercase"
            >
              ĐỒNG HÀNH CÙNG TƯƠNG LAI <br/>
              <span className="text-graphite/40">NĂNG LƯỢNG CÔNG NGHIỆP</span> <br/>
              VIỆT NAM
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="text-base lg:text-lg text-graphite/80 leading-relaxed max-w-[620px] mb-6 font-medium"
            >
              PKG Battery phát triển năng lực nghiên cứu, sản xuất và triển khai các giải pháp năng lượng Lithium phục vụ doanh nghiệp trong công nghiệp, logistics và hạ tầng vận hành hiện đại.
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="text-sm text-graphite/50 leading-relaxed max-w-[540px] mb-12"
            >
              Chúng tôi xây dựng giá trị từ công nghệ, đội ngũ kỹ thuật và cam kết đồng hành dài hạn, nhằm giúp doanh nghiệp nâng cao hiệu suất vận hành, tăng độ an toàn và sẵn sàng cho giai đoạn tăng trưởng mới.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7, duration: 0.8 }}
              className="flex flex-wrap items-center gap-6"
            >
              <button className="group bg-pkg-red text-white px-10 py-5 font-bold text-[11px] uppercase tracking-[0.2em] flex items-center gap-3 hover:bg-[#b5191f] transition-all duration-300">
                Khám phá doanh nghiệp
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </button>
              <button className="border-2 border-graphite/10 text-graphite px-10 py-[18px] font-bold text-[11px] uppercase tracking-[0.2em] hover:border-graphite/40 transition-all duration-300">
                Xem năng lực triển khai
              </button>
            </motion.div>
          </div>

          {/* Visual Area - Right */}
          <div className="hidden lg:col-span-5 lg:flex h-full relative items-center justify-end">
            <div className="w-full aspect-square relative">
              {/* Main Technical Container */}
              <motion.div
                initial={{ opacity: 0, rotate: 5, scale: 0.9 }}
                animate={{ opacity: 1, rotate: 0, scale: 1 }}
                transition={{ delay: 0.6, duration: 1.2, ease: "circOut" }}
                className="absolute inset-0 bg-[#EAEAEA] rounded-sm shadow-2xl overflow-hidden border border-white z-0"
              >
                <img 
                  src="https://picsum.photos/seed/expert-team/1000/1000" 
                  alt="Professional R&D Team" 
                  className="w-full h-full object-cover grayscale opacity-40 mix-blend-multiply"
                  referrerPolicy="no-referrer"
                />
                
                {/* Schematic Overlays */}
                <div className="absolute bottom-8 left-8 text-white/70 font-mono text-[9px] leading-tight uppercase bg-graphite/30 p-2 backdrop-blur-sm">
                  OPERATION_READY: 24/7<br/>
                  TEAM_CAPACITY: HIGH-END<br/>
                  R&D_STATUS: ACTIVE
                </div>

                {/* Decorative Layers inside */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-48 h-64 border border-white/20 bg-white/5 backdrop-blur-sm rotate-6" />
                  <div className="absolute w-64 h-40 bg-pkg-red/5 blur-3xl" />
                </div>
              </motion.div>

              {/* Product Card - Shifted Front */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1, duration: 1 }}
                className="absolute -left-6 xl:-left-12 bottom-12 w-64 xl:w-72 bg-white shadow-[-20px_20px_40px_rgba(0,0,0,0.08)] border border-gray-100 flex flex-col p-6 xl:p-8 z-10"
              >
                <div className="w-full h-2 bg-pkg-red mb-6" />
                <div className="flex-grow border-2 border-dashed border-gray-100 p-6 flex flex-col items-center justify-center">
                  <div className="text-center">
                    <div className="text-[10px] font-extrabold text-gray-300 uppercase mb-2 tracking-widest leading-none">Industrial Pack</div>
                    <div className="text-3xl font-extrabold text-graphite tracking-tighter mb-4">Li-PRO X</div>
                  </div>
                  <div className="flex items-center gap-4 mt-2">
                    <div className="p-2 bg-gray-50 rounded-sm">
                      <Settings className="text-pkg-red" size={16} />
                    </div>
                    <div className="text-[9px] font-bold text-gray-400 uppercase tracking-widest text-left">
                      High-Efficiency<br/>Control Logic
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Floating Accents */}
              <div className="absolute -top-6 -right-6 w-32 h-32 border-t-2 border-r-2 border-pkg-red/20" />
            </div>
          </div>
        </div>
      </main>

      <TrustSignalsFooter />
    </div>
  );
}
