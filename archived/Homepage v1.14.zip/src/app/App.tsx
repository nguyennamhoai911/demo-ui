import { Header } from "./components/pkg/Header";
import { Hero } from "./components/pkg/Hero";
import { TrustStrip } from "./components/pkg/TrustStrip";
import { PainPoints } from "./components/pkg/PainPoints";
import { About } from "./components/pkg/About";
import { Solutions } from "./components/pkg/Solutions";
import { Products } from "./components/pkg/Products";
import { OEM } from "./components/pkg/OEM";
import { Industries } from "./components/pkg/Industries";
import { WhyChoose } from "./components/pkg/WhyChoose";
import { TrustSignals } from "./components/pkg/TrustSignals";
import { Process } from "./components/pkg/Process";
import { DealerMap } from "./components/pkg/DealerMap";
import { News } from "./components/pkg/News";
import { CaseStudies } from "./components/pkg/CaseStudies";
import { ContactCTA } from "./components/pkg/ContactCTA";
import { Footer } from "./components/pkg/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white text-black antialiased">
      <Header />
      <main>
        <Hero />
        <TrustStrip />
        <PainPoints />
        <About />
        <Solutions />
        <Products />
        <OEM />
        <Industries />
        <WhyChoose />
        <TrustSignals />
        <Process />
        <DealerMap />
        <News />
        <CaseStudies />
        <ContactCTA />
      </main>
      <Footer />
    </div>
  );
}
