const COLS = [
  { t: "SẢN PHẨM", l: ["Pin Xe Nâng", "Pin Xe Điện Du Lịch", "Pin AGV / Robot", "Bộ Sạc – Trạm Sạc", "Hệ thống ESS"] },
  { t: "GIẢI PHÁP", l: ["Logistics & Kho vận", "Nhà máy & Sản xuất", "Automation", "Resort Mobility", "Energy Storage"] },
  { t: "CÔNG TY", l: ["Về PKG Battery", "OEM / ODM", "Đại lý", "Tin tức", "Liên hệ"] },
];

export function Footer() {
  return (
    <footer className="bg-black text-white pt-20 pb-8 border-t border-white/10">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-10 pb-16 border-b border-white/10">
          <div className="lg:col-span-4">
            <div className="flex items-center gap-3 mb-6">
              <div className="relative w-10 h-10 grid place-items-center">
                <div className="absolute inset-0 bg-[#E11D2E] rotate-45" />
                <span className="relative text-white" style={{ fontSize: 18, fontWeight: 700 }}>P</span>
              </div>
              <div>
                <div style={{ fontSize: 16, fontWeight: 600 }}>PKG BATTERY</div>
                <div className="text-white/50" style={{ fontSize: 10, letterSpacing: "0.25em" }}>INDUSTRIAL LITHIUM</div>
              </div>
            </div>
            <p className="text-white/55 max-w-sm" style={{ fontSize: 13, lineHeight: 1.7 }}>
              PKG Battery — đối tác pin lithium công nghiệp, bộ sạc và giải pháp kỹ thuật cho
              doanh nghiệp Việt Nam, FDI và đối tác quốc tế.
            </p>
          </div>
          {COLS.map((c) => (
            <div key={c.t} className="lg:col-span-2 space-y-3">
              <div className="text-white/50 mb-4" style={{ fontSize: 10, letterSpacing: "0.22em" }}>{c.t}</div>
              {c.l.map((x) => (
                <a key={x} href="#" className="block text-white/80 hover:text-[#E11D2E]" style={{ fontSize: 13 }}>{x}</a>
              ))}
            </div>
          ))}
          <div className="lg:col-span-2 space-y-3">
            <div className="text-white/50 mb-4" style={{ fontSize: 10, letterSpacing: "0.22em" }}>LIÊN HỆ</div>
            <div className="text-white/80" style={{ fontSize: 13, lineHeight: 1.7 }}>
              contact@pkgbattery.vn<br />1900 0000<br />HN • ĐN • HCM
            </div>
          </div>
        </div>
        <div className="pt-8 flex flex-wrap gap-4 items-center justify-between text-white/40" style={{ fontSize: 11, letterSpacing: "0.12em" }}>
          <div>© 2026 PKG BATTERY. ALL RIGHTS RESERVED.</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">PRIVACY</a>
            <a href="#" className="hover:text-white">TERMS</a>
            <a href="#" className="hover:text-white">COOKIES</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
