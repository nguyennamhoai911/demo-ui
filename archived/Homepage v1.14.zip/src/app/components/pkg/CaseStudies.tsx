import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const CASES = [
  {
    tag: "LOGISTICS",
    title: "Nâng cấp đội xe nâng điện cho trung tâm phân phối",
    result: "Giảm 40% downtime",
    img: "https://images.unsplash.com/photo-1645736315000-6f788915923b?w=1400&q=80",
  },
  {
    tag: "MANUFACTURING",
    title: "Triển khai AGV với giải pháp pin tùy chỉnh",
    result: "Tăng 30% throughput",
    img: "https://images.unsplash.com/photo-1720036237038-802f50cdfd9c?w=1400&q=80",
  },
  {
    tag: "ENERGY",
    title: "Hệ thống ESS cho nhà máy sản xuất 5MWh",
    result: "Tối ưu 25% chi phí điện",
    img: "https://images.unsplash.com/photo-1775519520494-d12d91797a01?w=1400&q=80",
  },
];

export function CaseStudies() {
  return (
    <section className="bg-white py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="mb-14 max-w-3xl">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>APPLICATION PROOF</span>
          </div>
          <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
            Giải pháp được xây dựng<br />cho bối cảnh vận hành thực tế.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {CASES.map((c, i) => (
            <motion.a
              key={c.title}
              href="#"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative block bg-black overflow-hidden"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <ImageWithFallback src={c.img} alt={c.title} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
              <div className="absolute inset-0 p-6 flex flex-col justify-between text-white">
                <div className="flex items-center gap-2 text-white/70" style={{ fontSize: 10, letterSpacing: "0.22em" }}>
                  <span className="w-1.5 h-1.5 bg-[#E11D2E] rotate-45" /> {c.tag}
                </div>
                <div>
                  <div style={{ fontSize: 22, lineHeight: 1.2, fontWeight: 500 }}>{c.title}</div>
                  <div className="mt-3 inline-block bg-[#E11D2E] px-3 py-1" style={{ fontSize: 11, letterSpacing: "0.15em" }}>
                    {c.result.toUpperCase()}
                  </div>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
