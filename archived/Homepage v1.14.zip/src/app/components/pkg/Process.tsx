import { motion } from "motion/react";

const STEPS = [
  { t: "Tiếp nhận nhu cầu", d: "Đánh giá ứng dụng và yêu cầu kỹ thuật ban đầu." },
  { t: "Phân tích vận hành", d: "Đề xuất cấu hình phù hợp với bài toán thực tế." },
  { t: "Thiết kế giải pháp", d: "Cấu hình pin, sạc và phương án tích hợp." },
  { t: "Triển khai", d: "Lắp đặt, nghiệm thu và hướng dẫn vận hành." },
  { t: "Đồng hành hậu mãi", d: "Hỗ trợ kỹ thuật và tối ưu dài hạn." },
];

export function Process() {
  return (
    <section className="bg-[#F4F4F4] py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>QUY TRÌNH</span>
          </div>
          <h2 className="max-w-3xl" style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
            Tư vấn rõ ràng, triển khai có kiểm soát.
          </h2>
        </div>

        <div className="relative grid grid-cols-1 md:grid-cols-5 gap-0">
          {STEPS.map((s, i) => (
            <motion.div
              key={s.t}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className={`relative p-7 bg-white ${i !== 0 ? "md:border-l border-black/10" : ""} hover:bg-black hover:text-white transition-colors group`}
            >
              <div className="text-[#E11D2E]" style={{ fontSize: 44, fontWeight: 500, letterSpacing: "-0.03em", lineHeight: 1 }}>
                0{i + 1}
              </div>
              <div className="mt-10 min-h-[3.5rem]" style={{ fontSize: 18, lineHeight: 1.2, fontWeight: 500 }}>
                {s.t}
              </div>
              <div className="mt-3 text-black/60 group-hover:text-white/60" style={{ fontSize: 13, lineHeight: 1.55 }}>
                {s.d}
              </div>
              {i < STEPS.length - 1 && (
                <div className="hidden md:block absolute top-12 -right-2 text-black/20 group-hover:text-white/30">→</div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
