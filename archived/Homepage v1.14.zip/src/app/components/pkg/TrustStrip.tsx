import { motion } from "motion/react";

const INDUSTRIES = [
  "LOGISTICS",
  "MANUFACTURING",
  "WAREHOUSE",
  "AUTOMATION",
  "RESORT MOBILITY",
  "ENERGY STORAGE",
  "FDI ENTERPRISE",
  "OEM / ODM",
];

export function TrustStrip() {
  return (
    <section className="bg-white border-y border-black/10 py-10">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="flex items-center gap-4 mb-6">
          <span className="w-8 h-px bg-black" />
          <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>
            ĐỒNG HÀNH CÙNG DOANH NGHIỆP TRONG NHIỀU LĨNH VỰC
          </span>
        </div>
        <div className="overflow-hidden">
          <motion.div
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            className="flex gap-16 whitespace-nowrap"
          >
            {[...INDUSTRIES, ...INDUSTRIES].map((x, i) => (
              <div key={i} className="flex items-center gap-4">
                <span className="w-1.5 h-1.5 bg-[#E11D2E] rotate-45" />
                <span className="text-black/70" style={{ fontSize: 22, letterSpacing: "0.04em", fontWeight: 500 }}>
                  {x}
                </span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
