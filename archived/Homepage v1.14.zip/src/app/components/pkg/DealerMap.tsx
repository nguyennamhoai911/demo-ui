import { motion } from "motion/react";
import { useState } from "react";
import { MapPin, Phone } from "lucide-react";

const DEALERS = [
  { id: 1, name: "PKG Hà Nội", city: "Hà Nội", x: 52, y: 18, phone: "024 0000 0000" },
  { id: 2, name: "PKG Hải Phòng", city: "Hải Phòng", x: 60, y: 22, phone: "0225 000 000" },
  { id: 3, name: "PKG Đà Nẵng", city: "Đà Nẵng", x: 64, y: 46, phone: "0236 000 000" },
  { id: 4, name: "PKG Nha Trang", city: "Khánh Hòa", x: 70, y: 62, phone: "0258 000 000" },
  { id: 5, name: "PKG Bình Dương", city: "Bình Dương", x: 54, y: 78, phone: "0274 000 000" },
  { id: 6, name: "PKG TP.HCM", city: "TP. Hồ Chí Minh", x: 56, y: 82, phone: "028 0000 0000" },
  { id: 7, name: "PKG Long An", city: "Long An", x: 50, y: 85, phone: "0272 000 000" },
  { id: 8, name: "PKG Cần Thơ", city: "Cần Thơ", x: 46, y: 90, phone: "0292 000 000" },
];

export function DealerMap() {
  const [active, setActive] = useState(DEALERS[5]);

  return (
    <section className="bg-white py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="mb-14 max-w-3xl">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>MẠNG LƯỚI PHÂN PHỐI</span>
          </div>
          <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
            Mạng lưới đại lý và<br />phân phối toàn Việt Nam.
          </h2>
        </div>

        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7 relative aspect-[3/4] bg-[#0A0A0B] overflow-hidden">
            {/* grid */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage:
                  "linear-gradient(rgba(255,255,255,.3) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.3) 1px,transparent 1px)",
                backgroundSize: "32px 32px",
              }}
            />
            {/* Stylized Vietnam silhouette */}
            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              <path
                d="M50 5 L58 10 L62 15 L60 22 L65 28 L62 34 L68 42 L66 50 L72 58 L68 66 L72 72 L68 78 L60 82 L58 88 L50 92 L44 90 L42 85 L46 80 L42 74 L38 68 L40 60 L44 52 L40 44 L46 36 L48 28 L46 20 L48 12 Z"
                fill="rgba(225,29,46,0.08)"
                stroke="rgba(225,29,46,0.4)"
                strokeWidth="0.2"
              />
            </svg>

            {DEALERS.map((d) => (
              <button
                key={d.id}
                onClick={() => setActive(d)}
                className="absolute -translate-x-1/2 -translate-y-1/2 group"
                style={{ left: `${d.x}%`, top: `${d.y}%` }}
              >
                <span
                  className={`absolute inset-0 -m-3 rounded-full ${
                    active.id === d.id ? "bg-[#E11D2E]/30" : "bg-white/10"
                  } animate-pulse`}
                />
                <span
                  className={`relative block w-3 h-3 rounded-full ${
                    active.id === d.id ? "bg-[#E11D2E]" : "bg-white"
                  } ring-2 ring-black transition-all group-hover:scale-125`}
                />
                <span
                  className={`absolute left-5 top-1/2 -translate-y-1/2 whitespace-nowrap text-white transition-opacity ${
                    active.id === d.id ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                  }`}
                  style={{ fontSize: 10, letterSpacing: "0.15em" }}
                >
                  {d.city.toUpperCase()}
                </span>
              </button>
            ))}

            <div className="absolute bottom-4 left-4 text-white/40" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
              VIETNAM • 8 ACTIVE DEALERS
            </div>
          </div>

          <div className="lg:col-span-5 flex flex-col">
            <motion.div
              key={active.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#F4F4F4] p-8 mb-4"
            >
              <div className="text-[#E11D2E]" style={{ fontSize: 11, letterSpacing: "0.22em" }}>ACTIVE DEALER</div>
              <div className="mt-3" style={{ fontSize: 28, fontWeight: 500, letterSpacing: "-0.01em" }}>
                {active.name}
              </div>
              <div className="mt-4 flex items-center gap-2 text-black/70"><MapPin className="w-4 h-4" /><span style={{ fontSize: 14 }}>{active.city}</span></div>
              <div className="mt-2 flex items-center gap-2 text-black/70"><Phone className="w-4 h-4" /><span style={{ fontSize: 14 }}>{active.phone}</span></div>
              <a href="#" className="inline-block mt-6 border-b border-black pb-1" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
                XEM CHI TIẾT ĐẠI LÝ →
              </a>
            </motion.div>
            <div className="border-t border-black/10">
              {DEALERS.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setActive(d)}
                  className={`w-full flex items-center justify-between py-3 border-b border-black/10 hover:bg-black/5 px-2 transition-colors ${
                    active.id === d.id ? "text-[#E11D2E]" : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-black/40" style={{ fontSize: 11 }}>0{d.id}</span>
                    <span style={{ fontSize: 14, fontWeight: 500 }}>{d.name}</span>
                  </div>
                  <span className="text-black/40" style={{ fontSize: 12 }}>{d.city}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
