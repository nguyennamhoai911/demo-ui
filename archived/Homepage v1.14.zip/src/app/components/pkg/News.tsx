import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const ARTICLES = [
  {
    tag: "KIẾN THỨC",
    date: "12.04.2026",
    title: "Vì sao pin lithium thay đổi bài toán vận hành xe nâng điện",
    img: "https://images.unsplash.com/photo-1714627798569-b3e36d409c4b?w=1600&q=80",
    feat: true,
  },
  {
    tag: "KỸ THUẬT",
    date: "08.04.2026",
    title: "BMS và an toàn pin lithium cho môi trường công nghiệp",
    img: "https://images.unsplash.com/photo-1775519520461-6b6e068d9250?w=800&q=80",
  },
  {
    tag: "ỨNG DỤNG",
    date: "02.04.2026",
    title: "ESS cho doanh nghiệp sản xuất: từ thiết kế đến vận hành",
    img: "https://images.unsplash.com/photo-1775519520494-d12d91797a01?w=800&q=80",
  },
  {
    tag: "TIN TỨC",
    date: "25.03.2026",
    title: "PKG Battery mở rộng mạng lưới đại lý phía Nam",
    img: "https://images.unsplash.com/photo-1668204866018-85586ed7bd89?w=800&q=80",
  },
];

export function News() {
  const [feat, ...rest] = ARTICLES;
  return (
    <section className="bg-[#F4F4F4] py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="flex items-end justify-between flex-wrap gap-6 mb-14">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-[#E11D2E]" />
              <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>TIN TỨC & KIẾN THỨC</span>
            </div>
            <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
              Tin tức, kiến thức kỹ thuật<br />và cập nhật từ PKG Battery.
            </h2>
          </div>
          <a href="#" className="inline-flex items-center gap-2 border-b border-black pb-1" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
            XEM TẤT CẢ BÀI VIẾT <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid lg:grid-cols-12 gap-6">
          <motion.a
            href="#"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-7 group block"
          >
            <div className="aspect-[16/11] overflow-hidden">
              <ImageWithFallback src={feat.img} alt={feat.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
            </div>
            <div className="mt-6 flex items-center gap-4 text-black/50" style={{ fontSize: 11, letterSpacing: "0.2em" }}>
              <span className="text-[#E11D2E]">{feat.tag}</span>
              <span>•</span>
              <span>{feat.date}</span>
            </div>
            <h3 className="mt-4 max-w-2xl" style={{ fontSize: "clamp(24px,2.6vw,36px)", lineHeight: 1.2, letterSpacing: "-0.01em", fontWeight: 500 }}>
              {feat.title}
            </h3>
            <div className="mt-5 inline-flex items-center gap-2 border-b border-black pb-1 group-hover:text-[#E11D2E] group-hover:border-[#E11D2E]" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
              ĐỌC THÊM →
            </div>
          </motion.a>

          <div className="lg:col-span-5 flex flex-col gap-5">
            {rest.map((a, i) => (
              <motion.a
                key={a.title}
                href="#"
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="group flex gap-5 bg-white p-5 hover:bg-black hover:text-white transition-colors"
              >
                <div className="w-32 h-32 shrink-0 overflow-hidden">
                  <ImageWithFallback src={a.img} alt={a.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-3 text-black/50 group-hover:text-white/50" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
                      <span className="text-[#E11D2E]">{a.tag}</span>
                      <span>{a.date}</span>
                    </div>
                    <div className="mt-2" style={{ fontSize: 16, lineHeight: 1.3, fontWeight: 500 }}>
                      {a.title}
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 mt-2" />
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
