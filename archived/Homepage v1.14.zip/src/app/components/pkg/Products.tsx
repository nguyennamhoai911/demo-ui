import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

type P = {
  num: string;
  tag: string;
  title: string;
  desc: string;
  apps: string;
  img: string;
  large?: boolean;
  dark?: boolean;
};

const PRODUCTS: P[] = [
  {
    num: "01",
    tag: "XE NÂNG ĐIỆN",
    title: "Pin Lithium cho Xe Nâng Điện",
    desc: "Giải pháp pin lithium tối ưu cho xe nâng điện với khả năng sạc nhanh, giảm bảo trì và hỗ trợ cường độ vận hành cao.",
    apps: "Kho vận • Logistics • Nhà máy",
    img: "https://images.unsplash.com/photo-1714627798569-b3e36d409c4b?w=1400&q=80",
    large: true,
  },
  {
    num: "02",
    tag: "XE ĐIỆN DU LỊCH",
    title: "Pin Lithium cho Xe Điện Du Lịch",
    desc: "Thiết kế cho xe điện du lịch, buggy và phương tiện chuyên dụng cần độ ổn định và tuổi thọ cao.",
    apps: "Resort • Khu du lịch • Mobility",
    img: "https://images.unsplash.com/photo-1664635032368-28eeb16de0d9?w=1200&q=80",
  },
  {
    num: "03",
    tag: "AGV / ROBOT",
    title: "Pin cho Xe AGV / Robot",
    desc: "Giải pháp năng lượng cho hệ thống tự động hóa cần độ ổn định, chính xác và khả năng tích hợp kỹ thuật cao.",
    apps: "Automation • Smart Factory",
    img: "https://images.unsplash.com/photo-1720036237038-802f50cdfd9c?w=1200&q=80",
    dark: true,
  },
  {
    num: "04",
    tag: "SẠC & TRẠM SẠC",
    title: "Bộ Sạc – Trạm Sạc",
    desc: "Giải pháp sạc đồng bộ giúp tối ưu hiệu suất pin, rút ngắn thời gian chờ và phù hợp nhiều môi trường vận hành.",
    apps: "Industrial Charging • Fleet",
    img: "https://images.unsplash.com/photo-1755555707440-188120a3c521?w=1200&q=80",
  },
  {
    num: "05",
    tag: "ESS",
    title: "Hệ thống Pin Lưu Trữ Năng Lượng",
    desc: "Giải pháp lưu trữ năng lượng cho doanh nghiệp cần tăng tính chủ động, ổn định nguồn điện và hiệu quả dài hạn.",
    apps: "Factory • Commercial • Energy",
    img: "https://images.unsplash.com/photo-1775519520494-d12d91797a01?w=1400&q=80",
    large: true,
    dark: true,
  },
];

export function Products() {
  return (
    <section className="bg-white py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="flex items-end justify-between flex-wrap gap-6 mb-14">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-[#E11D2E]" />
              <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>5 DÒNG SẢN PHẨM CHÍNH</span>
            </div>
            <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
              Giải pháp theo<br />5 nhóm sản phẩm chính.
            </h2>
          </div>
          <a
            href="#"
            className="inline-flex items-center gap-2 border-b border-black pb-1"
            style={{ fontSize: 12, letterSpacing: "0.15em" }}
          >
            XEM DANH MỤC SẢN PHẨM <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 auto-rows-[340px]">
          {PRODUCTS.map((p, i) => (
            <ProductCard key={p.num} p={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProductCard({ p, index }: { p: P; index: number }) {
  const span = p.large ? "md:col-span-4" : "md:col-span-2";
  return (
    <motion.a
      href="#"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.06 }}
      className={`relative overflow-hidden group ${span} ${p.dark ? "bg-black" : "bg-[#F4F4F4]"}`}
    >
      <div className="absolute inset-0 overflow-hidden">
        <ImageWithFallback
          src={p.img}
          alt={p.title}
          className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 ${
            p.dark ? "opacity-60" : "opacity-90"
          }`}
        />
        <div
          className={`absolute inset-0 ${
            p.dark
              ? "bg-gradient-to-t from-black via-black/40 to-transparent"
              : "bg-gradient-to-t from-white via-white/20 to-transparent"
          }`}
        />
      </div>

      <div className={`relative h-full p-7 flex flex-col justify-between ${p.dark ? "text-white" : "text-black"}`}>
        <div className="flex items-center justify-between">
          <div className={p.dark ? "text-white/60" : "text-black/50"} style={{ fontSize: 11, letterSpacing: "0.22em" }}>
            {p.num} / {p.tag}
          </div>
          <div
            className={`w-10 h-10 grid place-items-center border transition-all ${
              p.dark
                ? "border-white/30 group-hover:bg-[#E11D2E] group-hover:border-[#E11D2E]"
                : "border-black/20 group-hover:bg-black group-hover:text-white"
            }`}
          >
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>
        <div>
          <div style={{ fontSize: p.large ? 30 : 22, lineHeight: 1.15, letterSpacing: "-0.01em", fontWeight: 500 }}>
            {p.title}
          </div>
          <div className={`mt-3 max-w-md ${p.dark ? "text-white/70" : "text-black/65"}`} style={{ fontSize: 13, lineHeight: 1.55 }}>
            {p.desc}
          </div>
          <div className={`mt-4 flex items-center gap-2 ${p.dark ? "text-white/60" : "text-black/55"}`} style={{ fontSize: 11, letterSpacing: "0.15em" }}>
            <span className="w-1.5 h-1.5 bg-[#E11D2E] rotate-45" />
            {p.apps.toUpperCase()}
          </div>
        </div>
      </div>
    </motion.a>
  );
}
