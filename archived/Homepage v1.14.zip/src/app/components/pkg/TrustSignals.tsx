import { motion, useInView } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { Award, ShieldCheck, FileText, Maximize2 } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const STATS = [
  { n: 10, s: "+", l: "Năm kinh nghiệm" },
  { n: 200, s: "+", l: "Dự án triển khai" },
  { n: 8, s: "", l: "Đại lý toàn quốc" },
  { n: 15, s: "+", l: "Chứng chỉ & tiêu chuẩn" },
  { n: 7, s: "+", l: "Nhóm ứng dụng" },
];

const CERTS = [
  { name: "ISO 9001:2015", type: "Quality Management" },
  { name: "IEC 62133", type: "Battery Safety" },
  { name: "UN 38.3", type: "Transport Safety" },
  { name: "CE Compliance", type: "EU Standard" },
  { name: "Test Report", type: "Third-party" },
  { name: "RoHS", type: "Environment" },
];

function Counter({ n, s }: { n: number; s: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min((t - start) / 1400, 1);
      setV(Math.floor(n * (1 - Math.pow(1 - p, 3))));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, n]);
  return (
    <span ref={ref}>
      {v}
      {s}
    </span>
  );
}

export function TrustSignals() {
  return (
    <section className="bg-black text-white py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-10 mb-20 items-end">
          <div className="lg:col-span-8">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-[#E11D2E]" />
              <span className="text-[#E11D2E]" style={{ fontSize: 11, letterSpacing: "0.3em" }}>
                NĂNG LỰC & TRUST SIGNALS
              </span>
            </div>
            <h2 style={{ fontSize: "clamp(34px,4.5vw,64px)", lineHeight: 1.05, letterSpacing: "-0.025em", fontWeight: 500 }}>
              Năng lực kỹ thuật tạo nên<br />sự yên tâm khi hợp tác.
            </h2>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 border-y border-white/10">
          {STATS.map((st, i) => (
            <div key={st.l} className={`py-10 px-4 ${i !== 0 ? "md:border-l border-white/10" : ""}`}>
              <div className="text-white" style={{ fontSize: "clamp(44px,5vw,72px)", fontWeight: 500, letterSpacing: "-0.03em", lineHeight: 1 }}>
                <Counter n={st.n} s={st.s} />
              </div>
              <div className="text-white/50 mt-4" style={{ fontSize: 11, letterSpacing: "0.2em" }}>
                {st.l.toUpperCase()}
              </div>
            </div>
          ))}
        </div>

        {/* Certifications */}
        <div className="mt-24 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <Award className="w-8 h-8 text-[#E11D2E] mb-5" />
            <h3 className="text-white" style={{ fontSize: 28, lineHeight: 1.15, fontWeight: 500 }}>
              Chứng chỉ &<br />tiêu chuẩn quốc tế.
            </h3>
            <p className="mt-4 text-white/55" style={{ fontSize: 14, lineHeight: 1.65 }}>
              Hệ thống chứng chỉ an toàn, chất lượng và môi trường đáp ứng yêu cầu của khách hàng
              doanh nghiệp, FDI và đối tác quốc tế.
            </p>
            <a href="#" className="inline-flex mt-6 items-center gap-2 text-[#E11D2E] border-b border-[#E11D2E] pb-1" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
              XEM HỒ SƠ NĂNG LỰC
            </a>
          </div>
          <div className="lg:col-span-8 grid grid-cols-2 md:grid-cols-3 gap-4">
            {CERTS.map((c, i) => (
              <motion.div
                key={c.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -4 }}
                className="relative aspect-[3/4] bg-white group cursor-pointer overflow-hidden"
              >
                <div className="absolute inset-0 p-4 flex flex-col">
                  <div className="flex items-center justify-between">
                    <ShieldCheck className="w-5 h-5 text-[#E11D2E]" />
                    <FileText className="w-4 h-4 text-black/30" />
                  </div>
                  <div className="flex-1 grid place-items-center">
                    <div className="text-center px-4">
                      <div className="text-black" style={{ fontSize: 18, fontWeight: 500, letterSpacing: "-0.01em" }}>
                        {c.name}
                      </div>
                      <div className="mt-2 text-black/50" style={{ fontSize: 11, letterSpacing: "0.15em" }}>
                        {c.type.toUpperCase()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-black/40" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
                    <span>A4 / VERIFIED</span>
                    <Maximize2 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
                <div className="absolute inset-0 bg-[#E11D2E] translate-y-full group-hover:translate-y-0 transition-transform duration-500 grid place-items-center">
                  <span className="text-white" style={{ fontSize: 12, letterSpacing: "0.2em" }}>XEM CHI TIẾT</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Capability gallery */}
        <div className="mt-24">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-white" style={{ fontSize: 24, fontWeight: 500 }}>
              Nhà máy • Đội ngũ • Năng lực vận hành
            </h3>
            <span className="text-white/40" style={{ fontSize: 11, letterSpacing: "0.2em" }}>CAPABILITY GALLERY</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              "https://images.unsplash.com/photo-1720036236697-018370867320?w=800&q=80",
              "https://images.unsplash.com/photo-1720036236828-1c6a472db1c0?w=800&q=80",
              "https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=800&q=80",
              "https://images.unsplash.com/photo-1775519520461-6b6e068d9250?w=800&q=80",
              "https://images.unsplash.com/photo-1740733448722-82e16d3468bb?w=800&q=80",
              "https://images.unsplash.com/photo-1684695749267-233af13276d0?w=800&q=80",
              "https://images.unsplash.com/photo-1720036237038-802f50cdfd9c?w=800&q=80",
              "https://images.unsplash.com/photo-1732030373864-d37573915751?w=800&q=80",
            ].map((u, i) => (
              <div key={i} className="relative aspect-[4/5] overflow-hidden">
                <ImageWithFallback src={u} alt="" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700 hover:scale-105" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
