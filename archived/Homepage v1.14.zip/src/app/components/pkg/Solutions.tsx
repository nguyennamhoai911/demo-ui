import { motion } from "motion/react";
import { ClipboardCheck, Sliders, Puzzle, Workflow, Headset } from "lucide-react";

const STEPS = [
  { icon: ClipboardCheck, n: "01", t: "Đánh giá nhu cầu vận hành", d: "Khảo sát cường độ, môi trường, chu kỳ vận hành và KPI thực tế." },
  { icon: Sliders, n: "02", t: "Cấu hình pin & bộ sạc phù hợp", d: "Lựa chọn điện áp, dung lượng, hoá học và chuẩn sạc tối ưu." },
  { icon: Puzzle, n: "03", t: "Tùy chỉnh theo ứng dụng", d: "Form-factor, BMS, giao thức tích hợp theo thiết bị đặc thù." },
  { icon: Workflow, n: "04", t: "Tích hợp triển khai thực tế", d: "Lắp đặt, hướng dẫn vận hành và nghiệm thu tại hiện trường." },
  { icon: Headset, n: "05", t: "Hỗ trợ kỹ thuật & hậu mãi", d: "Đồng hành dài hạn, theo dõi hiệu suất và tối ưu TCO." },
];

export function Solutions() {
  return (
    <section id="solutions" className="bg-[#F4F4F4] py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-10 items-end mb-16">
          <div className="lg:col-span-7">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-[#E11D2E]" />
              <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>GIẢI PHÁP TỔNG THỂ</span>
            </div>
            <h2 style={{ fontSize: "clamp(34px,4.5vw,64px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
              Từ pin đến giải pháp<br />vận hành <span className="text-[#E11D2E]">hoàn chỉnh.</span>
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-black/70" style={{ fontSize: 16, lineHeight: 1.65 }}>
              PKG Battery xây dựng giải pháp pin lithium công nghiệp theo bài toán thực tế của
              doanh nghiệp — từ khảo sát nhu cầu, cấu hình pin và sạc phù hợp, đến triển khai, hỗ
              trợ kỹ thuật và đồng hành vận hành.
            </p>
          </div>
        </div>

        <div className="relative">
          {/* Flow line */}
          <div className="hidden lg:block absolute top-14 left-0 right-0 h-px bg-black/15">
            <motion.div
              animate={{ x: ["-20%", "120%"] }}
              transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              className="absolute top-0 w-32 h-px bg-gradient-to-r from-transparent via-[#E11D2E] to-transparent"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 relative">
            {STEPS.map((s, i) => (
              <motion.div
                key={s.n}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="relative bg-white p-6 border border-black/5 hover:border-[#E11D2E] transition-colors group"
              >
                <div className="absolute -top-3 left-6 w-6 h-6 bg-[#E11D2E] rounded-full group-hover:scale-125 transition-transform" />
                <div className="text-black/40" style={{ fontSize: 11, letterSpacing: "0.2em" }}>{s.n}</div>
                <s.icon className="w-7 h-7 mt-6 text-black group-hover:text-[#E11D2E] transition-colors" />
                <div className="mt-5" style={{ fontSize: 16, fontWeight: 500, lineHeight: 1.3 }}>{s.t}</div>
                <div className="mt-3 text-black/60" style={{ fontSize: 13, lineHeight: 1.55 }}>{s.d}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
