import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Quote } from "lucide-react";

export function About() {
  return (
    <section className="bg-white py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-10 lg:gap-16 items-start">
        <div className="lg:col-span-5">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>VỀ PKG BATTERY</span>
          </div>
          <h2 style={{ fontSize: "clamp(32px,4vw,54px)", lineHeight: 1.08, letterSpacing: "-0.02em", fontWeight: 500 }}>
            Đối tác giải pháp<br />năng lượng lithium<br />
            <span className="text-black/40">công nghiệp hiện đại.</span>
          </h2>
          <p className="mt-8 text-black/70" style={{ fontSize: 16, lineHeight: 1.7 }}>
            PKG Battery được định vị như một doanh nghiệp B2B chuyên pin lithium công nghiệp, bộ
            sạc, trạm sạc và giải pháp kỹ thuật theo ứng dụng. Không chỉ cung cấp sản phẩm, PKG
            hướng tới việc đồng hành cùng doanh nghiệp trong lựa chọn cấu hình, tối ưu hiệu quả
            vận hành và triển khai thực tế trong nhiều môi trường công nghiệp.
          </p>

          <div className="mt-10 grid grid-cols-2 gap-px bg-black/10 border border-black/10">
            {[
              ["Định vị", "B2B Industrial"],
              ["Phục vụ", "VN • FDI • Global"],
              ["Năng lực", "Pin • Sạc • ESS"],
              ["Định hướng", "OEM / ODM"],
            ].map(([k, v]) => (
              <div key={k} className="bg-white p-5">
                <div className="text-black/50" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
                  {k.toUpperCase()}
                </div>
                <div className="mt-2" style={{ fontSize: 15, fontWeight: 500 }}>{v}</div>
              </div>
            ))}
          </div>

          <div className="mt-10 flex gap-4 items-start">
            <Quote className="w-8 h-8 text-[#E11D2E] shrink-0" />
            <div className="text-black/80 italic" style={{ fontSize: 18, lineHeight: 1.5 }}>
              "Chúng tôi không chỉ bán pin — chúng tôi giúp doanh nghiệp vận hành hiệu quả hơn."
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 grid grid-cols-6 grid-rows-6 gap-4 h-[620px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="col-span-4 row-span-4 relative overflow-hidden"
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=1200&q=80"
              alt="factory"
              className="w-full h-full object-cover"
            />
            <div className="absolute top-4 left-4 bg-black text-white px-3 py-1.5" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
              NHÀ MÁY & SẢN XUẤT
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
            className="col-span-2 row-span-3 col-start-5 relative overflow-hidden"
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1720036236828-1c6a472db1c0?w=800&q=80"
              alt="engineer"
              className="w-full h-full object-cover"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.25 }}
            className="col-span-2 row-span-3 col-start-5 row-start-4 relative overflow-hidden bg-[#E11D2E]"
          >
            <div className="absolute inset-0 flex flex-col justify-between p-5 text-white">
              <div style={{ fontSize: 11, letterSpacing: "0.2em" }}>FOCUS</div>
              <div style={{ fontSize: 24, lineHeight: 1.15, fontWeight: 500 }}>
                Tư duy kỹ thuật + đồng hành triển khai thực tế
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.35 }}
            className="col-span-4 row-span-2 row-start-5 relative overflow-hidden"
          >
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1732030373864-d37573915751?w=1400&q=80"
              alt="battery cells"
              className="w-full h-full object-cover"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
