import { motion } from "motion/react";
import { ArrowUpRight, ArrowRight, Zap, Activity, Factory } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative bg-black text-white overflow-hidden pt-32 pb-24 lg:pt-40 lg:pb-32">
      {/* Background image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1720036236697-018370867320?w=2000&q=80"
          alt="industrial"
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60" />
      </div>

      {/* Precision grid */}
      <div
        className="absolute inset-0 opacity-[0.08]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.4) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.4) 1px,transparent 1px)",
          backgroundSize: "80px 80px",
        }}
      />

      {/* Red energy sweep */}
      <motion.div
        initial={{ x: "-120%" }}
        animate={{ x: "120%" }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        className="absolute top-1/3 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E11D2E] to-transparent"
      />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-10 items-end">
        {/* Headline block */}
        <div className="lg:col-span-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center gap-3 mb-8"
          >
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span className="text-[#E11D2E]" style={{ fontSize: 11, letterSpacing: "0.32em", fontWeight: 500 }}>
              GIẢI PHÁP PIN LITHIUM CÔNG NGHIỆP
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-white max-w-[14ch]"
            style={{ fontSize: "clamp(44px, 6.5vw, 92px)", lineHeight: 1.02, letterSpacing: "-0.03em", fontWeight: 500 }}
          >
            Đối tác pin lithium<br />
            & sạc toàn diện<br />
            <span className="text-white/40">cho doanh nghiệp.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.25 }}
            className="mt-8 text-white/70 max-w-2xl"
            style={{ fontSize: 17, lineHeight: 1.6, fontWeight: 400 }}
          >
            Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp vận hành ổn định,
            giảm downtime và tối ưu chi phí sở hữu dài hạn. Đồng hành cùng xe nâng điện, AGV/robot,
            xe điện du lịch và hệ thống ESS.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-10 flex flex-wrap items-center gap-5"
          >
            <a
              href="#contact"
              className="group inline-flex items-center gap-3 bg-[#E11D2E] hover:bg-white hover:text-black text-white px-7 py-4 transition-all"
              style={{ fontSize: 13, letterSpacing: "0.15em" }}
            >
              NHẬN TƯ VẤN KỸ THUẬT
              <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
            </a>
            <a
              href="#solutions"
              className="inline-flex items-center gap-3 text-white border-b border-white/30 hover:border-white pb-1 transition-all"
              style={{ fontSize: 13, letterSpacing: "0.15em" }}
            >
              XEM NHÓM GIẢI PHÁP
              <ArrowRight className="w-4 h-4" />
            </a>
          </motion.div>
        </div>

        {/* Floating panels */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="lg:col-span-4 space-y-3"
        >
          <FloatingPanel
            icon={<Factory className="w-4 h-4" />}
            label="5 NHÓM GIẢI PHÁP CHÍNH"
            title="Xe nâng • AGV • Xe điện du lịch • Sạc • ESS"
          />
          <FloatingPanel
            icon={<Zap className="w-4 h-4" />}
            label="OEM / ODM AVAILABLE"
            title="Tùy chỉnh theo yêu cầu kỹ thuật"
            accent
          />
          <FloatingPanel
            icon={<Activity className="w-4 h-4" />}
            label="PHỤC VỤ ĐA QUỐC GIA"
            title="Doanh nghiệp Việt Nam • FDI • Đối tác quốc tế"
          />
        </motion.div>
      </div>

      {/* Stats strip inside hero */}
      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-12 mt-24 grid grid-cols-2 md:grid-cols-4 gap-0 border-t border-white/10">
        {[
          ["10+", "Năm kinh nghiệm"],
          ["200+", "Dự án triển khai"],
          ["8", "Đại lý toàn quốc"],
          ["7+", "Nhóm ứng dụng phục vụ"],
        ].map(([n, l], i) => (
          <div key={l} className={`py-8 ${i !== 0 ? "md:border-l border-white/10" : ""}`}>
            <div className="text-white" style={{ fontSize: 44, fontWeight: 500, letterSpacing: "-0.02em" }}>
              {n}
            </div>
            <div className="text-white/50 mt-1" style={{ fontSize: 12, letterSpacing: "0.14em" }}>
              {l.toUpperCase()}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function FloatingPanel({
  icon,
  label,
  title,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  title: string;
  accent?: boolean;
}) {
  return (
    <motion.div
      whileHover={{ y: -3 }}
      className={`relative backdrop-blur-md border p-5 transition-all ${
        accent
          ? "bg-[#E11D2E]/15 border-[#E11D2E]/40"
          : "bg-white/[0.04] border-white/10 hover:border-white/25"
      }`}
    >
      <div className="flex items-center gap-2 text-white/70 mb-2">
        {icon}
        <span style={{ fontSize: 10, letterSpacing: "0.2em" }}>{label}</span>
      </div>
      <div className="text-white" style={{ fontSize: 14, lineHeight: 1.4 }}>
        {title}
      </div>
    </motion.div>
  );
}
