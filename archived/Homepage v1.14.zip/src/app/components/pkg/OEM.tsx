import { motion } from "motion/react";
import { ArrowUpRight, Cpu, Layers, Ruler, GitBranch } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const CAPS = [
  { icon: Ruler, t: "Kích thước & Form-factor", d: "Custom theo thiết bị, môi trường và không gian lắp đặt." },
  { icon: Cpu, t: "Điện áp & Dung lượng", d: "Cấu hình linh hoạt phù hợp ứng dụng thực tế." },
  { icon: Layers, t: "BMS & Giao thức", d: "Tích hợp hệ thống, giao thức CAN/RS485 và BMS custom." },
  { icon: GitBranch, t: "Tích hợp hệ thống", d: "Đồng bộ với bộ sạc, thiết bị và quy trình vận hành." },
];

export function OEM() {
  return (
    <section className="relative bg-black text-white py-28 lg:py-36 overflow-hidden">
      {/* Blueprint grid */}
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.6) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.6) 1px,transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-7">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span className="text-[#E11D2E]" style={{ fontSize: 11, letterSpacing: "0.3em" }}>
              OEM / ODM / CUSTOM SOLUTION
            </span>
          </div>
          <h2
            className="text-white"
            style={{ fontSize: "clamp(34px,4.5vw,64px)", lineHeight: 1.03, letterSpacing: "-0.025em", fontWeight: 500 }}
          >
            OEM / ODM và<br />giải pháp tùy chỉnh<br />
            <span className="text-white/40">theo yêu cầu kỹ thuật.</span>
          </h2>
          <p className="mt-8 text-white/65 max-w-2xl" style={{ fontSize: 16, lineHeight: 1.7 }}>
            PKG Battery hợp tác với doanh nghiệp và đối tác kỹ thuật cần cấu hình pin lithium theo
            yêu cầu — từ kích thước, điện áp, ứng dụng đến phương án tích hợp trong môi trường vận
            hành thực tế.
          </p>

          <div className="mt-10 grid sm:grid-cols-2 gap-px bg-white/10">
            {CAPS.map((c, i) => (
              <motion.div
                key={c.t}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="bg-black p-6 hover:bg-white/5 transition-colors"
              >
                <c.icon className="w-6 h-6 text-[#E11D2E] mb-4" />
                <div style={{ fontSize: 15, fontWeight: 500 }}>{c.t}</div>
                <div className="mt-2 text-white/55" style={{ fontSize: 13, lineHeight: 1.55 }}>{c.d}</div>
              </motion.div>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap gap-4">
            <a href="#contact" className="inline-flex items-center gap-3 bg-[#E11D2E] hover:bg-white hover:text-black text-white px-6 py-4" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
              TRAO ĐỔI VỀ OEM / ODM <ArrowUpRight className="w-4 h-4" />
            </a>
            <a href="#contact" className="inline-flex items-center gap-3 border border-white/30 hover:border-white px-6 py-4 transition-colors" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
              GỬI YÊU CẦU DỰ ÁN <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="lg:col-span-5 relative">
          <div className="relative h-full min-h-[500px]">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1775519520461-6b6e068d9250?w=1200&q=80"
              alt="oem technical"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />

            {/* Technical callouts */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="absolute top-8 left-8 bg-black/80 backdrop-blur border border-white/20 p-4 max-w-[180px]"
            >
              <div className="text-[#E11D2E]" style={{ fontSize: 10, letterSpacing: "0.2em" }}>NODE 01</div>
              <div className="mt-1" style={{ fontSize: 13, lineHeight: 1.4 }}>Cell selection + safety layer</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="absolute bottom-8 right-8 bg-[#E11D2E] p-4 max-w-[220px]"
            >
              <div style={{ fontSize: 10, letterSpacing: "0.2em" }}>NODE 02</div>
              <div className="mt-1" style={{ fontSize: 13, lineHeight: 1.4 }}>
                Custom BMS + CAN / RS485 integration layer
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
