import { useState } from "react";
import { motion } from "motion/react";
import { ArrowUpRight, Mail, Phone, MapPin } from "lucide-react";

export function ContactCTA() {
  const [f, setF] = useState({ name: "", company: "", phone: "", email: "", need: "" });

  return (
    <section id="contact" className="bg-[#0A0A0B] text-white py-28 lg:py-36 relative overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.8) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.8) 1px,transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />
      <motion.div
        animate={{ x: ["-20%", "120%"] }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        className="absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E11D2E] to-transparent w-1/3"
      />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span className="text-[#E11D2E]" style={{ fontSize: 11, letterSpacing: "0.3em" }}>
              NHẬN TƯ VẤN KỸ THUẬT
            </span>
          </div>
          <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.025em", fontWeight: 500 }}>
            Nhận tư vấn<br />kỹ thuật cho bài toán<br />
            <span className="text-white/40">pin lithium của bạn.</span>
          </h2>
          <p className="mt-6 text-white/60 max-w-md" style={{ fontSize: 15, lineHeight: 1.65 }}>
            Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu vận hành, đề xuất cấu hình
            phù hợp và định hướng giải pháp tối ưu hơn cho chi phí dài hạn.
          </p>

          <div className="mt-10 space-y-4 text-white/80">
            <div className="flex items-center gap-4"><Mail className="w-4 h-4 text-[#E11D2E]" /><span style={{ fontSize: 14 }}>contact@pkgbattery.vn</span></div>
            <div className="flex items-center gap-4"><Phone className="w-4 h-4 text-[#E11D2E]" /><span style={{ fontSize: 14 }}>1900 0000</span></div>
            <div className="flex items-center gap-4"><MapPin className="w-4 h-4 text-[#E11D2E]" /><span style={{ fontSize: 14 }}>HN • ĐN • HCM • CT</span></div>
          </div>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); alert("Đã gửi yêu cầu — đội ngũ PKG sẽ liên hệ trong 24h."); }}
          className="lg:col-span-7 bg-white/[0.03] border border-white/10 p-8 md:p-10 backdrop-blur"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Field label="Họ tên" v={f.name} onC={(v) => setF({ ...f, name: v })} />
            <Field label="Công ty" v={f.company} onC={(v) => setF({ ...f, company: v })} />
            <Field label="Số điện thoại" v={f.phone} onC={(v) => setF({ ...f, phone: v })} />
            <Field label="Email" v={f.email} onC={(v) => setF({ ...f, email: v })} />
            <div className="md:col-span-2">
              <div className="text-white/50 mb-2" style={{ fontSize: 11, letterSpacing: "0.2em" }}>NHU CẦU / ỨNG DỤNG</div>
              <textarea
                value={f.need}
                onChange={(e) => setF({ ...f, need: e.target.value })}
                rows={4}
                className="w-full bg-transparent border-b border-white/20 focus:border-[#E11D2E] outline-none py-2 text-white resize-none transition-colors"
                placeholder="Mô tả ngắn về thiết bị, ứng dụng và yêu cầu cấu hình..."
              />
            </div>
          </div>
          <div className="mt-8 flex flex-wrap gap-4 items-center">
            <button className="inline-flex items-center gap-3 bg-[#E11D2E] hover:bg-white hover:text-black text-white px-6 py-4 transition-all" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
              GỬI YÊU CẦU <ArrowUpRight className="w-4 h-4" />
            </button>
            <a href="#" className="text-white/70 hover:text-white" style={{ fontSize: 12, letterSpacing: "0.15em" }}>
              HOẶC TRAO ĐỔI VỀ OEM / ODM →
            </a>
          </div>
        </form>
      </div>
    </section>
  );
}

function Field({ label, v, onC }: { label: string; v: string; onC: (s: string) => void }) {
  return (
    <div>
      <div className="text-white/50 mb-2" style={{ fontSize: 11, letterSpacing: "0.2em" }}>{label.toUpperCase()}</div>
      <input
        value={v}
        onChange={(e) => onC(e.target.value)}
        className="w-full bg-transparent border-b border-white/20 focus:border-[#E11D2E] outline-none py-2 text-white transition-colors"
      />
    </div>
  );
}
