import { motion } from "motion/react";

const POINTS = [
  "Giải pháp thiết kế theo nhu cầu vận hành",
  "Tư duy kỹ thuật và khả năng đồng hành triển khai",
  "Tối ưu uptime, hiệu quả và chi phí dài hạn",
  "Phục vụ nhiều ứng dụng công nghiệp và logistics",
  "Khả năng tùy chỉnh giải pháp theo yêu cầu",
  "Phục vụ doanh nghiệp VN, FDI và đối tác kỹ thuật",
];

export function WhyChoose() {
  return (
    <section className="bg-white py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-5 lg:sticky lg:top-28">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>VÌ SAO CHỌN PKG</span>
          </div>
          <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
            Lý do doanh nghiệp<br />chọn <span className="text-[#E11D2E]">PKG Battery</span> cho<br />
            bài toán năng lượng.
          </h2>
        </div>

        <div className="lg:col-span-7 flex flex-col">
          {POINTS.map((p, i) => (
            <motion.div
              key={p}
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="group flex items-start gap-6 py-8 border-b border-black/10 hover:border-[#E11D2E] transition-colors"
            >
              <div className="text-black/30" style={{ fontSize: 13, letterSpacing: "0.2em" }}>
                0{i + 1}
              </div>
              <div className="flex-1" style={{ fontSize: "clamp(22px,2.2vw,32px)", lineHeight: 1.25, letterSpacing: "-0.01em", fontWeight: 500 }}>
                {p}
              </div>
              <div className="w-10 h-10 border border-black/20 grid place-items-center group-hover:bg-[#E11D2E] group-hover:border-[#E11D2E] group-hover:text-white transition-all">
                →
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
