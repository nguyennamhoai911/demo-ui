import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";

const NAV = [
  "Giải pháp",
  "Sản phẩm",
  "Ứng dụng",
  "OEM / ODM",
  "Về PKG",
  "Tin tức",
  "Đại lý",
  "Liên hệ",
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/85 backdrop-blur-xl border-b border-white/10"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 h-20 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3 text-white">
          <div className="relative w-10 h-10 grid place-items-center">
            <div className="absolute inset-0 bg-[#E11D2E] rotate-45" />
            <span className="relative text-white tracking-tight" style={{ fontSize: 18, fontWeight: 700 }}>
              P
            </span>
          </div>
          <div className="leading-none">
            <div style={{ fontSize: 15, fontWeight: 600, letterSpacing: "0.02em" }}>PKG BATTERY</div>
            <div className="text-white/50 mt-1" style={{ fontSize: 10, letterSpacing: "0.25em" }}>
              INDUSTRIAL LITHIUM
            </div>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-8">
          {NAV.map((n) => (
            <a
              key={n}
              href="#"
              className="text-white/80 hover:text-white transition-colors relative group"
              style={{ fontSize: 13, letterSpacing: "0.02em" }}
            >
              {n}
              <span className="absolute -bottom-2 left-0 h-px w-0 bg-[#E11D2E] transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 text-white/60" style={{ fontSize: 11, letterSpacing: "0.2em" }}>
            <span className="text-white">VI</span>
            <span>/</span>
            <span>EN</span>
          </div>
          <a
            href="#contact"
            className="hidden md:inline-flex items-center gap-2 bg-[#E11D2E] hover:bg-white hover:text-black text-white px-5 py-3 transition-all group"
            style={{ fontSize: 12, letterSpacing: "0.12em" }}
          >
            NHẬN TƯ VẤN KỸ THUẬT
            <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
          <button
            className="lg:hidden text-white"
            onClick={() => setOpen((v) => !v)}
            aria-label="menu"
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {open && (
        <div className="lg:hidden bg-black border-t border-white/10 px-6 py-6 flex flex-col gap-4">
          {NAV.map((n) => (
            <a key={n} href="#" className="text-white/80" style={{ fontSize: 14 }}>
              {n}
            </a>
          ))}
        </div>
      )}
    </motion.header>
  );
}
