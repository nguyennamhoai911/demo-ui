import { motion } from "motion/react";
import { AlertCircle, Clock, Wrench, Battery, Shield, Settings, TrendingDown } from "lucide-react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const POINTS = [
  { icon: Clock, title: "Thời gian sạc dài", desc: "Làm gián đoạn ca vận hành liên tục." },
  { icon: AlertCircle, title: "Downtime thiết bị", desc: "Ảnh hưởng trực tiếp tới sản lượng." },
  { icon: Battery, title: "Pin xuống cấp nhanh", desc: "Không đúng cường độ vận hành." },
  { icon: Wrench, title: "Chi phí bảo trì cao", desc: "Lặp lại theo chu kỳ ngắn hạn." },
  { icon: Shield, title: "Khó đảm bảo an toàn", desc: "Thiếu BMS và tiêu chuẩn phù hợp." },
  { icon: Settings, title: "Cấu hình không phù hợp", desc: "Không khớp với thiết bị thực tế." },
  { icon: TrendingDown, title: "TCO bị hiểu sai", desc: "Chỉ nhìn vào giá đầu tư ban đầu." },
];

export function PainPoints() {
  return (
    <section className="relative bg-[#0A0A0B] text-white py-28 lg:py-36 overflow-hidden">
      <div className="absolute inset-0 opacity-20">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1720036236828-1c6a472db1c0?w=2000&q=80"
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0B] via-[#0A0A0B]/90 to-transparent" />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-12 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5">
          <div className="flex items-center gap-3 mb-6">
            <span className="w-10 h-px bg-[#E11D2E]" />
            <span className="text-[#E11D2E]" style={{ fontSize: 11, letterSpacing: "0.3em" }}>
              VẤN ĐỀ VẬN HÀNH
            </span>
          </div>
          <h2
            className="text-white"
            style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}
          >
            Downtime, bảo trì và chi phí ẩn đang làm vận hành kém hiệu quả hơn bạn nghĩ.
          </h2>
          <p className="mt-6 text-white/60 max-w-lg" style={{ fontSize: 16, lineHeight: 1.6 }}>
            Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện
            năng mà còn mất thời gian, năng suất và khả năng kiểm soát chi phí dài hạn.
          </p>
        </div>

        <div className="lg:col-span-7 grid grid-cols-2 md:grid-cols-3 gap-px bg-white/10">
          {POINTS.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-[#0A0A0B] p-6 hover:bg-[#141416] transition-colors group"
            >
              <p.icon className="w-6 h-6 text-[#E11D2E] mb-4 group-hover:scale-110 transition-transform" />
              <div className="text-white" style={{ fontSize: 15, fontWeight: 500 }}>{p.title}</div>
              <div className="text-white/50 mt-2" style={{ fontSize: 12, lineHeight: 1.5 }}>{p.desc}</div>
            </motion.div>
          ))}
          <div className="bg-[#E11D2E] p-6 flex flex-col justify-between">
            <div style={{ fontSize: 11, letterSpacing: "0.2em" }}>PKG APPROACH</div>
            <div style={{ fontSize: 17, lineHeight: 1.35 }}>Giải quyết tận gốc bằng tư duy giải pháp kỹ thuật.</div>
          </div>
        </div>
      </div>
    </section>
  );
}
