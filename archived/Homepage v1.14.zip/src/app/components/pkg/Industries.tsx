import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";

const ITEMS = [
  { t: "Logistics & Kho vận", img: "https://images.unsplash.com/photo-1684695749267-233af13276d0?w=1200&q=80", tag: "01" },
  { t: "Nhà máy & Sản xuất", img: "https://images.unsplash.com/photo-1720036237334-9263cd28c3d4?w=1200&q=80", tag: "02" },
  { t: "AGV / Robot / Automation", img: "https://images.unsplash.com/photo-1720036237038-802f50cdfd9c?w=1200&q=80", tag: "03" },
  { t: "Resort & Mobility", img: "https://images.unsplash.com/photo-1664635032368-28eeb16de0d9?w=1200&q=80", tag: "04" },
  { t: "Khu công nghiệp", img: "https://images.unsplash.com/photo-1668204866018-85586ed7bd89?w=1200&q=80", tag: "05" },
  { t: "Hệ thống lưu trữ ESS", img: "https://images.unsplash.com/photo-1775519520494-d12d91797a01?w=1200&q=80", tag: "06" },
  { t: "Xe điện chuyên dụng", img: "https://images.unsplash.com/photo-1645736315000-6f788915923b?w=1200&q=80", tag: "07" },
];

export function Industries() {
  return (
    <section className="bg-[#F4F4F4] py-28 lg:py-36">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-12 gap-10 mb-14">
          <div className="lg:col-span-7">
            <div className="flex items-center gap-3 mb-6">
              <span className="w-10 h-px bg-[#E11D2E]" />
              <span style={{ fontSize: 11, letterSpacing: "0.3em" }}>ỨNG DỤNG / INDUSTRIES</span>
            </div>
            <h2 style={{ fontSize: "clamp(34px,4.5vw,60px)", lineHeight: 1.05, letterSpacing: "-0.02em", fontWeight: 500 }}>
              Giải pháp cho nhiều bối cảnh<br />vận hành công nghiệp.
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {ITEMS.map((it, i) => (
            <motion.a
              key={it.t}
              href="#"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className={`relative overflow-hidden group ${i === 0 ? "md:col-span-2 md:row-span-2 aspect-square md:aspect-auto" : "aspect-[4/5]"}`}
            >
              <ImageWithFallback
                src={it.img}
                alt={it.t}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
              <div className="absolute top-4 left-4 text-white/70" style={{ fontSize: 10, letterSpacing: "0.25em" }}>
                {it.tag}
              </div>
              <div className="absolute bottom-5 left-5 right-5 text-white" style={{ fontSize: i === 0 ? 26 : 16, lineHeight: 1.2, fontWeight: 500 }}>
                {it.t}
              </div>
              <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-[#E11D2E] group-hover:w-full transition-all duration-500" />
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
