
  # Homepage v1.14

  This is a code bundle for Homepage v1.14. The original project is available at https://www.figma.com/design/0fQ5hbgTJOH31jqgfYv7qZ/Homepage-v1.14.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  