import Navbar from "@/src/components/Navbar";
import Hero from "@/src/components/Hero";
import TrustSection from "@/src/components/TrustSection";
import AboutEnterprise from "@/src/components/AboutEnterprise";
import PainPoints from "@/src/components/PainPoints";
import SystemSolution from "@/src/components/SystemSolution";
import ProductCategories from "@/src/components/ProductCategories";
import OEMODMSection from "@/src/components/OEMODMSection";
import IndustryGallery from "@/src/components/IndustryGallery";
import TrustCenter from "@/src/components/TrustCenter";
import DealerMap from "@/src/components/DealerMap";
import NewsInsights from "@/src/components/NewsInsights";
import ContactCTA from "@/src/components/ContactCTA";
import Footer from "@/src/components/Footer";
import { motion, useScroll, useSpring } from "motion/react";

export default function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="relative overflow-x-hidden selection:bg-brand-red selection:text-white">
      {/* Custom Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-brand-red z-[60] origin-[0%]"
        style={{ scaleX }}
      />

      <Navbar />
      
      <main>
        <Hero />
        <TrustSection />
        <AboutEnterprise />
        <PainPoints />
        <SystemSolution />
        <ProductCategories />
        <OEMODMSection />
        <IndustryGallery />
        <TrustCenter />
        <DealerMap />
        <NewsInsights />
        <ContactCTA />
      </main>

      <Footer />

      {/* Floating Red Signal Decoration (Fixed position) */}
      <div className="fixed top-1/2 right-4 h-32 w-px bg-brand-red/10 z-40 hidden xl:block">
        <motion.div 
          animate={{ height: ["0%", "100%", "0%"] }}
          transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
          className="w-full bg-brand-red"
        />
      </div>
    </div>
  );
}

