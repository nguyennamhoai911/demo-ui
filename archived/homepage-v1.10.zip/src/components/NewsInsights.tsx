import { motion } from "motion/react";
import { ArrowUpRight, Calendar, User } from "lucide-react";

export default function NewsInsights() {
  const articles = [
    {
      title: "Tối ưu hóa chi phí vận hành xe nâng điện bằng pin Lithium-ion",
      category: "Kỹ thuật",
      date: "12-04-2026",
      img: "https://images.unsplash.com/photo-1586528116311-ad86d6f5439a?auto=format&fit=crop&q=80&w=800",
      featured: true
    },
    {
      title: "PKG Battery ra mắt dòng sản phẩm Pin AGV thế hệ mới với BMS tích hợp AI",
      category: "Sản phẩm",
      date: "08-04-2026",
      img: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&q=80&w=800",
      featured: false
    },
    {
      title: "Giải pháp lưu trữ năng lượng ESS cho nhà máy tại Bình Dương",
      category: "Dự án",
      date: "02-04-2026",
      img: "https://images.unsplash.com/photo-1466611653911-95282fc3656b?auto=format&fit=crop&q=80&w=800",
      featured: false
    },
    {
      title: "Tại sao nên chuyển đổi từ Pin Axit chì sang Lithium ngay hôm nay?",
      category: "Kiến thức",
      date: "28-03-2026",
      img: "https://images.unsplash.com/photo-1541625602330-2277a1cd13a1?auto=format&fit=crop&q=80&w=800",
      featured: false
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="max-w-2xl">
            <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-4">Insights & Updates</span>
            <h2 className="text-4xl font-display font-bold text-industrial-black leading-tight">
              TIN TỨC VÀ KIẾN THỨC <br />
              KỸ THUẬT NĂNG LƯỢNG
            </h2>
          </div>
          <button className="text-industrial-black font-bold text-sm border-b-2 border-industrial-black pb-1 hover:text-brand-red hover:border-brand-red transition-all">
            XEM TẤT CẢ BÀI VIẾT
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
          {/* Featured Article */}
          <div className="md:col-span-7">
            <motion.div
              whileHover={{ y: -10 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[16/10] overflow-hidden mb-6">
                <img
                  src={articles[0].img}
                  alt={articles[0].title}
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-6 left-6 p-2 bg-brand-red text-white text-[10px] font-mono font-bold tracking-widest uppercase">
                  {articles[0].category}
                </div>
              </div>
              <div className="flex items-center gap-6 mb-4 text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                <div className="flex items-center gap-2"><Calendar className="w-3 h-3" /> {articles[0].date}</div>
                <div className="flex items-center gap-2"><User className="w-3 h-3" /> By Technical Team</div>
              </div>
              <h3 className="text-3xl font-display font-bold text-industrial-black leading-tight mb-4 group-hover:text-brand-red transition-colors">
                {articles[0].title}
              </h3>
              <p className="text-gray-500 text-sm leading-relaxed mb-6 max-w-xl">
                Với xu hướng điện hóa toàn cầu, việc chuyển đổi sang pin Lithium mang đến lợi ích kép về cả năng suất vận hành lẫn bài toán tài chính dài hạn. Bài viết phân tích chi tiết các chỉ số ROI khi đầu tư hệ thống pin PKG...
              </p>
              <button className="flex items-center gap-2 font-bold text-xs uppercase tracking-widest group-hover:gap-4 transition-all">
                ĐỌC CHI TIẾT <ArrowUpRight className="w-4 h-4 text-brand-red" />
              </button>
            </motion.div>
          </div>

          {/* List of Small Articles */}
          <div className="md:col-span-5 space-y-10">
            {articles.slice(1).map((article, idx) => (
              <motion.div
                key={idx}
                whileHover={{ x: 10 }}
                className="group flex gap-6 cursor-pointer"
              >
                <div className="w-24 h-24 flex-shrink-0 overflow-hidden">
                  <img
                    src={article.img}
                    alt={article.title}
                    className="w-full h-full object-cover transition-transform group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-[9px] font-mono text-brand-red font-bold uppercase tracking-widest">
                      {article.category}
                    </span>
                    <span className="text-[9px] font-mono text-gray-400">
                      {article.date}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-industrial-black leading-snug group-hover:text-brand-red transition-colors line-clamp-2">
                    {article.title}
                  </h4>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
