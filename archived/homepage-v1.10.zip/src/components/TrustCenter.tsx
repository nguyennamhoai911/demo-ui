import { motion } from "motion/react";
import { Award, FileText, CheckCircle, ShieldCheck } from "lucide-react";

export default function TrustCenter() {
  const stats = [
    { label: "Năm kinh nghiệm", value: "10+" },
    { label: "Đại lý toàn quốc", value: "08" },
    { label: "Dự án triển khai", value: "500+" },
    { label: "Nhóm ứng dụng", value: "12+" }
  ];

  return (
    <section className="py-24 bg-gray-50 border-t border-gray-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Stats Tier */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 mb-32">
          {stats.map((s, idx) => (
            <motion.div
              key={idx}
              whileInView={{ opacity: 1, y: 0 }}
              initial={{ opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="text-center md:text-left"
            >
              <span className="block text-6xl md:text-8xl font-display font-black text-industrial-black tracking-tighter mb-4">
                {s.value}
              </span>
              <span className="text-[10px] font-mono text-brand-red font-bold tracking-[0.3em] uppercase">
                {s.label}
              </span>
            </motion.div>
          ))}
        </div>

        {/* Certificates & Documents Tier */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <div>
            <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-6">Compliance & Certification</span>
            <h2 className="text-4xl font-display font-bold text-industrial-black leading-tight mb-8">
              BẢO CHỨNG BỞI CÁC <br />
              TIÊU CHUẨN QUỐC TẾ
            </h2>
            <p className="text-gray-500 mb-10 leading-relaxed max-w-lg">
              Mọi sản phẩm và linh kiện tại PKG Battery đều trải qua quy trình kiểm định nghiêm ngặt, đáp ứng các chứng chỉ an toàn và hiệu suất hàng đầu trong ngành năng lượng.
            </p>
            
            <div className="space-y-6">
              {[
                { title: "Chứng chỉ ISO 9001:2015", desc: "Hệ thống quản lý chất lượng tiêu chuẩn quốc tế." },
                { title: "Tiêu chuẩn IEC 62619", desc: "Chứng nhận an toàn cho pin lithium công nghiệp." },
                { title: "CE / RoHS Compliance", desc: "Đảm bảo các quy định về an toàn và môi trường." }
              ].map((item, i) => (
                <div key={i} className="flex gap-4 p-4 border-l-2 border-transparent hover:border-brand-red hover:bg-white transition-all group">
                  <Award className="w-6 h-6 text-brand-red opacity-50 group-hover:opacity-100" />
                  <div>
                    <h4 className="font-bold text-sm text-industrial-black">{item.title}</h4>
                    <p className="text-xs text-gray-400">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => (
              <motion.div
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-6 shadow-xl border border-gray-100 aspect-[3/4] flex flex-col items-center justify-center text-center group"
              >
                <div className="w-16 h-20 bg-gray-50 border-2 border-gray-100 flex items-center justify-center mb-4 transition-colors group-hover:border-brand-red/20">
                  <FileText className="w-8 h-8 text-gray-300 group-hover:text-brand-red" />
                </div>
                <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block mb-1">Document</span>
                <span className="text-xs font-bold text-industrial-black">CERTIFICATE_0{i}</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Factory Tier */}
        <div className="relative group overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1558444479-c848260272cc?auto=format&fit=crop&q=80&w=2000"
            alt="Factory Environment"
            className="w-full h-[500px] object-cover transition-transform duration-[2s] group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-industrial-black/40 flex items-center justify-center">
            <div className="text-center p-12 border border-white/20 backdrop-blur-sm max-w-2xl transform transition-transform group-hover:scale-105">
              <h3 className="text-white text-3xl font-display font-bold mb-4">NĂNG LỰC SẢN XUẤT TẠI CHỖ</h3>
              <p className="text-white/80 text-sm mb-8 leading-relaxed">
                Chúng tôi sở hữu cơ sở hạ tầng kho bãi, xưởng sản xuất và phòng lab kiểm tra dung lượng chuyên biệt tại Việt Nam, sẵn sàng đáp ứng các đơn hàng quy mô lớn trong thời gian ngắn nhất.
              </p>
              <button className="bg-white text-industrial-black px-10 py-4 text-xs font-bold tracking-widest uppercase hover:bg-brand-red hover:text-white transition-all">
                THAM QUAN DOANH NGHIỆP
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
