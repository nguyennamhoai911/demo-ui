import { motion } from "motion/react";

export default function TrustSection() {
  const industries = [
    "Logistics",
    "Manufacturing",
    "Warehousing",
    "Automation",
    "Resort Mobility",
    "Energy Storage",
    "Industrial Vehicles",
    "Smart Factory",
  ];

  return (
    <section className="py-12 bg-white border-b border-gray-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono text-brand-red font-bold tracking-[0.3em] uppercase block mb-2">Verified Reliability</span>
          <h2 className="text-2xl font-display font-bold tracking-tight">HỆ SINH THÁI ĐỐI TÁC VÀ ỨNG DỤNG</h2>
        </div>
        <p className="text-gray-400 text-sm max-w-md">
          PKG Battery đồng hành cùng các doanh nghiệp đầu ngành trong việc tối ưu hóa hạ tầng năng lượng công nghiệp.
        </p>
      </div>

      {/* Moving Band */}
      <div className="relative flex">
        <div className="flex animate-marquee whitespace-nowrap gap-12 py-4">
          {[...industries, ...industries].map((industry, index) => (
            <div key={index} className="flex items-center gap-6 group">
              <span className="text-4xl md:text-5xl font-display font-black text-transparent stroke-1 stroke-gray-200 tracking-tighter opacity-50 group-hover:text-brand-red group-hover:stroke-brand-red transition-all duration-700">
                {industry.toUpperCase()}
              </span>
              <div className="w-1.5 h-1.5 bg-brand-red rounded-full opacity-30"></div>
            </div>
          ))}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
      `}} />
    </section>
  );
}
