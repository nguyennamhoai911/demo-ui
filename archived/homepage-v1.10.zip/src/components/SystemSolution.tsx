import { motion } from "motion/react";
import { Search, Settings, Cpu, Layers, Headphones } from "lucide-react";

export default function SystemSolution() {
  const steps = [
    {
      icon: <Search className="w-6 h-6" />,
      title: "Phân tích nhu cầu",
      desc: "Khảo sát bối cảnh vận hành, cường độ làm việc và yêu cầu thiết bị thực tế."
    },
    {
      icon: <Settings className="w-6 h-6" />,
      title: "Cấu hình hệ thống",
      desc: "Thiết lập thông số pin và bộ sạc tối ưu cho hiệu suất cao nhất."
    },
    {
      icon: <Cpu className="w-6 h-6" />,
      title: "Tùy chỉnh kỹ thuật",
      desc: "Tích hợp BMS và các tính năng đặc thù theo ứng dụng AGV/Robot/ESS."
    },
    {
      icon: <Layers className="w-6 h-6" />,
      title: "Triển khai đồng bộ",
      desc: "Lắp đặt, tinh chỉnh và đào tạo vận hành tại hiện trường doanh nghiệp."
    },
    {
      icon: <Headphones className="w-6 h-6" />,
      title: "Hỗ trợ hậu mãi",
      desc: "Giám sát kỹ thuật, bảo trì và đồng hành trọn vòng đời sản phẩm."
    }
  ];

  return (
    <section id="solutions" className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          <div className="lg:w-1/3 sticky top-32">
            <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-4">The Methodology</span>
            <h2 className="text-4xl font-display font-bold text-industrial-black leading-[1.1] mb-6">
              KHÔNG CHỈ LÀ PIN, <br />
              ĐÓ LÀ MỘT <br />
              HỆ GIẢI PHÁP
            </h2>
            <p className="text-gray-500 mb-8 leading-relaxed">
              Từ khảo sát nhu cầu đến tùy chỉnh theo ứng dụng và đồng hành kỹ thuật, PKG Battery hướng tới giải pháp vận hành hoàn chỉnh.
            </p>
            <button className="text-brand-red font-bold text-sm flex items-center gap-2 group">
              TẢI BROCHURE GIẢI PHÁP
              <div className="w-8 h-[1px] bg-brand-red transition-all group-hover:w-12"></div>
            </button>
          </div>

          <div className="lg:w-2/3 space-y-4">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                whileInView={{ opacity: 1, x: 0 }}
                initial={{ opacity: 0, x: 30 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group flex flex-col md:flex-row md:items-center gap-8 p-8 border border-gray-100 hover:border-brand-red/20 hover:bg-gray-50 transition-all cursor-default"
              >
                <div className="text-4xl font-display font-black text-gray-100 group-hover:text-brand-red/10 transition-colors">
                  0{index + 1}
                </div>
                <div className="w-12 h-12 bg-industrial-black text-white flex items-center justify-center flex-shrink-0 group-hover:bg-brand-red transition-colors">
                  {step.icon}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-industrial-black mb-2">{step.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-lg">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Decorative Technical Grid */}
      <div className="absolute bottom-0 right-0 w-64 h-64 opacity-[0.03] pointer-events-none">
        <div className="grid grid-cols-10 grid-rows-10 w-full h-full border-t border-l border-industrial-black">
          {[...Array(100)].map((_, i) => (
            <div key={i} className="border-r border-b border-industrial-black"></div>
          ))}
        </div>
      </div>
    </section>
  );
}
