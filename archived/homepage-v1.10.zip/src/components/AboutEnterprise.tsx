import { motion } from "motion/react";
import { Users, Factory, Target, CheckCircle2 } from "lucide-react";

export default function AboutEnterprise() {
  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          {/* Collage Section */}
          <div className="relative group">
            <div className="grid grid-cols-12 grid-rows-12 gap-4 h-[600px]">
              {/* Image 1: Main Factory/Team */}
              <motion.div
                whileInView={{ opacity: 1, scale: 1 }}
                initial={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.8 }}
                className="col-span-8 row-span-8 relative overflow-hidden"
              >
                <img
                  src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=1000"
                  alt="PKG Engineering Team"
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-industrial-black/10"></div>
              </motion.div>

              {/* Image 2: Production/Detail */}
              <motion.div
                whileInView={{ opacity: 1, x: 0 }}
                initial={{ opacity: 0, x: 50 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="col-span-4 row-span-5 col-start-9 row-start-2 relative overflow-hidden shadow-2xl z-10"
              >
                <img
                  src="https://images.unsplash.com/photo-1621259182978-f09e5e2ca935?auto=format&fit=crop&q=80&w=600"
                  alt="Battery Module"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Image 3: Application */}
              <motion.div
                whileInView={{ opacity: 1, y: 0 }}
                initial={{ opacity: 0, y: 50 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="col-span-5 row-span-4 col-start-6 row-start-9 relative overflow-hidden shadow-2xl z-10 border-4 border-white"
              >
                <img
                  src="https://images.unsplash.com/photo-1610444583731-9e1e9ac1449b?auto=format&fit=crop&q=80&w=800"
                  alt="Industrial Logistics"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Float Data Badge */}
              <div className="absolute -bottom-6 left-0 bg-brand-red text-white p-8 max-w-[240px] shadow-2xl z-20">
                <blockquote className="text-sm font-medium italic leading-relaxed">
                  "Chúng tôi không chỉ bán pin, chúng tôi xây dựng sự tin cậy trong từng chu kỳ sạc."
                </blockquote>
                <div className="mt-4 flex items-center gap-2">
                  <div className="w-8 h-[1px] bg-white opacity-50"></div>
                  <span className="text-[10px] font-mono tracking-widest uppercase">CEO Statement</span>
                </div>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div>
            <div className="mb-10">
              <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-4">Enterprise DNA</span>
              <h2 className="text-4xl md:text-5xl font-display font-bold text-industrial-black leading-[1.1] mb-8">
                ĐỐI TÁC NĂNG LƯỢNG <br />
                ĐƯỢC XÂY DỰNG CHO <br />
                VẬN HÀNH HIỆN ĐẠI
              </h2>
              <p className="text-gray-600 text-lg leading-relaxed mb-10">
                PKG Battery được định hướng như đối tác giải pháp pin lithium công nghiệp, kết hợp năng lực sản phẩm, tư duy kỹ thuật và khả năng triển khai theo nhu cầu thực tế của doanh nghiệp. Chúng tôi hướng tới việc phục vụ khách hàng trong nhiều môi trường vận hành khác nhau — từ logistics, nhà máy, AGV/robot đến lưu trữ năng lượng và các dự án kỹ thuật tùy biến.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-industrial-black text-white flex items-center justify-center">
                    <Factory className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm mb-1">Năng lực sản xuất</h4>
                    <p className="text-xs text-gray-500">Hệ thống xưởng hiện đại, quy trình kiểm định nghiêm ngặt.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-industrial-black text-white flex items-center justify-center">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm mb-1">Đội ngũ chuyên gia</h4>
                    <p className="text-xs text-gray-500">Kỹ sư giàu kinh nghiệm thực chiến trong ngành pin lithium.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-industrial-black text-white flex items-center justify-center">
                    <Target className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm mb-1">Độ tùy biến cao</h4>
                    <p className="text-xs text-gray-500">Giải pháp OEM / ODM đáp ứng các bài toán kỹ thuật đặc thù.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-industrial-black text-white flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm mb-1">Đồng hành dài hạn</h4>
                    <p className="text-xs text-gray-500">Hỗ trợ hậu mãi, bảo trì và tư vấn kỹ thuật trọn vòng đời.</p>
                  </div>
                </div>
              </div>

              <div className="mt-16 pt-10 border-t border-gray-100 flex items-center gap-10">
                <div>
                  <span className="block text-4xl font-display font-bold text-industrial-black">500+</span>
                  <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Projects Deployed</span>
                </div>
                <div className="h-10 w-[1px] bg-gray-200"></div>
                <div>
                  <span className="block text-4xl font-display font-bold text-industrial-black">15+</span>
                  <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Cities Served</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
