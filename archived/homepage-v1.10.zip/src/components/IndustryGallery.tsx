import { motion } from "motion/react";

export default function IndustryGallery() {
  const industries = [
    { name: "Logistics", img: "https://images.unsplash.com/photo-1586528116311-ad86d6f5439a?auto=format&fit=crop&q=80&w=800" },
    { name: "Manufacturing", img: "https://images.unsplash.com/photo-1565034946487-0d71ae0f9fb5?auto=format&fit=crop&q=80&w=800" },
    { name: "Warehousing", img: "https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&q=80&w=800" },
    { name: "Automation & Robotics", img: "https://images.unsplash.com/photo-1563911892437-1feda0179e1b?auto=format&fit=crop&q=80&w=800" },
    { name: "Resort Mobility", img: "https://images.unsplash.com/photo-1620311210411-e6bfd92550cb?auto=format&fit=crop&q=80&w=800" },
    { name: "Energy Infrastructure", img: "https://images.unsplash.com/photo-1466611653911-95282fc3656b?auto=format&fit=crop&q=80&w=800" }
  ];

  return (
    <section id="applications" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-20">
          <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-4">Market Presence</span>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-industrial-black tracking-tight leading-none mb-6">
            ĐỊNH HƯỚNG CHO NHIỀU <br />
            BỐI CẢNH VẬN HÀNH THỰC TẾ
          </h2>
          <div className="h-[2px] w-24 bg-brand-red"></div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1">
          {industries.map((item, index) => (
            <motion.div
              key={index}
              whileInView={{ opacity: 1, scale: 1 }}
              initial={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="relative aspect-[4/3] group overflow-hidden cursor-crosshair"
            >
              <img
                src={item.img}
                alt={item.name}
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-industrial-black/40 group-hover:bg-brand-red/60 transition-colors duration-700"></div>
              
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <span className="text-[10px] font-mono text-white/60 tracking-widest uppercase mb-1">Industrial Category</span>
                <h3 className="text-2xl font-display font-black text-white leading-tight uppercase transform transition-all group-hover:translate-x-2">
                  {item.name}
                </h3>
              </div>

              {/* Decorative Corner */}
              <div className="absolute top-4 right-4 w-6 h-6 border-t border-r border-white/40 group-hover:border-white transition-colors"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
