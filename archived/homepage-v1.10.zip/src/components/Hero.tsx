import { motion } from "motion/react";
import { ArrowRight, Zap, Shield, Cpu } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative h-screen min-h-[800px] w-full overflow-hidden bg-industrial-black flex items-center">
      {/* Cinematic Background Layer */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2000"
          alt="Industrial Automation"
          className="w-full h-full object-cover opacity-40 animate-slow-pan"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-industrial-black via-industrial-black/80 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-industrial-black via-transparent to-transparent"></div>
      </div>

      {/* Floating Signal Lines Effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute top-1/4 left-0 w-full h-px bg-brand-red/50 blur-[2px] -translate-y-1/2"></div>
        <div className="absolute top-2/3 left-0 w-full h-px bg-brand-red/30 blur-[1px] translate-y-1/2"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Text Content */}
        <div className="lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-[2px] bg-brand-red"></div>
              <span className="text-white font-mono text-xs tracking-[0.3em] uppercase">
                Industry Excellence • Solutions Driven
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-white leading-[0.9] tracking-tighter mb-8 italic">
              GIẢI PHÁP PIN <br />
              <span className="text-brand-red">LITHIUM</span> <br />
              CÔNG NGHIỆP.
            </h1>

            <p className="text-lg md:text-xl text-white/70 max-w-xl mb-10 leading-relaxed font-light">
              PKG Battery chuyên sâu hệ thống pin lithium, bộ sạc và giải pháp kỹ thuật cho xe nâng điện, AGV/robot và lưu trữ năng lượng ESS — Tối ưu uptime, hiệu suất và chi phí TCO.
            </p>

            <div className="flex flex-wrap gap-4">
              <button className="bg-brand-red text-white px-8 py-4 text-sm font-bold flex items-center gap-3 group transition-all hover:bg-white hover:text-industrial-black">
                NHẬN TƯ VẤN KỸ THUẬT
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="border border-white/20 text-white px-8 py-4 text-sm font-bold flex items-center gap-3 backdrop-blur-sm transition-all hover:bg-white/10">
                KHÁM PHÁ HỆ GIẢI PHÁP
              </button>
            </div>
          </motion.div>
        </div>

        {/* Info Panels Cluster */}
        <div className="lg:col-span-5 hidden lg:block">
          <div className="relative">
            {/* Panel 1 */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 mb-6 relative overflow-hidden group hover:border-brand-red/50 transition-colors"
            >
              <div className="absolute top-0 right-0 p-2 opacity-20">
                <Zap className="w-20 h-20 text-brand-red" />
              </div>
              <h3 className="text-2xl font-display font-bold text-white mb-2">05 NHÓM GIẢI PHÁP</h3>
              <p className="text-white/50 text-sm mb-4">Hệ sinh thái pin & sạc toàn diện cho mọi bối cảnh vận hành doanh nghiệp.</p>
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-brand-red rounded-full animate-pulse"></div>
                <div className="text-[10px] font-mono text-white/60 tracking-widest uppercase">High Performance Systems</div>
              </div>
            </motion.div>

            {/* Panel 2 (Small) */}
            <div className="grid grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="bg-brand-red p-6 aspect-square flex flex-col justify-between"
              >
                <Shield className="w-10 h-10 text-white" />
                <div className="text-white">
                  <span className="block text-3xl font-display font-bold">100%</span>
                  <span className="text-[10px] font-mono uppercase tracking-tighter opacity-80 leading-none">Safety Compliance</span>
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="bg-industrial-gray border border-white/10 p-6 aspect-square flex flex-col justify-between"
              >
                <Cpu className="w-10 h-10 text-brand-red" />
                <div className="text-white">
                  <span className="block text-lg font-display font-bold tracking-tight">OEM / ODM Support</span>
                  <span className="text-[10px] font-mono uppercase opacity-50">Custom Engineering</span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Down Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-50">
        <div className="w-[1px] h-12 bg-white/30 relative">
          <motion.div
            animate={{ top: ["0%", "100%"], opacity: [0, 1, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="absolute left-0 w-[1px] h-1/4 bg-brand-red"
          />
        </div>
        <span className="text-[8px] font-mono text-white uppercase tracking-widest">Scroll</span>
      </div>
    </section>
  );
}
