import { motion } from "motion/react";
import { MapPin, Phone, ExternalLink } from "lucide-react";

export default function DealerMap() {
  const dealers = [
    { city: "Hà Nội", count: 2, contacts: ["091x.xxx.xxx", "092x.xxx.xxx"] },
    { city: "Hải Phòng", count: 1, contacts: ["093x.xxx.xxx"] },
    { city: "Đà Nẵng", count: 1, contacts: ["094x.xxx.xxx"] },
    { city: "TP. Hồ Chí Minh", count: 3, contacts: ["095x.xxx.xxx", "096x.xxx.xxx", "097x.xxx.xxx"] },
    { city: "Bình Dương", count: 1, contacts: ["098x.xxx.xxx"] }
  ];

  return (
    <section id="dealers" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-center">
          {/* List Section */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-6">Distribution Network</span>
            <h2 className="text-4xl font-display font-bold text-industrial-black leading-tight mb-8">
              MẠNG LƯỚI ĐẠI LÝ <br />
              TRÊN TOÀN VIỆT NAM
            </h2>
            <p className="text-gray-500 mb-10 leading-relaxed">
              Với hệ thống đại lý và trung tâm phân phối chiến lược, PKG Battery đảm bảo khả năng cung ứng và hỗ trợ kỹ thuật nhanh chóng nhất cho khách hàng trên toàn quốc.
            </p>

            <div className="space-y-4">
              {dealers.map((dealer, idx) => (
                <div key={idx} className="group p-6 border border-gray-100 hover:border-brand-red/30 hover:bg-gray-50 transition-all flex justify-between items-center">
                  <div>
                    <h4 className="font-bold text-industrial-black text-lg mb-1">{dealer.city}</h4>
                    <div className="flex items-center gap-4">
                      <span className="text-[10px] font-mono text-brand-red font-bold uppercase">{dealer.count} ĐIỂM CUNG ỨNG</span>
                      <div className="flex gap-2">
                        {dealer.contacts.map((c, i) => (
                          <div key={i} className="flex items-center gap-1 text-[10px] text-gray-400">
                             <Phone className="w-2.5 h-2.5" />
                             {c}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  <button className="w-10 h-10 border border-gray-100 flex items-center justify-center text-gray-300 group-hover:text-brand-red group-hover:border-brand-red transition-all">
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <button className="mt-12 w-full bg-industrial-black text-white py-5 font-bold text-sm tracking-widest uppercase hover:bg-brand-red transition-all">
              TÌM ĐẠI LÝ GẦN BẠN NHẤT
            </button>
          </div>

          {/* Map Visualization */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            <div className="relative aspect-[3/4] md:aspect-square bg-gray-50 flex items-center justify-center overflow-hidden border border-gray-100">
               {/* Stylized VN Map SVG */}
               <svg viewBox="0 0 400 600" className="w-full h-full p-12 opacity-80">
                  <path 
                    d="M100,50 L120,40 L160,60 L180,100 L170,150 L150,180 L140,240 L160,280 L180,320 L220,380 L240,450 L230,520 L200,550 L180,540 L170,500 L150,450 L140,400 L130,350 L120,300 L100,250 L80,200 L70,150 L80,100 Z" 
                    fill="#F1F5F9" 
                    stroke="#CBD5E1" 
                    strokeWidth="1"
                  />
                  
                  {/* Pulse points for dealers */}
                  <g className="dealer-points">
                    <circle cx="130" cy="70" r="4" fill="#E31E24" className="animate-ping opacity-75" />
                    <circle cx="130" cy="70" r="3" fill="#E31E24" />
                    
                    <circle cx="140" cy="120" r="4" fill="#E31E24" className="animate-ping opacity-75" />
                    <circle cx="140" cy="120" r="3" fill="#E31E24" />
                    
                    <circle cx="160" cy="270" r="4" fill="#E31E24" className="animate-ping opacity-75" />
                    <circle cx="160" cy="270" r="3" fill="#E31E24" />
                    
                    <circle cx="210" cy="480" r="6" fill="#E31E24" className="animate-ping opacity-75" />
                    <circle cx="210" cy="480" r="4" fill="#E31E24" />

                    <circle cx="230" cy="450" r="4" fill="#E31E24" className="animate-ping opacity-75" />
                    <circle cx="230" cy="450" r="3" fill="#E31E24" />
                  </g>
               </svg>

               {/* Absolute Floating Info */}
               <motion.div 
                 initial={{ opacity: 0, x: 20 }}
                 whileInView={{ opacity: 1, x: 0 }}
                 className="absolute top-10 right-10 p-6 bg-white shadow-2xl border-l-4 border-brand-red hidden md:block"
               >
                 <span className="block text-2xl font-black font-display text-industrial-black">08</span>
                 <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">Active Hubs</span>
               </motion.div>

               {/* Overlay Decoration */}
               <div className="absolute top-0 left-0 p-8">
                  <div className="flex gap-1 text-gray-200">
                    <div className="w-1.5 h-1.5 bg-current"></div>
                    <div className="w-1.5 h-1.5 bg-current"></div>
                    <div className="w-1.5 h-1.5 bg-current"></div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
