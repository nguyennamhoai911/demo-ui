import { motion } from "motion/react";
import { ArrowRight, Mail, Phone, MessageSquare } from "lucide-react";

export default function ContactCTA() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="bg-industrial-black p-12 md:p-20 relative overflow-hidden">
          {/* Animated Background layer */}
          <div className="absolute top-0 right-0 w-1/3 h-full bg-brand-red skew-x-[30deg] translate-x-1/2 opacity-20"></div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-6">Connect with us</span>
              <h2 className="text-4xl md:text-6xl font-display font-bold text-white leading-tight mb-8">
                SẴN SÀNG CHO <br />
                BÀI TOÁN <br />
                <span className="text-brand-red">NĂNG LƯỢNG <br /> CỦA BẠN?</span>
              </h2>
              <p className="text-white/60 text-lg leading-relaxed mb-10 max-w-sm">
                Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu, định hướng giải pháp phù hợp và xây dựng cấu hình tối ưu nhất.
              </p>

              <div className="space-y-6">
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="w-12 h-12 border border-white/10 flex items-center justify-center group-hover:bg-brand-red group-hover:border-brand-red transition-all">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono text-white/40 uppercase tracking-widest leading-none mb-1">Hotline tư vấn</span>
                    <span className="block text-xl font-bold text-white">090x.xxx.xxx</span>
                  </div>
                </div>
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="w-12 h-12 border border-white/10 flex items-center justify-center group-hover:bg-brand-red group-hover:border-brand-red transition-all">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="block text-[10px] font-mono text-white/40 uppercase tracking-widest leading-none mb-1">Email dự án</span>
                    <span className="block text-xl font-bold text-white">sales@pkg-battery.vn</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 md:p-12">
              <h3 className="text-2xl font-display font-bold text-white mb-8">NHẬN TƯ VẤN KỸ THUẬT</h3>
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Họ và tên</label>
                    <input className="w-full bg-white/5 border-b border-white/20 p-3 text-white focus:outline-none focus:border-brand-red transition-colors" type="text" placeholder="Nguyễn Văn A" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Số điện thoại</label>
                    <input className="w-full bg-white/5 border-b border-white/20 p-3 text-white focus:outline-none focus:border-brand-red transition-colors" type="tel" placeholder="090x xxx xxx" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Công ty / Tổ chức</label>
                  <input className="w-full bg-white/5 border-b border-white/20 p-3 text-white focus:outline-none focus:border-brand-red transition-colors" type="text" placeholder="Tên công ty" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Ứng dụng quan tâm</label>
                  <select className="w-full bg-white/5 border-b border-white/20 p-3 text-white focus:outline-none focus:border-brand-red transition-colors appearance-none">
                    <option className="bg-industrial-black">Pin Xe Nâng Điện</option>
                    <option className="bg-industrial-black">Pin Xe Golf / Du Lịch</option>
                    <option className="bg-industrial-black">Hệ Thống AGV / Robot</option>
                    <option className="bg-industrial-black">Lưu Trữ Năng Lượng ESS</option>
                    <option className="bg-industrial-black">Hợp Tác OEM / ODM</option>
                  </select>
                </div>
                <div className="pt-6">
                  <button className="w-full bg-brand-red text-white py-5 font-bold text-sm tracking-widest uppercase flex items-center justify-center gap-3 hover:bg-white hover:text-industrial-black transition-all">
                    GỬI YÊU CẦU TƯ VẤN
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
