import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";

export default function ProductCategories() {
  const products = [
    {
      id: "forklift",
      title: "Pin Lithium Xe Nâng Điện",
      desc: "Giải pháp thay thế bình điện axit chì truyền thống, sạc nhanh, không bảo trì, hiệu suất vượt trội.",
      tags: ["Logistics", "Warehouse", "Heavy Duty"],
      image: "https://images.unsplash.com/photo-1586528116311-ad86d6f5439a?auto=format&fit=crop&q=80&w=1200",
      size: "large"
    },
    {
      id: "tourism",
      title: "Pin Lithium Xe Điện Du Lịch",
      desc: "Tối ưu trọng lượng, tăng quãng đường di chuyển và độ bền cho xe golf, xe điện resort.",
      tags: ["Resort", "Hospitality", "Light EV"],
      image: "https://images.unsplash.com/photo-1541625602330-2277a1cd13a1?auto=format&fit=crop&q=80&w=800",
      size: "small"
    },
    {
      id: "agv",
      title: "Pin / Hệ Thống Cho AGV & Robot",
      desc: "Tích hợp BMS thông minh, giao tiếp CAN/RS485, đảm bảo vận hành 24/7 cho hệ thống tự động hóa.",
      tags: ["Automation", "Robotics", "Industry 4.0"],
      image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=800",
      size: "small"
    },
    {
      id: "ess",
      title: "Lưu Trữ Năng Lượng ESS",
      desc: "Hệ thống lưu trữ quy mô công nghiệp, tối ưu hóa năng lượng tái tạo và dự phòng lưới điện.",
      tags: ["Energy", "Smart Grid", "Sustainability"],
      image: "https://images.unsplash.com/photo-1611348586804-61bf6c080437?auto=format&fit=crop&q=80&w=1200",
      size: "large"
    },
    {
      id: "charger",
      title: "Bộ Sạc & Trạm Sạc Thông Minh",
      desc: "Công nghệ sạc nhanh, bảo vệ đa lớp, tương thích hoàn hảo với hệ pin PKG Lithium.",
      tags: ["Charging", "Infrastructure", "Power"],
      image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=800",
      size: "medium"
    }
  ];

  return (
    <section id="products" className="py-24 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="max-w-2xl">
            <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-4">Product Ecosystem</span>
            <h2 className="text-4xl font-display font-bold text-industrial-black leading-tight">
              05 NHÓM SẢN PHẨM VÀ <br />
              GIẢI PHÁP CHỦ LỰC
            </h2>
          </div>
          <p className="text-gray-400 text-sm max-w-xs font-light">
            Mỗi dòng sản phẩm đều được thiết kế dựa trên tiêu chuẩn công nghiệp khắt khe nhất về độ bền và an toàn.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 auto-rows-[400px]">
          {products.map((p, idx) => (
            <motion.div
              key={p.id}
              whileInView={{ opacity: 1, scale: 1 }}
              initial={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className={`relative overflow-hidden group cursor-pointer ${
                p.size === "large" ? "md:col-span-8" : 
                p.size === "medium" ? "md:col-span-12" : "md:col-span-4"
              }`}
            >
              {/* Background Image */}
              <img
                src={p.image}
                alt={p.title}
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-industrial-black via-industrial-black/20 to-transparent opacity-80 transition-opacity group-hover:opacity-95"></div>

              {/* Content Overlay */}
              <div className="absolute inset-x-0 bottom-0 p-8 flex flex-col justify-end h-full">
                <div className="flex gap-2 mb-4">
                  {p.tags.map(t => (
                    <span key={t} className="px-3 py-1 bg-white/10 backdrop-blur-md border border-white/10 text-[10px] font-mono text-white/80 uppercase tracking-widest">
                      {t}
                    </span>
                  ))}
                </div>
                <h3 className="text-2xl md:text-3xl font-display font-bold text-white mb-2 leading-tight">
                  {p.title}
                </h3>
                <p className="text-white/60 text-sm max-w-md hidden md:block group-hover:text-white/80 transition-colors">
                  {p.desc}
                </p>

                {/* Hover Reveal Action */}
                <div className="mt-6 flex items-center gap-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                  <button className="bg-brand-red text-white py-3 px-8 text-xs font-bold tracking-widest uppercase flex items-center gap-2 hover:bg-white hover:text-industrial-black transition-colors">
                    XEM DANH MỤC
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Index Number */}
              <div className="absolute top-8 left-8 text-6xl font-display font-black text-white/5 pointer-events-none group-hover:text-brand-red/10 transition-colors">
                0{idx + 1}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
