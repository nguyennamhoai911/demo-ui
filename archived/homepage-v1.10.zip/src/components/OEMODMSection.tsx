import { motion } from "motion/react";
import { Cpu, Workflow, PenTool, Database } from "lucide-react";

export default function OEMODMSection() {
  return (
    <section id="oem" className="py-24 bg-industrial-black relative overflow-hidden">
      {/* Background technical overlay */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div
            whileInView={{ opacity: 1, x: 0 }}
            initial={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-brand-red font-mono text-xs font-bold tracking-[0.4em] uppercase block mb-6">Expert Engineering</span>
            <h2 className="text-4xl md:text-6xl font-display font-bold text-white leading-tight mb-8">
              TÙY CHỈNH GIẢI PHÁP <br />
              VÀ HỢP TÁC <br />
              <span className="text-brand-red">OEM / ODM</span>
            </h2>
            <p className="text-white/60 text-lg leading-relaxed mb-10 max-w-xl">
              PKG Battery định hướng hỗ trợ các bài toán pin lithium theo yêu cầu kỹ thuật riêng, bao gồm khả năng tùy chỉnh cấu hình, ứng dụng, phương án tích hợp và hướng hợp tác OEM / ODM cho doanh nghiệp và đối tác kỹ thuật.
            </p>

            <div className="grid grid-cols-2 gap-8 mb-12">
              <div className="space-y-3">
                <div className="w-10 h-10 border border-brand-red/30 flex items-center justify-center text-brand-red">
                  <Cpu className="w-5 h-5" />
                </div>
                <h4 className="text-white text-sm font-bold">Custom BMS</h4>
                <p className="text-white/40 text-xs">Phát triển mạch bảo vệ thông minh theo giao thức riêng.</p>
              </div>
              <div className="space-y-3">
                <div className="w-10 h-10 border border-brand-red/30 flex items-center justify-center text-brand-red">
                  <PenTool className="w-5 h-5" />
                </div>
                <h4 className="text-white text-sm font-bold">Design Flow</h4>
                <p className="text-white/40 text-xs">Thiết kế cấu trúc module tối ưu cho không gian lắp đặt.</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <button className="bg-brand-red text-white py-5 px-10 text-xs font-bold tracking-[0.2em] uppercase hover:bg-white hover:text-industrial-black transition-all">
                GỬI YÊU CẦU DỰ ÁN
              </button>
              <button className="text-white py-5 px-2 text-xs font-bold tracking-[0.2em] uppercase border-b border-brand-red hover:border-white transition-all">
                TRAO ĐỔI OEM / ODM
              </button>
            </div>
          </motion.div>

          <div className="relative">
            <motion.div
              whileInView={{ opacity: 1, rotate: 0 }}
              initial={{ opacity: 0, rotate: 5 }}
              transition={{ duration: 1 }}
              className="relative aspect-square bg-industrial-gray border border-white/5 overflow-hidden group"
            >
              <img
                src="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1000"
                alt="Electronic Circuitry"
                className="w-full h-full object-cover opacity-50 transition-transform duration-[2s] group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-brand-red/20 to-transparent"></div>
              
              {/* Technical Overlay */}
              <div className="absolute inset-0 p-12 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="w-20 h-[1px] bg-white/30"></div>
                  <div className="text-right">
                    <span className="block text-white/50 font-mono text-[10px]">SPECIFICATION</span>
                    <span className="block text-brand-red font-mono text-[10px]">PKG-BATT_CUSTOM_01</span>
                  </div>
                </div>
                <div>
                  <h4 className="text-white font-display text-4xl font-black mb-2 opacity-50 tracking-tighter">BMS INTELLIGENCE</h4>
                  <div className="h-[2px] w-full bg-white/10 relative">
                    <motion.div
                      animate={{ width: ["0%", "100%", "0%"] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute top-0 left-0 h-full bg-brand-red shadow-[0_0_10px_#E31E24]"
                    />
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Float Label */}
            <div className="absolute -top-10 -right-10 bg-brand-red text-white p-6 md:p-10 shadow-2xl">
              <Database className="w-8 h-8 mb-4" />
              <span className="block text-3xl font-display font-black leading-none">CELL</span>
              <span className="block text-xs font-mono tracking-widest uppercase opacity-80">Grade A Tier-1</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
