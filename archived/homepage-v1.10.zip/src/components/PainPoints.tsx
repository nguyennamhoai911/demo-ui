import { motion } from "motion/react";
import { Gauge, Clock, ShieldAlert, CreditCard, Wrench } from "lucide-react";

export default function PainPoints() {
  const pains = [
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Downtime do sạc chậm",
      desc: "Thời gian chờ sạc quá dài làm gián đoạn chuỗi cung ứng và giảm năng suất lao động."
    },
    {
      icon: <Wrench className="w-6 h-6" />,
      title: "Bảo trì tốn kém",
      desc: "Chi phí bảo trì định kỳ cho các dòng pin cũ tiêu tốn nguồn lực và tài chính của doanh nghiệp."
    },
    {
      icon: <Gauge className="w-6 h-6" />,
      title: "Hiệu suất không ổn định",
      desc: "Dung lượng ảo và sự sụt giảm điện áp khi làm việc cường độ cao gây mất an toàn."
    },
    {
      icon: <ShieldAlert className="w-6 h-6" />,
      title: "Rủi ro an toàn cháy nổ",
      desc: "Thiếu hệ thống BMS thông minh kiểm soát rủi ro trong môi trường công nghiệp khắc nghiệt."
    },
    {
      icon: <CreditCard className="w-6 h-6" />,
      title: "TCO khó tối ưu",
      desc: "Lựa chọn sai giải pháp ban đầu dẫn đến chi phí vận hành (Total Cost of Ownership) tăng vọt."
    }
  ];

  return (
    <section className="py-24 bg-industrial-black relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-red/5 skew-x-12 translate-x-1/2"></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="max-w-3xl mb-20">
          <span className="text-white/40 font-mono text-xs tracking-[0.3em] uppercase block mb-4 italic">The Operational Reality</span>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-6 leading-tight">
            KHI NĂNG LƯỢNG KHÔNG PHÙ HỢP, <br />
            <span className="text-brand-red">VẬN HÀNH PHẢI TRẢ GIÁ.</span>
          </h2>
          <p className="text-white/60 text-lg font-light leading-relaxed">
            Downtime, bảo trì, tuổi thọ, tốc độ sạc và độ an toàn đều ảnh hưởng trực tiếp đến hiệu suất vận hành và tổng chi phí sở hữu (TCO) của doanh nghiệp.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {pains.map((pain, index) => (
            <motion.div
              key={index}
              whileInView={{ opacity: 1, y: 0 }}
              initial={{ opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-industrial-gray border border-white/5 p-8 relative group hover:border-brand-red/30 transition-all duration-500"
            >
              <div className="w-12 h-12 bg-white/5 flex items-center justify-center text-brand-red mb-6 transition-colors group-hover:bg-brand-red group-hover:text-white">
                {pain.icon}
              </div>
              <h3 className="text-lg font-bold text-white mb-4 leading-tight">{pain.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{pain.desc}</p>
              
              {/* Corner Accent */}
              <div className="absolute top-0 right-0 w-0 h-0 border-t-[30px] border-r-[30px] border-t-white/5 border-r-transparent group-hover:border-t-brand-red/20 transition-all"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
