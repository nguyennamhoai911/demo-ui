import { Facebook, Linkedin, Youtube, ArrowUpRight } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-industrial-black text-white pt-24 pb-12 overflow-hidden relative">
      {/* Decorative Brand Accent */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-red/20 blur-[150px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-16 mb-20">
          {/* Brand Col */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-brand-red flex items-center justify-center">
                <div className="w-6 h-1.5 bg-white"></div>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-display font-bold leading-none tracking-tight">
                  PKG <span className="text-brand-red">BATTERY</span>
                </span>
                <span className="text-[10px] font-mono tracking-[0.2em] uppercase opacity-40">
                  Industrial Energy Excellence
                </span>
              </div>
            </div>
            <p className="text-white/40 text-sm leading-relaxed mb-10 max-w-sm">
              Định hướng giải pháp pin lithium công nghiệp trọn gói, nâng tầm hiệu suất vận hành cho doanh nghiệp hiện đại.
            </p>
            <div className="flex gap-4">
              {[Facebook, Linkedin, Youtube].map((Icon, idx) => (
                <a key={idx} href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links 1 */}
          <div className="md:col-span-2">
            <h4 className="text-brand-red font-mono text-[10px] uppercase tracking-widest mb-6">Giải pháp</h4>
            <ul className="space-y-4 text-white/60 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Xe nâng điện</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Xe du lịch</a></li>
              <li><a href="#" className="hover:text-white transition-colors">AGV / Robot</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Lưu trữ ESS</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Trạm sạc</a></li>
            </ul>
          </div>

          {/* Links 2 */}
          <div className="md:col-span-2">
            <h4 className="text-brand-red font-mono text-[10px] uppercase tracking-widest mb-6">Doanh nghiệp</h4>
            <ul className="space-y-4 text-white/60 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Về PKG Battery</a></li>
              <li><a href="#" className="hover:text-white transition-colors">OEM / ODM</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Đại lý toàn quốc</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Tin tức & Sự kiện</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Cơ hội nghề nghiệp</a></li>
            </ul>
          </div>

          {/* Contact Col */}
          <div className="md:col-span-3">
            <h4 className="text-brand-red font-mono text-[10px] uppercase tracking-widest mb-6">Liên hệ</h4>
            <div className="space-y-6">
               <div className="flex gap-4">
                 <div className="w-1 h-1 bg-brand-red mt-2"></div>
                 <p className="text-white/60 text-sm">
                   Trụ sở: Tòa nhà Industrial, <br />
                   Khu công nghệ cao, TP. Thủ Đức, <br />
                   Thành phố Hồ Chí Minh.
                 </p>
               </div>
               <div className="flex gap-4">
                 <div className="w-1 h-1 bg-brand-red mt-2"></div>
                 <p className="text-white/60 text-sm">
                   090x.xxx.xxx <br />
                   sales@pkg-battery.vn
                 </p>
               </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <span className="text-[10px] font-mono text-white/20 uppercase tracking-widest">
            © 2026 PKG BATTERY. ALL RIGHTS RESERVED.
          </span>
          <div className="flex gap-10">
             <a href="#" className="text-[10px] font-mono text-white/20 hover:text-brand-red uppercase tracking-widest transition-colors">Privacy Policy</a>
             <a href="#" className="text-[10px] font-mono text-white/20 hover:text-brand-red uppercase tracking-widest transition-colors">Terms of Service</a>
          </div>
          <div className="flex items-center gap-4 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Back to top</span>
            <div className="w-10 h-10 border border-white/10 flex items-center justify-center group-hover:bg-brand-red group-hover:border-brand-red transition-all">
              <ArrowUpRight className="w-4 h-4 transform -rotate-45" />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
