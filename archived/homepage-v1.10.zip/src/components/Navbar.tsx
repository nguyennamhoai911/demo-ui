import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, ChevronDown, ArrowRight } from "lucide-react";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Giải pháp", href: "#solutions" },
    { name: "Sản phẩm", href: "#products" },
    { name: "Ứng dụng", href: "#applications" },
    { name: "OEM / ODM", href: "#oem" },
    { name: "Doanh nghiệp", href: "#about" },
    { name: "Đại lý", href: "#dealers" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled ? "bg-white/90 backdrop-blur-md py-4 shadow-sm" : "bg-transparent py-6"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 bg-brand-red flex items-center justify-center rounded-sm transition-transform duration-500 group-hover:rotate-90">
            <div className="w-5 h-1 bg-white"></div>
          </div>
          <div className="flex flex-col">
            <span className={`text-xl font-display font-bold leading-none tracking-tight ${isScrolled ? "text-industrial-black" : "text-white"}`}>
              PKG <span className="text-brand-red">BATTERY</span>
            </span>
            <span className={`text-[8px] font-mono tracking-[0.2em] uppercase opacity-60 ${isScrolled ? "text-industrial-black" : "text-white"}`}>
              Industrial Energy Excellence
            </span>
          </div>
        </div>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={`text-sm font-medium tracking-wide transition-colors hover:text-brand-red ${
                isScrolled ? "text-industrial-black" : "text-white/90"
              }`}
            >
              {link.name}
            </a>
          ))}
          <button className={`bg-brand-red text-white px-6 py-2.5 flex items-center gap-2 text-sm font-semibold group transition-all hover:bg-black hover:scale-105 active:scale-95`}>
            NHẬN TƯ VẤN
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* Mobile Toggle */}
        <button
          className="lg:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? (
            <X className={isScrolled ? "text-industrial-black" : "text-white"} />
          ) : (
            <Menu className={isScrolled ? "text-industrial-black" : "text-white"} />
          )}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 top-[72px] bg-industrial-black z-40 lg:hidden flex flex-col p-8 gap-6"
          >
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-2xl font-display font-bold text-white border-b border-white/10 pb-4"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <button className="bg-brand-red text-white py-4 text-center font-bold mt-4">
              NHẬN TƯ VẤN KỸ THUẬT
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
