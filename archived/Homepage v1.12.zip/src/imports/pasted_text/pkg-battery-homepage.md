Bạn là World-class Creative Director, Senior UI/UX Designer, B2B Web Strategist, Art Director, Motion Director, Vietnamese Enterprise Copywriting Expert và Conversion-focused Content Architect chuyên thiết kế homepage đẳng cấp quốc tế cho doanh nghiệp công nghiệp, kỹ thuật, năng lượng, tự động hóa và giải pháp B2B cao cấp.

Bạn phải làm việc như một studio lớn hoặc agency hàng đầu thế giới:

hiểu chiến lược thương hiệu
hiểu hành vi khách hàng B2B
hiểu conversion cho website công nghiệp
hiểu cách tạo cảm giác “công ty có năng lực thật”
hiểu cách phối hợp giữa layout, typography, image direction, motion, grid, UI system, background system, interaction và storytelling
hiểu cách tạo một homepage vừa có đẳng cấp thị giác, vừa có hiệu quả thương mại

Bạn không được tạo ra website kiểu template phổ thông. Bạn phải tạo ra một homepage có cảm giác:

được art direct kỹ lưỡng
có layout được thiết kế riêng từng section
có chiều sâu thị giác
có khí chất thương hiệu mạnh
có độ tin cậy cao
có khả năng cạnh tranh quốc tế
NHIỆM VỤ

Thiết kế toàn bộ homepage hoàn chỉnh cho PKG Battery — doanh nghiệp B2B chuyên:

pin lithium công nghiệp
bộ sạc / trạm sạc
giải pháp pin theo ứng dụng
tư vấn kỹ thuật
OEM / ODM
giải pháp cho doanh nghiệp, nhà máy, logistics, xe nâng điện, AGV/robot, ESS
phục vụ khách hàng Việt Nam, FDI và đối tác quốc tế

Homepage phải thể hiện PKG Battery đồng thời là:

nhà cung cấp pin lithium công nghiệp
đơn vị cung cấp giải pháp pin + sạc + tư vấn kỹ thuật
đối tác kỹ thuật có thể tùy biến theo nhu cầu
doanh nghiệp phục vụ nhiều ứng dụng công nghiệp khác nhau
đơn vị có khả năng hỗ trợ doanh nghiệp trong nước, FDI và OEM/ODM quốc tế

Tuyệt đối không được thể hiện PKG Battery như một công ty chỉ bán hàng thương mại.

MỤC TIÊU ƯU TIÊN CỦA HOMEPAGE

Theo thứ tự ưu tiên:

Tăng uy tín thương hiệu với khách hàng/đối tác B2B
Giúp người xem hiểu nhanh các dòng sản phẩm và ứng dụng
Tăng lead tư vấn từ doanh nghiệp tại Việt Nam
Thu hút đối tác OEM/ODM/quốc tế
CTA CHÍNH

Homepage phải dẫn về CTA chính:

Nhận tư vấn kỹ thuật

CTA phụ có thể gồm:

Xem nhóm giải pháp
Xem danh mục sản phẩm
Gửi yêu cầu dự án
Trao đổi về OEM / ODM
Xem hồ sơ năng lực
Xem hệ thống đại lý

Không ưu tiên:

mua ngay
giá rẻ
bán lẻ
KHÁCH HÀNG MỤC TIÊU
Nhóm ưu tiên cao
doanh nghiệp sử dụng pin công nghiệp
quản lý vận hành
trưởng phòng kỹ thuật
trưởng bộ phận mua hàng
chủ doanh nghiệp
nhà máy
kho vận
logistics
khu công nghiệp
resort / khu du lịch
đơn vị vận hành xe điện chuyên dụng
doanh nghiệp cần AGV / robot
đơn vị có nhu cầu ESS
Nhóm mở rộng
doanh nghiệp FDI tại Việt Nam
đối tác OEM / ODM
đối tác quốc tế
PHẠM VI SẢN PHẨM / GIẢI PHÁP BẮT BUỘC PHẢI THỂ HIỆN RÕ

Homepage phải có 5 dòng sản phẩm / giải pháp chính thể hiện rất rõ, có card riêng, có hình riêng, có CTA “Xem thêm” hoặc “Xem chi tiết”:

Pin Lithium cho Xe Nâng Điện
Pin Lithium cho Xe Điện Du Lịch
Pin cho Xe AGV / Robot
Bộ Sạc – Trạm Sạc
Hệ thống Pin Lưu Trữ Năng Lượng ESS

Ngoài ra phải có thêm khối OEM / ODM / Tùy chỉnh giải pháp như một capability riêng, không được chôn quá sâu.

LOGIC CHIẾN LƯỢC BẮT BUỘC

Homepage phải đi theo logic:

Trust first → Clarity second → Conversion third

Nghĩa là:

đầu tiên phải tạo cảm giác doanh nghiệp có năng lực thật
sau đó giúp người xem hiểu nhanh PKG làm gì, có gì, phục vụ ai
tiếp theo mới đẩy sâu vào sản phẩm, ứng dụng, trust signals, OEM/ODM, doanh nghiệp, đại lý, chứng chỉ
cuối cùng mới chốt CTA
ĐỊNH HƯỚNG THIẾT KẾ TỔNG THỂ
Màu sắc thương hiệu

Bảng màu chủ đạo:

Trắng
Đen
Đỏ thương hiệu

Đỏ dùng như màu nhấn quyền lực, có chủ đích. Không lạm dụng.

Cảm giác màu:
sạch
mạnh
cao cấp
công nghệ
hiện đại
đáng tin
Color rhythm tổng thể

Toàn bộ website phải đa số là sáng:

khoảng 75% section sáng
khoảng 15% section dark
khoảng 10% là 1–2 section đỏ statement thật ấn tượng

Section đỏ không được làm phẳng, rẻ hoặc gắt. Phải xử lý như brand-power sections với:

red gradient depth
dark red shadow zones
linework kỹ thuật
subtle glow
cinematic layering
typography mạnh
ambient motion tinh tế
Mục tiêu cảm xúc khi mở website

Người dùng phải cảm thấy:

doanh nghiệp có năng lực thật
công nghệ pin hiện đại
thương hiệu B2B cao cấp
tư duy kỹ thuật mạnh
quy mô và sự tự tin
chuẩn quốc tế
PHONG CÁCH THỊ GIÁC

Theo hướng:

công nghiệp cao cấp hiện đại
tối giản cao cấp
kỹ thuật tinh tế
hình khối sắc nét
doanh nghiệp hiện đại
mạnh nhưng kiểm soát
sang trọng tối giản

Website phải có cảm giác:

đắt tiền
có director đứng sau
được thiết kế riêng
không phải template
không phải theme WordPress
không phải web công nghiệp cũ
TRIẾT LÝ LAYOUT

Không làm kiểu chia block xếp dọc nhàm chán.

Ưu tiên:

bố cục sáng tạo có kiểm soát
bất đối xứng hợp lý
có layer foreground / midground / background
khoảng trắng thông minh
section nào cũng có điểm nhấn riêng
có rhythm rõ ràng giữa section sáng và tối
có section full-bleed
có section contained
có section overlap nhẹ
có section dùng editorial composition
có section dùng technical dashboard style
có section dùng image-first composition
có section dùng split-layout nhưng phải cao cấp

Mỗi section phải mang cảm giác được custom design riêng.

TYPOGRAPHY

Dùng sans-serif cao cấp.

Yêu cầu:

headline mạnh, rõ, tự tin
body text dễ đọc
hierarchy rõ
spacing đẹp
tracking tinh chỉnh
line-height kiểm soát tốt
text blocks thoáng
label nhỏ mang tinh thần kỹ thuật hiện đại
không được cảm giác font rẻ tiền

Nên có hệ:

Hero display
Section headline
Eyebrow label
Body large
Body regular
Caption / meta
Stats number style
CONTENT / COPYWRITING SYSTEM (RẤT QUAN TRỌNG)

Nội dung website phải được viết với tư duy của người có nhiều năm làm việc cho các công ty top đầu Việt Nam về thương hiệu, chiến lược nội dung, website doanh nghiệp và marketing B2B.

Người viết phải hiểu:

cách người Việt đọc website doanh nghiệp
tâm lý chủ doanh nghiệp Việt Nam
mindset trưởng phòng kỹ thuật / mua hàng / vận hành
hành vi ra quyết định B2B tại Việt Nam
nỗi lo thật phía sau nhu cầu báo giá hoặc nhu cầu tìm nhà cung cấp
Ngôn ngữ bắt buộc
thuần Việt
đúng giọng người Việt
tự nhiên
chuyên nghiệp
hiện đại
có chiều sâu
không dịch cứng từ tiếng Anh
không sáo rỗng kiểu brochure
không khoa trương rẻ tiền
không dùng câu chữ “corporate English dịch sang tiếng Việt”
Insight bắt buộc phải phản ánh
khách hàng không chỉ mua pin, họ mua sự yên tâm
họ cần đơn vị hiểu bài toán vận hành thật
họ sợ downtime, bảo trì, chọn sai giải pháp
họ cần đối tác phản hồi nhanh, làm được việc
họ tin doanh nghiệp có hệ thống, có người thật, có năng lực thật
họ muốn thông điệp rõ, thẳng, không vòng vo
họ quan tâm độ ổn định, hỗ trợ kỹ thuật, tính tương thích, tuổi thọ, chi phí dài hạn
Giọng văn
chuẩn người Việt
chắc chắn
hiện đại
hiểu ngành
có insight
phù hợp bối cảnh doanh nghiệp Việt Nam
đủ tốt để nói chuyện với khách hàng lớn, FDI và đối tác quốc tế
HÌNH ẢNH

Ưu tiên hình ảnh mạnh về công nghiệp:

hệ thống pin
nhà máy hiện đại
xe nâng điện
AGV / robot
trạm sạc
cận cảnh cell, module, tủ pin, chi tiết kỹ thuật
dây chuyền vận hành
kỹ sư làm việc
kho vận / nhà xưởng / môi trường công nghiệp cao cấp
ảnh doanh nghiệp thật
ảnh đội ngũ, nhà máy, năng lực, xưởng, quy trình test
ảnh ứng dụng thực tế

Có thể dùng:

cinematic lighting
nền tối kỹ thuật
texture kim loại tinh tế
motion blur nhẹ
overlay đỏ tinh tế
khung hình học hiện đại

Cho phép AI tạo ảnh nếu chưa có ảnh thật, nhưng ảnh phải theo tinh thần:

industrial premium
realistic
corporate luxury
không stock rẻ
không sci-fi lố
không giả CGI rẻ tiền

AI phải tạo nhiều ảnh, không chỉ 1 ảnh đơn lẻ. Phải dùng:

ảnh nền section
ảnh panel
ảnh crop nghệ thuật
ảnh cụm sản phẩm
ảnh tổ hợp công nghiệp
ảnh close-up kỹ thuật
ảnh doanh nghiệp
ảnh layout collage cao cấp
ADVANCED BACKGROUND / IMAGE / AMBIENT SYSTEM

Mỗi section không được có cảm giác phẳng hoặc chết.

Mỗi section phải có hệ nền được thiết kế như một hệ thống gồm:

Base background
Image layer
Gradient overlay
Pattern / line / geometry layer
Ambient motion layer
Content layer
Ảnh nền phải có vai trò

Ảnh nền không được chỉ là “ảnh đẹp”. Ảnh nền phải:

tạo trust
tăng cảm giác quy mô
gợi môi trường ứng dụng
làm nền cho thông điệp
tạo cinematic depth
dẫn mắt theo bố cục
Text readability trên ảnh nền

Không đặt text trực tiếp lên ảnh thô. Phải xử lý bằng:

side gradient
bottom gradient
radial spotlight
multi-layer gradient
blur nhẹ vùng sau text
darkening selective
vignette tinh tế
masking bằng shape
panel nền semi-opaque nếu cần
Các loại gradient overlay nên dùng
Side gradient
dùng cho hero
dùng cho CTA cuối
dùng cho OEM/ODM
Bottom gradient
dùng cho product cards
dùng cho news cards
dùng cho application cards
Radial spotlight
dùng cho hero
pin close-up
ESS / charger product showcase
Multi-layer gradient
dark layer để giữ text
red accent layer cực nhẹ
vignette để khóa bố cục

Không dùng:

gradient rẻ tiền
excessive gradient
blend lòe loẹt
đỏ saturate lớn
màu tech startup generic
LINE-BASED ELEMENT SYSTEM / ELEMENT NỀN KỸ THUẬT

Đây là phần rất quan trọng.

Các element nền không được vô nghĩa. Chúng phải gợi cảm giác:

mạch điện
routing kỹ thuật
dòng năng lượng
sơ đồ hệ thống
tín hiệu
topology
network
system intelligence

Nhưng phải theo hướng cao cấp, hiện đại, tiết chế.

Dùng các loại element sau
Circuit-inspired routing lines

Line mảnh, chia nhánh, có góc kỹ thuật, như mạch điện hoặc routing path.

Energy flow lines

Line mô phỏng dòng năng lượng chạy trong hệ thống.

Technical nodes / node clusters

Các node nhỏ như điểm kết nối, sensor point, signal point.

Technical paths

Các line dẫn mắt giữa image, panel, metric, diagram.

Precision grid

Lưới kỹ thuật rất mờ, spacing rộng, không dày.

Geometric frames

Khung hình học mảnh, offset frame, cropped angular border, outline panel.

Contour lines

Line như vùng phủ / địa hình / field mapping, rất hợp cho dealer map và network.

Signal markers

Các chấm đỏ nhỏ hoặc marker cực tinh tế dùng để đánh dấu điểm nhấn.

Section dividers kiểu năng lượng

Divider line giữa các section có thể là line tín hiệu rất mảnh thay cho divider thường.

Không dùng line chỉ để trang trí vô nghĩa.

PATTERN / BACKGROUND / GRAPHIC SYSTEM

Có thể dùng chọn lọc:

lưới kỹ thuật tinh tế
line graphic hiện đại
mô phỏng dòng năng lượng
khung hình học
texture công nghiệp nhẹ
pattern tối giản
mask geometry
red signal lines
precision grid
contour field lines
soft reflection slabs
technical mesh
geometric slabs
subtle industrial grain

Tất cả phải:

tinh tế
premium
không rối
không generic kiểu tech startup
MOTION / HIỆU ỨNG

Dùng motion cao cấp, mượt và có kiểm soát.

Bao gồm:

reveal animation mượt
parallax nhẹ
hover tinh tế
transition mượt
counter animation
video nền cinematic loop
micro interaction cao cấp
background element motion cực nhẹ
moving light sweep nhẹ
line flow animation mô phỏng dòng năng lượng
floating panel motion rất nhỏ
image mask reveal
section transition thông minh giữa nền sáng / nền tối
Ambient motion system bổ sung

Các motion nền phải rất tinh tế, gần như chỉ cảm nhận sau 1–2 giây nhìn:

circuit line pulse
signal flow chạy chậm
gradient breathing
light sweep
floating panels drift
blur blobs drift
texture shift
node pulse
subtle parallax
image layer drift nhẹ
line draw nhẹ ở các section kỹ thuật

Không dùng:

animation lòe loẹt
glow nặng
kiểu startup màu mè
motion gây mệt
bounce
sci-fi game UI
BLUR / GLASS / DEPTH STYLE

Hiệu ứng blur kiểu Apple / iPhone chỉ được dùng rất tinh tế ở một số chỗ, không lạm dụng.

Có thể dùng ở:

floating info panel trong hero
trust detail panel
CTA block
modal chứng chỉ
floating glass cards rất chọn lọc
overlay card khi hover vào logo hoặc map point

Không được biến toàn website thành glassmorphism.

UI COMPONENTS
Button
mạnh mẽ
premium
sắc nét
dứt khoát
hover tinh tế nhưng rõ
Cards
tối giản
thanh lịch
có chiều sâu nhẹ
không bo tròn trẻ con
không shadow rẻ tiền
Form
sạch
enterprise-grade
chuyên nghiệp
có trust
Navigation
thoáng
hiện đại
đắt tiền
dễ dùng
sticky header tinh tế
dropdown đẹp
Stats / numbers
hoành tráng
rõ
cinematic
có thể đi kèm ảnh nền nhẹ
có typography đủ mạnh
TUYỆT ĐỐI TRÁNH

Không thiết kế giống:

theme WordPress rẻ tiền
web công ty công nghiệp cũ kỹ
bootstrap phổ thông
block lặp lại đơn điệu
layout chật chội
landing page startup màu mè
style địa phương giá rẻ
quá nhiều gradient rẻ tiền
icon kiểu minh họa quá cartoon
infographic rối
CẤU TRÚC HOMEPAGE HOÀN CHỈNH BẮT BUỘC PHẢI CÓ

Homepage phải có đầy đủ các section dưới đây, theo thứ tự chiến lược hợp lý. Không được bỏ thiếu section.

SECTION 1 — HEADER / NAVIGATION
Mục tiêu
tạo cảm giác premium ngay từ thanh đầu
định vị nhanh đây là doanh nghiệp B2B nghiêm túc
điều hướng rõ ràng
Thành phần
logo PKG Battery
menu chính:
Giải pháp
Sản phẩm
Ứng dụng
OEM / ODM
Về PKG Battery
Tin tức / Kiến thức
Đại lý
Liên hệ
CTA header:
Nhận tư vấn kỹ thuật
có thể có language switch nếu phù hợp:
VI / EN
sticky khi scroll
trạng thái header chuyển tinh tế theo nền section
Thiết kế
nền header có thể trong suốt ở hero rồi solid dần khi scroll
menu spacing đẹp
nav hover sang
CTA nổi bật nhưng không gắt
SECTION 2 — HERO ĐẲNG CẤP QUỐC TẾ
Mục tiêu
tạo trust cực mạnh trong 3–5 giây
khẳng định PKG là đối tác giải pháp pin lithium công nghiệp cao cấp
cho thấy phạm vi ứng dụng rộng
đẩy CTA
Hướng layout

Không làm hero text trái ảnh phải đơn giản.

Hero nên có:

bố cục bất đối xứng nhiều lớp
ảnh nền hoặc video nền cinematic
1 vùng headline cực mạnh
1 hoặc 2 panel phụ floating
1 cụm visual thể hiện pin + ứng dụng + môi trường công nghiệp
các element nền chuyển động nhẹ
overlay kỹ thuật rất tinh tế
có cảm giác flagship homepage
Hướng hình ảnh

Có thể tạo 1 cảnh hero composite gồm:

xe nâng điện đang vận hành
AGV trong nhà máy hiện đại
hệ thống tủ pin ESS
bộ sạc / trạm sạc
close-up pin lithium / module
ánh sáng đỏ tinh tế
nền công nghiệp cao cấp
Nội dung

Eyebrow label: GIẢI PHÁP PIN LITHIUM CÔNG NGHIỆP

Headline: Đối tác pin lithium & sạc toàn diện cho doanh nghiệp

Subheadline: Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp vận hành ổn định, giảm downtime và tối ưu chi phí sở hữu dài hạn.

Body text:
PKG Battery cung cấp giải pháp pin lithium công nghiệp cho xe nâng điện, AGV/robot, xe điện du lịch, hệ thống lưu trữ năng lượng và nhiều ứng dụng doanh nghiệp khác, với định hướng tư vấn kỹ thuật, tùy chỉnh theo nhu cầu và đồng hành triển khai thực tế.

CTA chính: Nhận tư vấn kỹ thuật
CTA phụ: Xem nhóm giải pháp

Panel phụ trong hero

Nên có các module nổi nhẹ như:

5 nhóm giải pháp chính
OEM / ODM available
Hỗ trợ doanh nghiệp Việt Nam / FDI / quốc tế
[Cần xác nhận với PKG Battery] các con số headline trust nếu có
Motion
video nền loop cinematic
headline reveal
line animation nhẹ
floating panel drift rất nhẹ
CTA hover premium
background energy lines chuyển động rất nhẹ
blur panel depth
light sweep cực nhẹ
SECTION 3 — TRUSTED BY INDUSTRY LEADERS EXPERIENCE
Mục tiêu
tăng trust ngay sau hero
tạo cảm giác quy mô
chứng minh PKG không phải công ty nhỏ lẻ
biến logo thành proof asset, không chỉ là logo wall
Layer 1 — Headline & statement

Headline: Đồng hành cùng doanh nghiệp trong nhiều môi trường vận hành trọng yếu

Subheadline:
PKG Battery hiện diện trong các bối cảnh vận hành như logistics, nhà máy, kho vận, tự động hóa, xe điện chuyên dụng và lưu trữ năng lượng, với định hướng giải pháp, hỗ trợ kỹ thuật và hợp tác dài hạn.

Layer 2 — SVG Logo Marquee cao cấp
2 hàng logo SVG chạy ngang ngược chiều
tốc độ chậm, premium
fade mask ở hai mép
spacing rộng
grayscale mặc định
có thể xen kẽ lớn/nhỏ để nhịp đẹp hơn
Hover logo
logo sáng rõ / full opacity
dừng marquee của hàng đó
scale nhẹ
underline đỏ mảnh
glow cực nhẹ phía sau
panel detail cập nhật theo logo đang active
Layer 3 — Partnership Detail Panel

Khi hover hoặc click logo, hiện panel:

tên doanh nghiệp / đối tác
ngành hoạt động
từ năm hợp tác [Cần xác nhận]
hợp tác nội dung gì [Cần xác nhận]
nhóm giải pháp liên quan
khu vực / phạm vi triển khai
tag: Forklift / AGV / ESS / OEM / Dealer / Technical Support
CTA phụ: Xem giải pháp liên quan
Layer 4 — Filter tabs
All
Enterprise
OEM / ODM
Dealers
Technical Partners
Layer 5 — Featured trust cards

3 card nhỏ:

Khách hàng doanh nghiệp
Đối tác OEM
Mạng lưới phân phối
Thiết kế
không làm strip logo phẳng
phải có typography hỗ trợ
divider line kỹ thuật
subtle background grid
detail panel sang, usable, có blur nhẹ nếu cần
Ghi chú xác thực
logo đối tác thật → [Cần xác nhận với PKG Battery]
năm hợp tác / nội dung hợp tác → [Cần xác nhận với PKG Battery]
SECTION 4 — PAIN POINT / VẤN ĐỀ VẬN HÀNH
Mục tiêu
cho thấy PKG hiểu bài toán doanh nghiệp
chuyển từ trust sang relevance
Nội dung

Headline: Downtime, bảo trì và chi phí ẩn đang làm vận hành kém hiệu quả hơn bạn nghĩ

Subheadline:
Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện năng mà còn mất thời gian, năng suất và khả năng kiểm soát chi phí dài hạn.

Các pain points
thời gian sạc dài
downtime ảnh hưởng vận hành
pin xuống cấp nhanh
chi phí bảo trì cao
khó đảm bảo an toàn
cấu hình không phù hợp thiết bị
khó tối ưu TCO nếu chỉ nhìn giá đầu tư ban đầu
Layout
1 composition mạnh, không đều nhau
typography lớn ở 1 bên
các module pain point ở nhiều kích thước khác nhau
có thể 1 ảnh nền tối kỹ thuật phía sau
có motion line nền cực nhẹ
SECTION 5 — GIỚI THIỆU DOANH NGHIỆP / ABOUT PKG BATTERY
Mục tiêu
có section giới thiệu doanh nghiệp rõ ràng
giúp khách hàng hiểu PKG là ai
tăng chiều sâu thương hiệu
Nội dung

Headline: PKG Battery – đối tác giải pháp năng lượng lithium công nghiệp cho doanh nghiệp hiện đại

Body:
PKG Battery được định hướng như một doanh nghiệp B2B chuyên pin lithium công nghiệp, bộ sạc, trạm sạc và giải pháp kỹ thuật theo ứng dụng. Không chỉ cung cấp sản phẩm, PKG Battery hướng tới việc đồng hành cùng doanh nghiệp trong việc lựa chọn cấu hình phù hợp, tối ưu hiệu quả vận hành và hỗ trợ triển khai thực tế trong nhiều môi trường công nghiệp khác nhau.

Nội dung phụ nên có
định vị doanh nghiệp
năng lực phục vụ đa ngành
tư duy kỹ thuật
định hướng phục vụ khách hàng Việt Nam, FDI và quốc tế
khả năng đồng hành lâu dài
Hình ảnh

Phải có cụm hình doanh nghiệp:

văn phòng / đội ngũ
nhà máy / xưởng / kho / khu test
kỹ sư làm việc
cận cảnh sản phẩm trong môi trường thật
Layout

Không làm 1 ảnh + 1 đoạn text đơn giản. Nên làm:

editorial collage
2–3 ảnh xếp chồng có kiểm soát
typography lớn
quote thương hiệu
shape geometry nhẹ
background sạch sang
SECTION 6 — GIẢI PHÁP TỔNG THỂ CỦA PKG BATTERY
Mục tiêu
khẳng định tư duy giải pháp
không chỉ bán pin
Nội dung

Headline: Từ pin đến giải pháp vận hành hoàn chỉnh

Subheadline:
PKG Battery xây dựng giải pháp pin lithium công nghiệp theo bài toán thực tế của doanh nghiệp — từ khảo sát nhu cầu, cấu hình pin và sạc phù hợp, đến triển khai, hỗ trợ kỹ thuật và đồng hành vận hành.

Khối nội dung
Đánh giá nhu cầu vận hành
Cấu hình pin và bộ sạc phù hợp
Tùy chỉnh theo ứng dụng và thiết bị
Tích hợp triển khai thực tế
Hỗ trợ kỹ thuật và hậu mãi
Thiết kế
sơ đồ hệ sinh thái
đường line kết nối các node
panel kỹ thuật cao cấp
có image support
có motion flow line nhẹ
SECTION 7 — 5 DÒNG SẢN PHẨM / GIẢI PHÁP CHÍNH
Mục tiêu
phải thấy 5 dòng sản phẩm chính rõ ràng
mỗi dòng có hình, mô tả, CTA riêng
Cấu trúc bắt buộc

Mỗi card / module phải có:

hình ảnh riêng
tên dòng sản phẩm
mô tả ngắn
ứng dụng
CTA:
Xem thêm
Xem chi tiết
5 dòng sản phẩm

1. Pin Lithium cho Xe Nâng Điện
Giải pháp pin lithium tối ưu cho xe nâng điện với khả năng sạc nhanh, giảm bảo trì và hỗ trợ cường độ vận hành cao trong kho vận, logistics và nhà máy.
CTA: Xem chi tiết

2. Pin Lithium cho Xe Điện Du Lịch
Thiết kế cho xe điện du lịch, buggy và phương tiện chuyên dụng cần độ ổn định, tuổi thọ cao và trải nghiệm vận hành bền bỉ.
CTA: Xem chi tiết

3. Pin cho Xe AGV / Robot
Giải pháp năng lượng cho hệ thống tự động hóa cần độ ổn định, độ chính xác, tính tương thích và khả năng tích hợp kỹ thuật cao.
CTA: Xem chi tiết

4. Bộ Sạc – Trạm Sạc
Giải pháp sạc đồng bộ giúp tối ưu hiệu suất pin, rút ngắn thời gian chờ và phù hợp nhiều môi trường vận hành công nghiệp.
CTA: Xem chi tiết

5. Hệ thống Pin Lưu Trữ Năng Lượng ESS
Giải pháp lưu trữ năng lượng cho doanh nghiệp cần tăng tính chủ động, ổn định nguồn điện và nâng cao hiệu quả vận hành dài hạn.
CTA: Xem chi tiết

Layout

Không dùng lưới card đơn điệu. Dùng:

composition showcase
có section intro + 5 module sáng tạo
module lớn nhỏ xen kẽ
có ảnh nền phụ
có dark/light rhythm
có hover sâu, ảnh zoom nhẹ
SECTION 8 — OEM / ODM / TÙY CHỈNH GIẢI PHÁP
Mục tiêu
giúp PKG nói chuyện với đối tác quốc tế và doanh nghiệp cần custom solution
Nội dung

Headline: OEM / ODM và giải pháp tùy chỉnh theo yêu cầu kỹ thuật

Subheadline:
PKG Battery hướng tới khả năng hợp tác với doanh nghiệp và đối tác kỹ thuật cần cấu hình pin lithium theo yêu cầu, từ kích thước, điện áp, ứng dụng đến phương án tích hợp trong môi trường vận hành thực tế.

Bullet points
cấu hình theo ứng dụng
tùy chỉnh điện áp / dung lượng / form factor
hỗ trợ tích hợp hệ thống
định hướng làm việc với OEM / ODM / FDI
hỗ trợ kỹ thuật trong quá trình phát triển giải pháp
CTA
Trao đổi về OEM / ODM
Gửi yêu cầu dự án
Layout
dark premium section hoặc red-dark statement section
ảnh close-up kỹ thuật + blueprint style overlays
line graphics
shape frame mảnh
technical luxury
circuit-inspired line motion
node pulse rất nhẹ
blur depth tinh tế
Ghi chú xác thực
phạm vi OEM / ODM thực tế → [Cần xác nhận với PKG Battery]
SECTION 9 — ỨNG DỤNG / INDUSTRIES
Mục tiêu
giúp người xem hiểu nhanh PKG phục vụ ai
tăng clarity
Nội dung

Headline: Giải pháp cho nhiều bối cảnh vận hành công nghiệp

Các nhóm ứng dụng
Logistics & kho vận
Nhà máy & sản xuất
AGV / Robot / tự động hóa
Resort / khu du lịch / mobility
Khu công nghiệp
Hệ thống lưu trữ năng lượng
Xe điện công nghiệp / chuyên dụng
Layout
image-rich section
có thể dùng mosaic
hoặc horizontal narrative panels
mỗi ngành có ảnh / icon / tag
hover reveal chi tiết
SECTION 10 — VÌ SAO CHỌN PKG BATTERY
Mục tiêu
chốt điểm khác biệt
Nội dung

Headline: Lý do doanh nghiệp chọn PKG Battery cho bài toán năng lượng công nghiệp

Các điểm chính
Giải pháp thiết kế theo nhu cầu vận hành
Tư duy kỹ thuật và khả năng đồng hành triển khai
Tối ưu uptime, hiệu quả và chi phí dài hạn
Phục vụ nhiều ứng dụng công nghiệp và logistics
Khả năng tùy chỉnh giải pháp
Định hướng phục vụ khách hàng doanh nghiệp, FDI và đối tác kỹ thuật
Layout
section cô đọng nhưng mạnh
typography lớn + USP blocks
không checklist nhàm chán
SECTION 11 — CAPABILITY THEATER / NĂNG LỰC / CHỨNG CHỈ / SỐ LIỆU
Mục tiêu
hoành tráng hơn, nhiều bằng chứng hơn
không đơn điệu
không làm kiểu 4 ô đếm số đơn giản
phải là một “proof of capability experience”
Layer A — Hero metric

Một chỉ số hoặc một tuyên ngôn lớn làm tâm điểm.

Ví dụ:

8+
Đại lý toàn quốc
[Cần xác nhận với PKG Battery]

Layer B — Secondary metrics

Xung quanh hero metric, trình bày các chỉ số khác với hierarchy mạnh:

số năm kinh nghiệm
số dự án / khách hàng / hệ thống
số đại lý / điểm phân phối
số nhóm ứng dụng phục vụ
vùng hoạt động
5 nhóm giải pháp
OEM / ODM capability

Tất cả số liệu: [Cần xác nhận với PKG Battery]

Layer C — Interpretation

Mỗi metric nên có 1–2 câu giải nghĩa ngắn, để khách hàng hiểu “con số này có ý nghĩa gì”.

Layer D — Coverage map
bản đồ Việt Nam stylized
marker đại lý
hover info panel
route lines / node system
Layer E — Certification gallery

Phải có section trình bày ảnh chứng chỉ dạng A4:

ảnh scan chứng chỉ / tiêu chuẩn
trình bày sang, có lightbox hoặc expand
có caption
có CTA xem thêm

Ví dụ:

ISO
IEC
test report
compliance documents
[Cần xác nhận với PKG Battery]
Layer F — Logo đối tác / khách hàng / hệ sinh thái
grid logo đẹp
monochrome xử lý cao cấp
có hover nhẹ
có thể chia:
đối tác
khách hàng
mạng lưới
[Cần xác nhận với PKG Battery]
Layer G — Ảnh doanh nghiệp / nhà máy / đội ngũ / năng lực

Phải có gallery hoặc strip ảnh:

nhà máy
đội ngũ
quy trình test
trưng bày sản phẩm
kho / xưởng
kỹ sư
dự án thực tế
Layout
không gom vào 1 block chật
chia thành nhiều tầng
stats + ảnh + chứng chỉ + logo + map
trình bày sang như hồ sơ năng lực cao cấp
typography mạnh
cinematic but controlled
line-based motion và spotlight tinh tế
Motion
counter animation
line pulse
map reveal
certificate slide
light sweep
subtle line routing motion
SECTION 12 — QUY TRÌNH TƯ VẤN VÀ TRIỂN KHAI
Mục tiêu
giảm rủi ro cảm nhận
cho thấy làm việc bài bản
Nội dung

Headline: Quy trình tư vấn rõ ràng, triển khai có kiểm soát

Steps
Tiếp nhận nhu cầu và đánh giá ứng dụng
Phân tích vận hành và đề xuất cấu hình phù hợp
Thiết kế giải pháp pin / sạc / tích hợp
Triển khai và hướng dẫn vận hành
Đồng hành kỹ thuật và hậu mãi
Layout
timeline hiện đại
motion line
number typography lớn
icon tối giản cao cấp
SECTION 13 — BẢN ĐỒ ĐẠI LÝ / HỆ THỐNG PHÂN PHỐI VIỆT NAM
Mục tiêu
tăng trust về độ phủ
cho thấy mạng lưới hiện diện
Nội dung

Headline: Mạng lưới đại lý và phân phối trên toàn Việt Nam

Thiết kế
bản đồ Việt Nam stylized cao cấp
đánh dấu 8 điểm hiện tại
mỗi điểm click / hover ra:
tên đại lý
thành phố / khu vực
thông tin liên hệ ngắn
CTA xem chi tiết
hệ thống phải mở rộng được khi tăng thêm đại lý
Yêu cầu
bản đồ không làm kiểu infographic rẻ tiền
phải premium, tối giản, rõ
có motion hover
có active states
có thể có danh sách đại lý đi kèm bên cạnh bản đồ
dùng contour lines, node pulse, region glow rất nhẹ nếu phù hợp
Ghi chú xác thực
dữ liệu 8 đại lý cụ thể → [Cần xác nhận với PKG Battery]
SECTION 14 — BÀI VIẾT / TIN TỨC / KIẾN THỨC KỸ THUẬT
Mục tiêu
tăng SEO
tăng trust
tăng chiều sâu chuyên gia
chứng minh PKG có hiểu biết kỹ thuật và chia sẻ được kiến thức
Nội dung

Headline: Tin tức, kiến thức kỹ thuật và cập nhật từ PKG Battery

Nhóm bài viết nên hiển thị
kiến thức về pin lithium công nghiệp
so sánh lithium và giải pháp truyền thống
bài viết về sạc, BMS, an toàn, vòng đời
ứng dụng pin cho xe nâng điện
xu hướng AGV / robot / tự động hóa
giải pháp ESS cho doanh nghiệp
tin doanh nghiệp / hoạt động / sự kiện / triển lãm
Thiết kế
editorial cards cao cấp
có ảnh thumbnail lớn
meta info đẹp
hover premium
CTA:
Xem tất cả bài viết
Đọc thêm
Layout
1 bài featured lớn
2–4 bài phụ
có rhythm đẹp
không card blog phổ thông
SECTION 15 — CASE STUDY / APPLICATION PROOF / DỰ ÁN TIÊU BIỂU
Mục tiêu
chuyển từ claim sang proof
Nội dung

Nếu có case study thật:

khách hàng / ngành
bài toán
giải pháp
kết quả

Nếu chưa có đủ case công khai:

dùng section “Các mô hình ứng dụng tiêu biểu”
trình bày theo application proof

Headline: Giải pháp được xây dựng cho các bối cảnh vận hành thực tế

Layout
premium editorial case cards
có ảnh lớn
có kết quả highlight
có quote nếu có
Ghi chú xác thực
case study thật → [Cần xác nhận với PKG Battery]
SECTION 16 — CTA CUỐI / CONTACT BLOCK
Mục tiêu
chốt lead
mạnh, sạch, cao cấp
Nội dung

Headline: Nhận tư vấn kỹ thuật cho bài toán pin lithium của doanh nghiệp bạn

Subheadline:
Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu vận hành, đề xuất cấu hình phù hợp và định hướng giải pháp tối ưu hơn cho chi phí dài hạn.

CTA
Nhận tư vấn kỹ thuật
Gửi yêu cầu dự án
Trao đổi về OEM / ODM
Form
Họ tên
Công ty
Số điện thoại
Email
Nhu cầu / ứng dụng
Gửi yêu cầu
Layout
dark premium hoặc ultra-clean light block
có contact options
không làm form rẻ tiền
có gradient mạnh hơn để text rất rõ nếu dùng ảnh nền
có blur panel tinh tế nếu cần
có line routing / signal line nhẹ
SECTION 17 — FOOTER
Nội dung
logo
giới thiệu ngắn về PKG Battery
menu nhanh
danh mục sản phẩm
giải pháp
ứng dụng
OEM / ODM
tin tức
đại lý
liên hệ
mạng xã hội nếu có
thông tin công ty
copyright
legal links nếu cần
ART DIRECTION TỔNG THỂ CHO TỪNG TẦNG
Tầng 1 — Brand confidence

Thể hiện qua:

hero mạnh
typography chắc
trusted by experience
enterprise visuals
Tầng 2 — Technical capability

Thể hiện qua:

giải pháp tổng thể
OEM/ODM
capability theater
chứng chỉ
stats
doanh nghiệp / nhà máy / đội ngũ / quy trình
Tầng 3 — Application clarity

Thể hiện qua:

5 dòng sản phẩm chính
industries
application proof
bài viết kỹ thuật
Tầng 4 — Conversion

Thể hiện qua:

CTA xuyên suốt
process section
contact block
CTA cuối
GRID / SPACING SYSTEM
Grid
desktop 12 hoặc 16 cột
section có thể phá grid nhẹ để tạo cảm giác designer-grade
mobile vẫn premium
Spacing
rộng
có khoảng thở
section padding lớn
nội dung không chật
nhịp giãn rõ
dark/light sections luân phiên có chủ ý
Section rhythm
Hero: rộng, cinematic
Trusted by: gọn nhưng giàu trải nghiệm
Pain point: nén vừa
About enterprise: mở
Solutions: có hệ thống
5 products: giàu hình ảnh
OEM: mạnh, dark hoặc red-dark
Industries: linh hoạt
Capability theater: hoành tráng
Dealer map: rõ, thoáng
News: editorial
CTA cuối: gọn, dứt khoát
IMAGE GENERATION DIRECTION CHO AI

AI được phép tạo ảnh cho từng section. Phải tạo nhiều ảnh chứ không chỉ 1 ảnh hero.

Danh sách ảnh nên tạo
Hero composite industrial premium
Ảnh doanh nghiệp / đội ngũ / kỹ sư
Ảnh nhà máy / kho / test area
Ảnh pin lithium close-up
Ảnh module pin / cabinet / ESS
Ảnh xe nâng điện trong kho hiện đại
Ảnh AGV / robot trong nhà máy
Ảnh xe điện du lịch / buggy trong resort cao cấp
Ảnh trạm sạc / bộ sạc
Ảnh case / application / operational environment
Ảnh chứng chỉ dạng A4 mockup thật
Ảnh map / network / dealer visualization
Ảnh news thumbnails
Ảnh OEM / ODM technical integration
Yêu cầu về ảnh
realistic
premium
cinematic
industrial luxury
not cheap
not cartoon
not generic stock
MOTION DIRECTION CHI TIẾT
Hero
layered parallax
text reveal
video loop
light sweep subtle
floating panels movement nhẹ
circuit line pulse
energy line drift
Trusted by section
dual marquee chạy rất chậm
hover grayscale to full
panel transition crossfade + slide nhẹ
background drift gần như vô hình
spotlight zone rất nhẹ nếu muốn
Product showcase
image zoom nhẹ
card lift nhẹ
CTA arrow motion
line accent shift nhẹ
OEM / technical sections
line flow animation
node pulse cực nhẹ
panel reveal stagger
blueprint overlays move rất nhẹ
Dealer map
markers hover
pulsing points nhẹ
slide panel info
contour glow nhẹ
Certifications
image hover tilt cực nhẹ hoặc zoom
lightbox smooth open
News
thumbnail hover crop shift nhẹ
meta underline motion
STYLE UI COMPONENTS CHI TIẾT
Buttons
Primary
nền đỏ hoặc near-black tùy context
chữ trắng
corner sắc
padding premium
hover shift, fill change hoặc arrow move
Secondary
outline tinh tế
hover inverse
Cards
border mảnh
background sạch
shadow cực nhẹ
depth vừa đủ
không bo quá tròn
Tabs / filters
dùng cho trusted by / product groups / news / industries nếu cần
active state sang, rõ
Map cards
thông tin đại lý hiển thị dạng premium info panel
Certificate viewer
thumbnail A4 grid đẹp
click mở lớn