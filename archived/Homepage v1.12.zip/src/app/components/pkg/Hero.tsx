import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { CircuitLines, Eyebrow, PillButton } from "./decor";

const HERO_IMG =
  "https://images.unsplash.com/photo-1720036237038-802f50cdfd9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmdpbmVlciUyMHRlY2huaWNpYW4lMjBpbmR1c3RyaWFsJTIwZGFya3xlbnwxfHx8fDE3NzY3NzMyODh8MA&ixlib=rb-4.1.0&q=80&w=2000";

const PANEL_IMG =
  "https://images.unsplash.com/photo-1742899273038-67ff67477663?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80";

export function Hero() {
  return (
    <section className="relative min-h-screen overflow-hidden bg-black text-white">
      <ImageWithFallback
        src={HERO_IMG}
        alt="PKG Battery industrial environment"
        className="absolute inset-0 w-full h-full object-cover opacity-70"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/30" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/40" />

      <motion.div
        className="absolute inset-0 text-[#E10E1C]/25"
        animate={{ opacity: [0.35, 0.6, 0.35] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      >
        <CircuitLines />
      </motion.div>

      <div className="absolute top-1/2 -right-20 w-[520px] h-[520px] rounded-full bg-[#E10E1C]/20 blur-[140px]" />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-10 pt-40 pb-24 lg:pt-48 lg:pb-32">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-7">
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <Eyebrow tone="light">Giải pháp Pin Lithium Công nghiệp</Eyebrow>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.1 }}
              className="mt-6"
              style={{ fontSize: "clamp(44px, 6.2vw, 84px)", lineHeight: 1.02, fontWeight: 500, letterSpacing: "-0.035em" }}
            >
              Đối tác pin lithium<br />
              & sạc toàn diện<br />
              cho <span className="italic text-[#E10E1C]">doanh nghiệp</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.25 }}
              className="mt-8 max-w-[560px] text-white/75"
              style={{ fontSize: 17, lineHeight: 1.6 }}
            >
              Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp
              vận hành ổn định, giảm downtime và tối ưu chi phí sở hữu dài hạn.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.4 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              <PillButton variant="primary">Nhận tư vấn kỹ thuật</PillButton>
              <PillButton variant="ghost">Xem nhóm giải pháp</PillButton>
            </motion.div>

            <div className="mt-14 grid grid-cols-3 gap-6 max-w-[560px]">
              {[
                { k: "05", v: "Dòng giải pháp" },
                { k: "OEM", v: "ODM available" },
                { k: "VN/FDI", v: "Quốc tế" },
              ].map((it) => (
                <div key={it.k} className="border-t border-white/20 pt-4">
                  <div className="text-white" style={{ fontSize: 24, fontWeight: 500, letterSpacing: "-0.02em" }}>{it.k}</div>
                  <div className="text-white/60 mt-1" style={{ fontSize: 12, letterSpacing: "0.08em" }}>{it.v}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="relative"
            >
              <div className="relative aspect-[4/5] w-full overflow-hidden border border-white/10">
                <ImageWithFallback src={PANEL_IMG} alt="Battery cells close-up" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute top-4 left-4 flex items-center gap-2 text-white/80" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
                  <span className="h-1.5 w-1.5 rounded-full bg-[#E10E1C] animate-pulse" />
                  LIVE SYSTEM MONITOR
                </div>
                <div className="absolute bottom-5 left-5 right-5 border border-white/15 bg-black/40 backdrop-blur-md p-4">
                  <div className="text-white/60" style={{ fontSize: 10, letterSpacing: "0.2em" }}>MODULE BMS-24X</div>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span style={{ fontSize: 24, fontWeight: 500 }}>51.2<span className="text-white/50" style={{ fontSize: 12 }}> V</span></span>
                    <span className="text-[#E10E1C]" style={{ fontSize: 11, letterSpacing: "0.1em" }}>● NORMAL</span>
                  </div>
                  <div className="mt-3 h-1 bg-white/10">
                    <motion.div
                      className="h-full bg-[#E10E1C]"
                      initial={{ width: 0 }}
                      animate={{ width: "82%" }}
                      transition={{ duration: 1.4, delay: 0.8 }}
                    />
                  </div>
                </div>
              </div>

              <div className="absolute -left-10 -bottom-10 hidden lg:block border border-white/20 bg-black/50 backdrop-blur-md p-5 w-[220px]">
                <div className="text-white/60" style={{ fontSize: 10, letterSpacing: "0.2em" }}>APPLICATION COVERAGE</div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {["Forklift", "AGV", "Buggy", "ESS", "Charger"].map((t) => (
                    <span key={t} className="px-2 py-1 border border-white/20" style={{ fontSize: 10 }}>{t}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 inset-x-0 flex items-center justify-between px-6 lg:px-10 py-5 border-t border-white/10 bg-black/50 backdrop-blur-sm">
        <div className="flex items-center gap-3 text-white/60" style={{ fontSize: 11, letterSpacing: "0.22em" }}>
          <span className="h-1.5 w-1.5 rounded-full bg-[#E10E1C]" />
          PKG / 01 — HERO
        </div>
        <div className="hidden md:flex gap-8 text-white/55" style={{ fontSize: 11, letterSpacing: "0.18em" }}>
          <span>FORKLIFT</span>
          <span>AGV / ROBOT</span>
          <span>BUGGY / RESORT</span>
          <span>ESS</span>
          <span>CHARGERS</span>
        </div>
      </div>
    </section>
  );
}
