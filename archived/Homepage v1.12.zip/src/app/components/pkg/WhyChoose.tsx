import { Eyebrow } from "./decor";

const POINTS = [
  { t: "Giải pháp thiết kế theo nhu cầu vận hành", d: "Không rao pin chung. Cấu hình xuất phát từ bài toán thực tế, cường độ và môi trường sử dụng." },
  { t: "Tư duy kỹ thuật và đồng hành triển khai", d: "Đội ngũ kỹ sư tham gia khảo sát, thử nghiệm, pilot và hỗ trợ trong suốt vòng đời sản phẩm." },
  { t: "Tối ưu uptime, hiệu quả & TCO dài hạn", d: "Đánh giá trên tổng chi phí sở hữu — giảm downtime, giảm bảo trì, kéo dài chu kỳ thay thế." },
  { t: "Phục vụ đa ngành công nghiệp", d: "Logistics, sản xuất, AGV/robot, resort mobility, ESS và các fleet chuyên dụng." },
  { t: "Khả năng tùy chỉnh sâu", d: "Điện áp, dung lượng, form factor, BMS, giao tiếp — theo yêu cầu OEM/ODM." },
  { t: "Doanh nghiệp trong nước, FDI & đối tác kỹ thuật", d: "Cấu trúc phục vụ đa dạng khách hàng, từ nội địa đến đối tác quốc tế." },
];

export function WhyChoose() {
  return (
    <section className="relative bg-[#F5F5F5] py-24 lg:py-32">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-5 lg:sticky lg:top-28">
            <Eyebrow>Vì sao chọn PKG Battery</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(32px, 4.4vw, 60px)", lineHeight: 1.05, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Lý do doanh nghiệp chọn PKG cho bài toán năng lượng công nghiệp.
            </h2>
            <p className="mt-8 text-black/60 max-w-[420px]" style={{ fontSize: 15, lineHeight: 1.7 }}>
              Một đối tác không chỉ cung cấp pin — mà đồng hành cùng doanh nghiệp trong từng quyết định
              kỹ thuật, từng giai đoạn triển khai và từng thay đổi của khối lượng vận hành.
            </p>
          </div>

          <div className="lg:col-span-7">
            <div className="grid sm:grid-cols-2 gap-px bg-black/10">
              {POINTS.map((p, i) => (
                <div key={p.t} className="group relative bg-[#F5F5F5] p-7 hover:bg-white transition-colors">
                  <div className="flex items-baseline justify-between">
                    <span className="tabular-nums" style={{ fontSize: 28, fontWeight: 500, color: "#E10E1C", letterSpacing: "-0.02em" }}>
                      0{i + 1}
                    </span>
                    <div className="h-px w-10 bg-black/20 group-hover:w-16 group-hover:bg-[#E10E1C] transition-all" />
                  </div>
                  <h3 className="mt-6" style={{ fontSize: 17, fontWeight: 500, letterSpacing: "-0.01em", lineHeight: 1.3 }}>{p.t}</h3>
                  <p className="mt-3 text-black/60" style={{ fontSize: 13, lineHeight: 1.65 }}>{p.d}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
