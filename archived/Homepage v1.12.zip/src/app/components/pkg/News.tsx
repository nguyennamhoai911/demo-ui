import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Eyebrow, PillButton } from "./decor";

const FEATURED = {
  tag: "KIẾN THỨC KỸ THUẬT",
  date: "10 / 04 / 2026",
  title: "Chọn pin lithium cho fleet xe nâng điện: 5 tiêu chí doanh nghiệp thường bỏ sót",
  excerpt:
    "Từ cường độ ca làm, chu kỳ sạc, đến cấu hình BMS và tính tương thích thiết bị — đâu là những yếu tố ảnh hưởng trực tiếp đến TCO mà nhiều doanh nghiệp chưa tính đủ khi lựa chọn nhà cung cấp.",
  img: "https://images.unsplash.com/photo-1645736315000-6f788915923b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1600&q=80",
};

const POSTS = [
  {
    tag: "ỨNG DỤNG",
    date: "02 / 04 / 2026",
    title: "AGV & Robot: Vì sao nguồn năng lượng là yếu tố then chốt cho uptime tự động hóa",
    img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1000&q=80",
  },
  {
    tag: "ESS",
    date: "25 / 03 / 2026",
    title: "ESS cho doanh nghiệp vừa: Cân bằng giữa peak-shaving và năng lượng tái tạo",
    img: "https://images.unsplash.com/photo-1753272691001-4d68806ac590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1000&q=80",
  },
  {
    tag: "AN TOÀN",
    date: "18 / 03 / 2026",
    title: "BMS trong pin lithium công nghiệp: Những gì người mua cần hỏi trước khi ký hợp đồng",
    img: "https://images.unsplash.com/photo-1742899273038-67ff67477663?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1000&q=80",
  },
];

export function News() {
  return (
    <section className="relative bg-white py-24 lg:py-32">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="flex items-end justify-between mb-14 gap-10 flex-wrap">
          <div>
            <Eyebrow>Tin tức & Kiến thức kỹ thuật</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(30px, 4vw, 54px)", lineHeight: 1.05, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Cập nhật từ PKG Battery.
            </h2>
          </div>
          <PillButton variant="outline">Xem tất cả bài viết</PillButton>
        </div>

        <div className="grid lg:grid-cols-12 gap-8">
          <article className="lg:col-span-7 group cursor-pointer">
            <div className="relative aspect-[4/3] overflow-hidden bg-black">
              <ImageWithFallback src={FEATURED.img} alt={FEATURED.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
              <div className="absolute top-5 left-5 px-3 py-1 bg-[#E10E1C] text-white" style={{ fontSize: 10, letterSpacing: "0.22em" }}>FEATURED</div>
            </div>
            <div className="mt-6 flex items-center gap-4 text-black/55" style={{ fontSize: 11, letterSpacing: "0.18em" }}>
              <span>{FEATURED.tag}</span>
              <span className="h-px w-6 bg-black/20" />
              <span>{FEATURED.date}</span>
            </div>
            <h3 className="mt-5 group-hover:text-[#E10E1C] transition-colors" style={{ fontSize: 28, lineHeight: 1.2, fontWeight: 500, letterSpacing: "-0.02em" }}>
              {FEATURED.title}
            </h3>
            <p className="mt-4 text-black/60 max-w-[580px]" style={{ fontSize: 15, lineHeight: 1.7 }}>
              {FEATURED.excerpt}
            </p>
          </article>

          <div className="lg:col-span-5 flex flex-col gap-8">
            {POSTS.map((p) => (
              <article key={p.title} className="group grid grid-cols-5 gap-5 cursor-pointer items-start">
                <div className="col-span-2 relative aspect-[4/3] overflow-hidden bg-black">
                  <ImageWithFallback src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="col-span-3">
                  <div className="flex items-center gap-3 text-black/55" style={{ fontSize: 10, letterSpacing: "0.2em" }}>
                    <span>{p.tag}</span>
                    <span>·</span>
                    <span>{p.date}</span>
                  </div>
                  <h4 className="mt-3 group-hover:text-[#E10E1C] transition-colors" style={{ fontSize: 16, lineHeight: 1.3, fontWeight: 500, letterSpacing: "-0.01em" }}>
                    {p.title}
                  </h4>
                  <div className="mt-3 h-px w-8 bg-[#E10E1C] group-hover:w-16 transition-all" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
