import { motion } from "motion/react";

export function PrecisionGrid({ className = "" }: { className?: string }) {
  return (
    <svg
      className={`pointer-events-none absolute inset-0 w-full h-full ${className}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern id="pkg-grid" width="56" height="56" patternUnits="userSpaceOnUse">
          <path d="M 56 0 L 0 0 0 56" fill="none" stroke="currentColor" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#pkg-grid)" />
    </svg>
  );
}

export function CircuitLines({ className = "" }: { className?: string }) {
  return (
    <svg
      className={`pointer-events-none absolute inset-0 w-full h-full ${className}`}
      viewBox="0 0 1200 600"
      preserveAspectRatio="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g fill="none" stroke="currentColor" strokeWidth="1">
        <path d="M0,120 L260,120 L300,160 L520,160 L560,120 L900,120 L940,160 L1200,160" />
        <path d="M0,320 L180,320 L220,360 L420,360 L460,320 L720,320 L760,360 L1200,360" />
        <path d="M0,480 L340,480 L380,440 L640,440 L680,480 L1200,480" />
      </g>
      <g fill="currentColor">
        <circle cx="300" cy="160" r="3" />
        <circle cx="560" cy="120" r="3" />
        <circle cx="940" cy="160" r="3" />
        <circle cx="220" cy="360" r="3" />
        <circle cx="460" cy="320" r="3" />
        <circle cx="760" cy="360" r="3" />
        <circle cx="380" cy="440" r="3" />
        <circle cx="680" cy="480" r="3" />
      </g>
    </svg>
  );
}

export function Eyebrow({ children, tone = "dark" }: { children: React.ReactNode; tone?: "dark" | "light" | "red" }) {
  const color =
    tone === "light" ? "text-white/70" : tone === "red" ? "text-[#E10E1C]" : "text-black/60";
  return (
    <div className={`flex items-center gap-3 ${color} tracking-[0.28em] uppercase`} style={{ fontSize: 11, fontWeight: 500 }}>
      <span className="inline-block h-[1px] w-8 bg-current" />
      <span>{children}</span>
    </div>
  );
}

export function PillButton({
  children,
  variant = "primary",
  className = "",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "outline" | "light" }) {
  const styles: Record<string, string> = {
    primary: "bg-[#E10E1C] text-white hover:bg-[#b80a15] border-transparent",
    ghost: "bg-transparent text-white hover:bg-white/10 border-white/30",
    outline: "bg-transparent text-black hover:bg-black hover:text-white border-black",
    light: "bg-white text-black hover:bg-white/90 border-transparent",
  };
  return (
    <button
      {...rest}
      className={`group inline-flex items-center gap-3 px-6 py-3 border tracking-wide transition-all duration-300 ${styles[variant]} ${className}`}
      style={{ fontSize: 13, fontWeight: 500, letterSpacing: "0.04em" }}
    >
      <span>{children}</span>
      <span className="inline-block transition-transform duration-300 group-hover:translate-x-1">→</span>
    </button>
  );
}

export function SignalDivider() {
  return (
    <div className="relative h-px w-full bg-black/10">
      <motion.div
        className="absolute top-0 left-0 h-px w-24 bg-[#E10E1C]"
        animate={{ x: ["-10%", "110%"] }}
        transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
}

export function StatNumber({ value, label, sub }: { value: string; label: string; sub?: string }) {
  return (
    <div className="flex flex-col">
      <div className="flex items-baseline gap-1">
        <span className="tabular-nums" style={{ fontSize: 64, fontWeight: 500, letterSpacing: "-0.04em", lineHeight: 1 }}>
          {value}
        </span>
      </div>
      <div className="mt-3 h-px w-10 bg-[#E10E1C]" />
      <div className="mt-3" style={{ fontSize: 14, fontWeight: 500 }}>{label}</div>
      {sub && <div className="mt-1 text-black/55" style={{ fontSize: 12 }}>{sub}</div>}
    </div>
  );
}
