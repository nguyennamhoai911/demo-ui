import { ImageWithFallback } from "../figma/ImageWithFallback";
import { CircuitLines, Eyebrow, PillButton } from "./decor";

export function CTABlock() {
  return (
    <section className="relative bg-[#0A0A0A] text-white py-24 lg:py-32 overflow-hidden">
      <ImageWithFallback
        src="https://images.unsplash.com/photo-1720036237038-802f50cdfd9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=2000&q=80"
        alt="Industrial environment"
        className="absolute inset-0 w-full h-full object-cover opacity-30"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/60" />
      <div className="absolute inset-0 text-[#E10E1C]/15">
        <CircuitLines />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-6">
            <Eyebrow tone="red">Nhận tư vấn kỹ thuật</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(34px, 5vw, 68px)", lineHeight: 1.02, fontWeight: 500, letterSpacing: "-0.035em" }}>
              Trao đổi với đội ngũ PKG Battery về bài toán pin lithium của doanh nghiệp bạn.
            </h2>
            <p className="mt-8 text-white/70 max-w-[520px]" style={{ fontSize: 16, lineHeight: 1.7 }}>
              Chúng tôi đánh giá nhu cầu vận hành, đề xuất cấu hình phù hợp và định hướng giải pháp
              tối ưu hơn cho chi phí dài hạn — không cam kết đầu tư gì từ phía bạn.
            </p>

            <div className="mt-10 space-y-5 max-w-[440px]">
              {[
                { k: "Hotline kỹ thuật", v: "1900 — PKG" },
                { k: "Email dự án", v: "project@pkgbattery.vn" },
                { k: "OEM / ODM", v: "oem@pkgbattery.vn" },
              ].map((c) => (
                <div key={c.k} className="flex items-center justify-between border-b border-white/10 pb-3">
                  <span className="text-white/55" style={{ fontSize: 12, letterSpacing: "0.18em" }}>{c.k.toUpperCase()}</span>
                  <span style={{ fontSize: 15, fontWeight: 500 }}>{c.v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-6 lg:pl-10">
            <form className="border border-white/10 bg-white/[0.04] backdrop-blur-md p-8 lg:p-10 space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                {[
                  { l: "Họ và tên", p: "Nguyễn Văn A", type: "text" },
                  { l: "Công ty", p: "Tên doanh nghiệp", type: "text" },
                  { l: "Số điện thoại", p: "09xx xxx xxx", type: "tel" },
                  { l: "Email công việc", p: "ban@congty.vn", type: "email" },
                ].map((f) => (
                  <label key={f.l} className="block">
                    <span className="text-white/60" style={{ fontSize: 11, letterSpacing: "0.18em", fontWeight: 500 }}>{f.l.toUpperCase()}</span>
                    <input
                      type={f.type}
                      placeholder={f.p}
                      className="mt-2 w-full bg-transparent border-b border-white/20 pb-2 focus:border-[#E10E1C] focus:outline-none placeholder:text-white/30"
                      style={{ fontSize: 15 }}
                    />
                  </label>
                ))}
              </div>

              <label className="block">
                <span className="text-white/60" style={{ fontSize: 11, letterSpacing: "0.18em", fontWeight: 500 }}>
                  NHU CẦU / ỨNG DỤNG
                </span>
                <textarea
                  rows={4}
                  placeholder="Ví dụ: Cần pin lithium cho fleet 15 xe nâng 2 tấn, ca vận hành 2×8h/ngày..."
                  className="mt-2 w-full bg-transparent border border-white/15 p-3 focus:border-[#E10E1C] focus:outline-none resize-none placeholder:text-white/30"
                  style={{ fontSize: 14, lineHeight: 1.6 }}
                />
              </label>

              <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                <div className="text-white/45" style={{ fontSize: 12 }}>
                  Thông tin của bạn được bảo mật và chỉ dùng cho mục đích tư vấn.
                </div>
                <PillButton variant="primary">Gửi yêu cầu</PillButton>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
