import { useState } from "react";
import { motion } from "motion/react";
import { Eyebrow, PillButton } from "./decor";

const DEALERS = [
  { id: "hn", name: "PKG Hà Nội", region: "Miền Bắc", contact: "(024) — Trung tâm phía Bắc", x: 52, y: 14 },
  { id: "hp", name: "PKG Hải Phòng", region: "Miền Bắc", contact: "Logistics & cảng biển", x: 60, y: 18 },
  { id: "dn", name: "PKG Đà Nẵng", region: "Miền Trung", contact: "Trung tâm miền Trung", x: 66, y: 46 },
  { id: "qn", name: "PKG Quảng Nam", region: "Miền Trung", contact: "KCN miền Trung", x: 68, y: 52 },
  { id: "bd", name: "PKG Bình Dương", region: "Đông Nam Bộ", contact: "KCN & nhà máy FDI", x: 48, y: 78 },
  { id: "dni", name: "PKG Đồng Nai", region: "Đông Nam Bộ", contact: "Hỗ trợ logistics phía Nam", x: 52, y: 80 },
  { id: "hcm", name: "PKG TP.HCM", region: "Miền Nam", contact: "Trung tâm phía Nam", x: 50, y: 85 },
  { id: "ct", name: "PKG Cần Thơ", region: "ĐBSCL", contact: "Khu vực đồng bằng sông Cửu Long", x: 44, y: 92 },
];

export function DealerMap() {
  const [active, setActive] = useState(DEALERS[0]);

  return (
    <section className="relative bg-[#0A0A0A] text-white py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.08]" aria-hidden>
        <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="dm-grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dm-grid)" />
        </svg>
      </div>
      <div className="absolute -right-40 top-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full bg-[#E10E1C]/20 blur-[140px]" />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 mb-14">
          <div className="lg:col-span-7">
            <Eyebrow tone="red">Hệ thống đại lý</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(32px, 4.4vw, 58px)", lineHeight: 1.05, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Mạng lưới đại lý & phân phối trên toàn Việt Nam.
            </h2>
          </div>
          <div className="lg:col-span-5 flex items-end">
            <p className="text-white/65" style={{ fontSize: 15, lineHeight: 1.7 }}>
              Hiện diện tại các trung tâm công nghiệp trọng điểm — hỗ trợ kỹ thuật tại chỗ,
              giao hàng và bảo trì theo khu vực.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 relative aspect-[4/5] lg:aspect-[3/4] border border-white/10 bg-gradient-to-br from-[#101012] to-[#070707] overflow-hidden">
            {/* Stylized VN silhouette */}
            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              <defs>
                <linearGradient id="vnGrad" x1="0" x2="1" y1="0" y2="1">
                  <stop offset="0%" stopColor="#E10E1C" stopOpacity="0.18" />
                  <stop offset="100%" stopColor="#E10E1C" stopOpacity="0.02" />
                </linearGradient>
              </defs>
              <path
                d="M55,6 L62,10 L64,18 L60,24 L63,30 L66,38 L70,46 L68,54 L64,60 L58,66 L52,72 L48,78 L46,84 L42,90 L38,94 L44,92 L48,90 L50,86 L54,82 L52,78 L56,74 L60,68 L65,60 L70,50 L72,40 L68,28 L62,18 Z"
                fill="url(#vnGrad)"
                stroke="#E10E1C"
                strokeOpacity="0.4"
                strokeWidth="0.3"
              />
            </svg>

            {/* Contour lines */}
            <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full opacity-25" preserveAspectRatio="none">
              {[20, 30, 40, 50, 60, 70, 80].map((r) => (
                <circle key={r} cx={active.x} cy={active.y} r={r * 0.15} fill="none" stroke="#E10E1C" strokeWidth="0.15" />
              ))}
            </svg>

            {DEALERS.map((d) => {
              const isActive = d.id === active.id;
              return (
                <button
                  key={d.id}
                  onClick={() => setActive(d)}
                  onMouseEnter={() => setActive(d)}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group"
                  style={{ left: `${d.x}%`, top: `${d.y}%` }}
                >
                  {isActive && (
                    <motion.span
                      className="absolute inset-0 rounded-full bg-[#E10E1C]/40"
                      animate={{ scale: [1, 2.4], opacity: [0.6, 0] }}
                      transition={{ duration: 1.8, repeat: Infinity }}
                      style={{ width: 18, height: 18, left: -9, top: -9 }}
                    />
                  )}
                  <span
                    className={`relative block rounded-full transition-all ${
                      isActive ? "bg-[#E10E1C] w-4 h-4" : "bg-white/70 w-2.5 h-2.5 hover:bg-white"
                    }`}
                  />
                  <span
                    className={`absolute left-6 top-1/2 -translate-y-1/2 whitespace-nowrap transition-opacity ${
                      isActive ? "opacity-100" : "opacity-0 group-hover:opacity-70"
                    }`}
                    style={{ fontSize: 11, letterSpacing: "0.1em" }}
                  >
                    {d.name}
                  </span>
                </button>
              );
            })}

            <div className="absolute top-5 left-5 text-white/60" style={{ fontSize: 10, letterSpacing: "0.22em" }}>
              VN / DEALER NETWORK — 08 POINTS
            </div>
          </div>

          <div className="lg:col-span-5 flex flex-col">
            <div className="border border-white/10 bg-white/[0.03] backdrop-blur-sm p-7">
              <div className="text-[#E10E1C]" style={{ fontSize: 11, letterSpacing: "0.22em" }}>ACTIVE DEALER</div>
              <h3 className="mt-4" style={{ fontSize: 28, fontWeight: 500, letterSpacing: "-0.02em" }}>{active.name}</h3>
              <div className="mt-2 text-white/70" style={{ fontSize: 13, letterSpacing: "0.06em" }}>{active.region}</div>
              <p className="mt-5 text-white/60" style={{ fontSize: 14, lineHeight: 1.65 }}>{active.contact}</p>
              <div className="mt-6 flex gap-3">
                <PillButton variant="light">Xem chi tiết</PillButton>
                <PillButton variant="ghost">Liên hệ</PillButton>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-px bg-white/10 border border-white/10">
              {DEALERS.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setActive(d)}
                  className={`text-left p-4 transition-colors ${
                    d.id === active.id ? "bg-[#E10E1C] text-white" : "bg-[#0A0A0A] hover:bg-white/5 text-white/80"
                  }`}
                >
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{d.name}</div>
                  <div className={`mt-1 ${d.id === active.id ? "text-white/80" : "text-white/45"}`} style={{ fontSize: 11 }}>
                    {d.region}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
