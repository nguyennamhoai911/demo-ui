import { ImageWithFallback } from "../figma/ImageWithFallback";
import { CircuitLines, Eyebrow } from "./decor";

const PAINS = [
  { t: "Thời gian sạc dài", d: "Chu kỳ sạc chậm làm giảm tần suất khai thác thiết bị và kéo dài thời gian chờ giữa ca." },
  { t: "Downtime ảnh hưởng vận hành", d: "Một sự cố pin nhỏ có thể làm dừng cả dây chuyền hoặc fleet thiết bị trong nhiều giờ." },
  { t: "Pin xuống cấp nhanh", d: "Cấu hình không phù hợp khiến pin chai sớm, tăng chi phí thay thế định kỳ." },
  { t: "Chi phí bảo trì cao", d: "Giải pháp không đồng bộ phát sinh chi phí nhân công, phụ kiện và quản lý." },
  { t: "Khó đảm bảo an toàn", d: "BMS yếu hoặc giám sát thiếu tiêu chuẩn gây rủi ro cho thiết bị và người vận hành." },
  { t: "Không tối ưu TCO", d: "Chỉ nhìn giá đầu tư ban đầu sẽ bỏ qua chi phí vận hành và bảo trì dài hạn." },
];

export function PainPoints() {
  return (
    <section className="relative bg-[#0A0A0A] text-white py-24 lg:py-32 overflow-hidden">
      <ImageWithFallback
        src="https://images.unsplash.com/photo-1720036236697-018370867320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=2000&q=80"
        alt="Industrial operations"
        className="absolute inset-0 w-full h-full object-cover opacity-25"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-black via-black/90 to-[#1a0406]" />
      <div className="absolute inset-0 text-white/10">
        <CircuitLines />
      </div>

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5">
            <Eyebrow tone="red">Vấn đề vận hành thực tế</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(32px, 4.2vw, 56px)", lineHeight: 1.05, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Downtime, bảo trì và chi phí ẩn đang âm thầm bào mòn hiệu quả vận hành.
            </h2>
            <p className="mt-8 text-white/65 max-w-[440px]" style={{ fontSize: 15, lineHeight: 1.7 }}>
              Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện năng
              mà còn mất thời gian, năng suất và khả năng kiểm soát chi phí dài hạn.
            </p>
            <div className="mt-10 inline-flex items-center gap-3 text-white/80 border-l-2 border-[#E10E1C] pl-5 py-1" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
              Khách hàng không chỉ mua pin — họ mua sự yên tâm trong vận hành.
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="grid sm:grid-cols-2 gap-px bg-white/10">
              {PAINS.map((p, i) => (
                <div
                  key={p.t}
                  className={`group relative bg-black p-7 hover:bg-[#120306] transition-colors ${i === 0 || i === 3 ? "sm:row-span-1" : ""}`}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-white/40 tabular-nums" style={{ fontSize: 11, letterSpacing: "0.16em" }}>0{i + 1}</span>
                    <span className="h-1.5 w-1.5 rounded-full bg-[#E10E1C] opacity-60 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <h3 className="mt-6" style={{ fontSize: 18, fontWeight: 500, letterSpacing: "-0.01em" }}>{p.t}</h3>
                  <p className="mt-3 text-white/55" style={{ fontSize: 13, lineHeight: 1.6 }}>{p.d}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
