import { ImageWithFallback } from "../figma/ImageWithFallback";
import { CircuitLines, Eyebrow, StatNumber, PillButton } from "./decor";

const CERTS = [
  { t: "ISO 9001", d: "Quality Management" },
  { t: "IEC 62619", d: "Industrial Lithium Safety" },
  { t: "UN 38.3", d: "Transport Certification" },
  { t: "CE / RoHS", d: "European Compliance" },
];

const FACTORY = [
  { img: "https://images.unsplash.com/photo-1717386255773-1e3037c81788?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80", t: "Xưởng & dây chuyền" },
  { img: "https://images.unsplash.com/photo-1700727448686-b314cb5f9948?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80", t: "Kỹ sư vận hành" },
  { img: "https://images.unsplash.com/photo-1611023624193-31924e0e7d3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80", t: "Module & cabinet" },
  { img: "https://images.unsplash.com/photo-1720036236697-018370867320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80", t: "Khu test & QC" },
];

export function Capability() {
  return (
    <section className="relative bg-white py-24 lg:py-32 overflow-hidden">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end mb-16">
          <div className="lg:col-span-7">
            <Eyebrow>Hồ sơ năng lực</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(32px, 4.4vw, 60px)", lineHeight: 1.05, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Năng lực được chứng minh bằng số liệu, chứng chỉ và đội ngũ thực tế.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-black/60" style={{ fontSize: 15, lineHeight: 1.75 }}>
              Capability Theater trình bày bằng chứng về quy mô, kinh nghiệm, tiêu chuẩn và độ phủ —
              giúp doanh nghiệp đánh giá PKG Battery như một đối tác dài hạn.
            </p>
          </div>
        </div>

        {/* Hero metric + secondary */}
        <div className="relative grid lg:grid-cols-12 gap-px bg-black/10 border border-black/10">
          <div className="relative lg:col-span-6 bg-black text-white p-10 lg:p-14 overflow-hidden">
            <div className="absolute inset-0 text-white/10">
              <CircuitLines />
            </div>
            <div className="absolute -bottom-24 -right-24 w-[380px] h-[380px] rounded-full bg-[#E10E1C]/30 blur-[120px]" />
            <div className="relative">
              <div className="text-white/60" style={{ fontSize: 11, letterSpacing: "0.22em" }}>HERO METRIC</div>
              <div className="mt-6 flex items-baseline gap-3">
                <span style={{ fontSize: "clamp(90px, 12vw, 180px)", fontWeight: 500, lineHeight: 0.95, letterSpacing: "-0.05em" }}>8</span>
                <span className="text-[#E10E1C]" style={{ fontSize: 48, fontWeight: 500 }}>+</span>
              </div>
              <div className="mt-4" style={{ fontSize: 20, fontWeight: 500 }}>Đại lý trên toàn Việt Nam</div>
              <div className="mt-3 text-white/55 max-w-[360px]" style={{ fontSize: 13, lineHeight: 1.6 }}>
                Mạng lưới đại lý hiện diện xuyên suốt Bắc – Trung – Nam, hỗ trợ triển khai và bảo trì tại chỗ.
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 grid grid-cols-2 gap-px bg-black/10">
            {[
              { value: "7+", label: "Năm tập trung lithium công nghiệp", sub: "Kinh nghiệm triển khai thực tế." },
              { value: "05", label: "Nhóm giải pháp chính", sub: "Forklift · Buggy · AGV · Charger · ESS." },
              { value: "OEM", label: "ODM capability", sub: "Cấu hình theo yêu cầu kỹ thuật." },
              { value: "VN/FDI", label: "Khách hàng & đối tác", sub: "Nội địa, FDI, quốc tế." },
            ].map((s) => (
              <div key={s.label} className="bg-white p-8">
                <StatNumber value={s.value} label={s.label} sub={s.sub} />
              </div>
            ))}
          </div>
        </div>

        {/* Factory strip */}
        <div className="mt-14">
          <div className="flex items-center justify-between mb-6">
            <div className="text-black/60" style={{ fontSize: 11, letterSpacing: "0.22em" }}>FACTORY · TEAM · QC</div>
            <div className="h-px flex-1 ml-6 bg-black/10" />
          </div>
          <div className="grid md:grid-cols-4 gap-3">
            {FACTORY.map((f) => (
              <div key={f.t} className="group relative aspect-[4/5] overflow-hidden bg-black">
                <ImageWithFallback src={f.img} alt={f.t} className="w-full h-full object-cover opacity-85 group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute bottom-5 left-5 right-5 text-white" style={{ fontSize: 13, fontWeight: 500, letterSpacing: "0.04em" }}>{f.t}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div className="mt-16 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <Eyebrow>Chứng chỉ & tiêu chuẩn</Eyebrow>
            <h3 className="mt-5" style={{ fontSize: 28, lineHeight: 1.15, fontWeight: 500, letterSpacing: "-0.02em" }}>
              Tuân thủ tiêu chuẩn công nghiệp quốc tế.
            </h3>
            <p className="mt-4 text-black/60" style={{ fontSize: 14, lineHeight: 1.65 }}>
              Bộ chứng chỉ và tài liệu kiểm định được cập nhật theo từng dòng sản phẩm và từng thị trường.
            </p>
            <div className="mt-6">
              <PillButton variant="outline">Xem hồ sơ chứng chỉ</PillButton>
            </div>
          </div>
          <div className="lg:col-span-8 grid grid-cols-2 md:grid-cols-4 gap-4">
            {CERTS.map((c, i) => (
              <div key={c.t} className="group relative aspect-[3/4] border border-black/10 bg-white p-5 flex flex-col justify-between hover:border-black transition-all">
                <div className="flex items-center justify-between">
                  <span className="tabular-nums text-black/40" style={{ fontSize: 11, letterSpacing: "0.18em" }}>A4 · 0{i + 1}</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-[#E10E1C]" />
                </div>
                <div className="relative flex-1 my-4 border border-black/10 bg-[radial-gradient(circle_at_center,#f5f5f5,#e8e8e8)] flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 opacity-10 text-black/40">
                    <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id={`cp-${i}`} width="14" height="14" patternUnits="userSpaceOnUse"><path d="M 14 0 L 0 0 0 14" fill="none" stroke="currentColor" strokeWidth="0.4"/></pattern></defs><rect width="100%" height="100%" fill={`url(#cp-${i})`}/></svg>
                  </div>
                  <div className="relative text-center">
                    <div style={{ fontSize: 22, fontWeight: 500, letterSpacing: "-0.02em" }}>{c.t}</div>
                    <div className="mt-1 text-black/50" style={{ fontSize: 11, letterSpacing: "0.1em" }}>{c.d}</div>
                  </div>
                </div>
                <button className="text-left text-black/70 group-hover:text-[#E10E1C] flex items-center gap-2" style={{ fontSize: 12, fontWeight: 500 }}>
                  Xem chi tiết <span className="group-hover:translate-x-1 transition-transform">→</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
