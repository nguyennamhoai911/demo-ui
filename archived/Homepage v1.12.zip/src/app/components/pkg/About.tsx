import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Eyebrow, PillButton } from "./decor";

export function About() {
  return (
    <section className="relative bg-white py-24 lg:py-32">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-start">
          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[4/5] w-full overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1700727448686-b314cb5f9948?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1400&q=80"
                alt="PKG Battery manufacturing"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -right-6 lg:-right-16 bottom-12 w-[60%] aspect-[4/3] overflow-hidden border-8 border-white shadow-xl hidden md:block">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1742899273038-67ff67477663?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1000&q=80"
                alt="Battery close-up"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -left-4 top-8 bg-[#E10E1C] text-white p-5 w-[180px] hidden md:block">
              <div style={{ fontSize: 11, letterSpacing: "0.2em" }}>SINCE</div>
              <div className="mt-2" style={{ fontSize: 44, fontWeight: 500, letterSpacing: "-0.03em", lineHeight: 1 }}>2017</div>
              <div className="mt-2 text-white/80" style={{ fontSize: 12 }}>Industrial lithium focus</div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <Eyebrow>Về PKG Battery</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(30px, 4vw, 52px)", lineHeight: 1.1, fontWeight: 500, letterSpacing: "-0.025em" }}>
              Đối tác giải pháp năng lượng lithium công nghiệp cho doanh nghiệp hiện đại.
            </h2>
            <p className="mt-8 text-black/65" style={{ fontSize: 16, lineHeight: 1.75 }}>
              PKG Battery được định vị như một doanh nghiệp B2B chuyên pin lithium công nghiệp, bộ sạc,
              trạm sạc và giải pháp kỹ thuật theo ứng dụng. Không chỉ cung cấp sản phẩm, PKG Battery hướng tới
              việc <span className="text-black">đồng hành cùng doanh nghiệp</span> trong việc lựa chọn cấu hình phù hợp,
              tối ưu hiệu quả vận hành và hỗ trợ triển khai thực tế trong nhiều môi trường công nghiệp khác nhau.
            </p>

            <div className="mt-10 grid sm:grid-cols-2 gap-x-10 gap-y-6">
              {[
                { t: "Tư duy giải pháp", d: "Không bán lẻ — xây dựng cấu hình theo bài toán vận hành." },
                { t: "Đa ngành công nghiệp", d: "Logistics, nhà máy, tự động hóa, resort, ESS, xe chuyên dụng." },
                { t: "Tư duy kỹ thuật", d: "Tư vấn, khảo sát, tùy chỉnh và triển khai thực tế." },
                { t: "Khách hàng VN, FDI & quốc tế", d: "Đồng hành doanh nghiệp nội địa và đối tác OEM/ODM." },
              ].map((it) => (
                <div key={it.t} className="flex gap-4">
                  <div className="h-6 w-px bg-[#E10E1C] flex-shrink-0 mt-1" />
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 500 }}>{it.t}</div>
                    <div className="mt-1 text-black/55" style={{ fontSize: 13, lineHeight: 1.6 }}>{it.d}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 flex flex-wrap gap-4">
              <PillButton variant="outline">Xem hồ sơ năng lực</PillButton>
              <PillButton variant="primary">Nhận tư vấn kỹ thuật</PillButton>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
