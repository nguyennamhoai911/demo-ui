import { Eyebrow } from "./decor";

const STEPS = [
  { k: "01", t: "Đánh giá nhu cầu vận hành", d: "Khảo sát tải, tần suất, môi trường, cường độ và bài toán thực tế của doanh nghiệp." },
  { k: "02", t: "Cấu hình pin & bộ sạc", d: "Đề xuất điện áp, dung lượng, BMS, form factor và cụm sạc tương thích thiết bị." },
  { k: "03", t: "Tùy chỉnh theo ứng dụng", d: "Điều chỉnh theo thiết bị và môi trường — forklift, AGV, buggy, ESS, dây chuyền tự động." },
  { k: "04", t: "Tích hợp & triển khai", d: "Thi công, lắp đặt, thử tải, chạy pilot và bàn giao vận hành cho đội ngũ doanh nghiệp." },
  { k: "05", t: "Hỗ trợ kỹ thuật & hậu mãi", d: "Đồng hành giám sát, bảo trì, nâng cấp cấu hình khi khối lượng vận hành thay đổi." },
];

export function Solutions() {
  return (
    <section className="relative bg-[#F5F5F5] py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.5] text-black/10 pointer-events-none">
        <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="sol-grid" width="80" height="80" patternUnits="userSpaceOnUse">
              <path d="M 80 0 L 0 0 0 80" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#sol-grid)" />
        </svg>
      </div>

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end mb-16">
          <div className="lg:col-span-6">
            <Eyebrow>Giải pháp tổng thể</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(30px, 4vw, 54px)", lineHeight: 1.08, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Từ pin đến giải pháp vận hành hoàn chỉnh.
            </h2>
          </div>
          <div className="lg:col-span-6">
            <p className="text-black/60" style={{ fontSize: 15, lineHeight: 1.75 }}>
              PKG Battery xây dựng giải pháp pin lithium công nghiệp theo bài toán thực tế của doanh nghiệp —
              từ khảo sát nhu cầu, cấu hình pin và sạc phù hợp, đến triển khai, hỗ trợ kỹ thuật và đồng hành vận hành.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-5 gap-px bg-black/10">
          {STEPS.map((s, i) => (
            <div
              key={s.k}
              className="group relative bg-white p-7 hover:bg-black hover:text-white transition-all duration-500"
            >
              <div className="flex items-center justify-between">
                <span className="tabular-nums text-black/30 group-hover:text-[#E10E1C]" style={{ fontSize: 28, fontWeight: 500, letterSpacing: "-0.02em" }}>
                  {s.k}
                </span>
                {i < 4 && (
                  <div className="hidden lg:flex items-center text-black/25 group-hover:text-[#E10E1C]">
                    <div className="h-px w-6 bg-current" />
                    <span>→</span>
                  </div>
                )}
              </div>
              <h3 className="mt-8" style={{ fontSize: 17, fontWeight: 500, letterSpacing: "-0.01em" }}>{s.t}</h3>
              <p className="mt-3 text-black/55 group-hover:text-white/60" style={{ fontSize: 13, lineHeight: 1.6 }}>{s.d}</p>
              <div className="mt-10 h-px w-6 bg-[#E10E1C]" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
