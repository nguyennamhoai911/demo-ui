import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Eyebrow } from "./decor";

const INDUSTRIES = [
  { t: "Logistics & Kho vận", d: "Forklift, pallet truck, kho phân loại, trung tâm logistics 24/7.", img: "https://images.unsplash.com/photo-1645736315000-6f788915923b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80" },
  { t: "Nhà máy & Sản xuất", d: "Dây chuyền vận hành liên tục, nội bộ di chuyển và hỗ trợ sản xuất.", img: "https://images.unsplash.com/photo-1717386255773-1e3037c81788?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80" },
  { t: "AGV / Robot / Tự động hóa", d: "Hệ thống tự hành cần nguồn năng lượng ổn định và tương thích cao.", img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80" },
  { t: "Resort & Mobility", d: "Xe điện du lịch, buggy, shuttle trong khu nghỉ dưỡng, sân golf.", img: "https://images.unsplash.com/photo-1762742316793-b1845065429a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80" },
  { t: "Khu công nghiệp", d: "Đồng bộ nhiều thiết bị, cụm sạc tập trung, quản lý fleet quy mô lớn.", img: "https://images.unsplash.com/photo-1668204866018-85586ed7bd89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80" },
  { t: "ESS & Lưu trữ năng lượng", d: "Giải pháp dự phòng, peak-shaving, tích hợp năng lượng tái tạo.", img: "https://images.unsplash.com/photo-1753272691001-4d68806ac590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80" },
];

export function Industries() {
  return (
    <section className="relative bg-white py-24 lg:py-32">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 mb-14">
          <div className="lg:col-span-6">
            <Eyebrow>Ứng dụng công nghiệp</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(30px, 4vw, 54px)", lineHeight: 1.08, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Giải pháp cho nhiều bối cảnh vận hành công nghiệp.
            </h2>
          </div>
          <div className="lg:col-span-6 lg:pl-10 flex items-end">
            <p className="text-black/60" style={{ fontSize: 15, lineHeight: 1.75 }}>
              Mỗi ngành có đặc thù riêng về cường độ vận hành, môi trường và chuẩn an toàn.
              PKG Battery lựa chọn cấu hình và hỗ trợ kỹ thuật theo từng bối cảnh cụ thể.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {INDUSTRIES.map((ind, i) => (
            <article key={ind.t} className="group relative overflow-hidden aspect-[4/5] bg-black">
              <ImageWithFallback
                src={ind.img}
                alt={ind.t}
                className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-95 transition-all duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

              <div className="absolute top-5 left-5 right-5 flex items-center justify-between text-white/80" style={{ fontSize: 11, letterSpacing: "0.22em" }}>
                <span>0{i + 1}</span>
                <span className="h-1.5 w-1.5 rounded-full bg-[#E10E1C]" />
              </div>

              <div className="absolute left-0 right-0 bottom-0 p-6 text-white">
                <h3 style={{ fontSize: 22, fontWeight: 500, letterSpacing: "-0.015em" }}>{ind.t}</h3>
                <p className="mt-3 text-white/75 max-h-0 overflow-hidden group-hover:max-h-24 transition-all duration-500" style={{ fontSize: 13, lineHeight: 1.6 }}>
                  {ind.d}
                </p>
                <div className="mt-4 h-px w-8 bg-[#E10E1C] group-hover:w-20 transition-all" />
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
