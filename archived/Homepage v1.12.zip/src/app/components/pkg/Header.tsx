import { useEffect, useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";
import { PillButton } from "./decor";

const NAV = [
  "Giải pháp",
  "Sản phẩm",
  "Ứng dụng",
  "OEM / ODM",
  "Về PKG",
  "Tin tức",
  "Đại lý",
  "Liên hệ",
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-white/90 backdrop-blur-md border-b border-black/5"
          : "bg-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10 h-20 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5">
          <div className="relative">
            <div className="h-8 w-8 bg-[#E10E1C] relative">
              <div className="absolute inset-[6px] bg-white" />
              <div className="absolute inset-[10px] bg-[#E10E1C]" />
            </div>
          </div>
          <div className="flex flex-col leading-none">
            <span style={{ fontSize: 16, fontWeight: 600, letterSpacing: "0.02em" }}>PKG BATTERY</span>
            <span className={`${scrolled ? "text-black/55" : "text-white/70"} mt-0.5`} style={{ fontSize: 10, letterSpacing: "0.24em", fontWeight: 500 }}>
              INDUSTRIAL LITHIUM SOLUTIONS
            </span>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-7">
          {NAV.map((item) => (
            <button
              key={item}
              className={`flex items-center gap-1 transition-colors ${
                scrolled ? "text-black/80 hover:text-[#E10E1C]" : "text-white/85 hover:text-white"
              }`}
              style={{ fontSize: 13, fontWeight: 500 }}
            >
              {item}
              {["Giải pháp", "Sản phẩm", "Ứng dụng"].includes(item) && (
                <ChevronDown className="h-3 w-3 opacity-60" />
              )}
            </button>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-5">
          <div className={`flex items-center gap-1.5 ${scrolled ? "text-black/60" : "text-white/70"}`} style={{ fontSize: 11, letterSpacing: "0.18em", fontWeight: 500 }}>
            <span className="text-black/90 font-semibold" style={{ color: scrolled ? "#000" : "#fff" }}>VI</span>
            <span>/</span>
            <span>EN</span>
          </div>
          <PillButton variant={scrolled ? "outline" : "light"}>Nhận tư vấn kỹ thuật</PillButton>
        </div>

        <button onClick={() => setOpen((v) => !v)} className={`lg:hidden ${scrolled ? "text-black" : "text-white"}`}>
          {open ? <X /> : <Menu />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-white border-t border-black/5 px-6 py-6 flex flex-col gap-4">
          {NAV.map((n) => (
            <button key={n} className="text-left" style={{ fontSize: 14, fontWeight: 500 }}>{n}</button>
          ))}
          <PillButton>Nhận tư vấn kỹ thuật</PillButton>
        </div>
      )}
    </header>
  );
}
