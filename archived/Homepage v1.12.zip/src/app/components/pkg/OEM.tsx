import { motion } from "motion/react";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { CircuitLines, Eyebrow, PillButton } from "./decor";

const BULLETS = [
  "Cấu hình theo ứng dụng cụ thể",
  "Tùy chỉnh điện áp, dung lượng, form factor",
  "Hỗ trợ tích hợp hệ thống & BMS",
  "Định hướng hợp tác OEM / ODM / FDI",
  "Đồng hành kỹ thuật trong quá trình phát triển",
];

export function OEM() {
  return (
    <section className="relative bg-gradient-to-br from-[#B50812] via-[#8A050C] to-[#2a0206] text-white py-24 lg:py-32 overflow-hidden">
      <ImageWithFallback
        src="https://images.unsplash.com/photo-1732030373864-d37573915751?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=2000&q=80"
        alt="Technical integration"
        className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-50"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-[#6a0309]/50 to-transparent" />

      <motion.div
        className="absolute inset-0 text-white/15"
        animate={{ opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 5, repeat: Infinity }}
      >
        <CircuitLines />
      </motion.div>
      <div className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-white/10 blur-[160px]" />

      <div className="relative max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <Eyebrow tone="light">OEM / ODM & Tùy chỉnh giải pháp</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(34px, 5vw, 72px)", lineHeight: 1.02, fontWeight: 500, letterSpacing: "-0.035em" }}>
              Cấu hình pin lithium<br />theo <em className="not-italic underline decoration-2 underline-offset-[10px]">yêu cầu kỹ thuật</em> của bạn.
            </h2>
            <p className="mt-8 max-w-[540px] text-white/75" style={{ fontSize: 16, lineHeight: 1.7 }}>
              PKG Battery hợp tác với doanh nghiệp và đối tác kỹ thuật cần cấu hình pin lithium theo yêu cầu —
              từ kích thước, điện áp, ứng dụng đến phương án tích hợp trong môi trường vận hành thực tế.
            </p>

            <ul className="mt-10 space-y-4 max-w-[520px]">
              {BULLETS.map((b, i) => (
                <li key={b} className="flex items-start gap-4 border-t border-white/15 pt-4">
                  <span className="tabular-nums text-white/50" style={{ fontSize: 11, letterSpacing: "0.18em" }}>0{i + 1}</span>
                  <span style={{ fontSize: 15, fontWeight: 500 }}>{b}</span>
                </li>
              ))}
            </ul>

            <div className="mt-10 flex flex-wrap gap-4">
              <PillButton variant="light">Trao đổi về OEM / ODM</PillButton>
              <PillButton variant="ghost">Gửi yêu cầu dự án</PillButton>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[4/5] overflow-hidden border border-white/15">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1611023624193-31924e0e7d3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80"
                alt="Battery module customization"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />

              <div className="absolute top-5 left-5 right-5 flex items-center justify-between text-white/85" style={{ fontSize: 10, letterSpacing: "0.24em" }}>
                <span>BLUEPRINT / MODULE-A</span>
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" /> CONFIGURABLE
                </span>
              </div>

              <div className="absolute bottom-5 left-5 right-5 grid grid-cols-2 gap-px bg-white/10">
                {[
                  { k: "Voltage", v: "24 / 48 / 80V" },
                  { k: "Capacity", v: "100–600Ah" },
                  { k: "Chemistry", v: "LFP" },
                  { k: "Form factor", v: "Custom" },
                ].map((s) => (
                  <div key={s.k} className="bg-black/55 backdrop-blur-sm p-3">
                    <div className="text-white/55" style={{ fontSize: 10, letterSpacing: "0.18em" }}>{s.k.toUpperCase()}</div>
                    <div className="mt-1" style={{ fontSize: 14, fontWeight: 500 }}>{s.v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
