import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Eyebrow, PillButton } from "./decor";

const PRODUCTS = [
  {
    n: "01",
    t: "Pin Lithium cho Xe Nâng Điện",
    d: "Giải pháp pin lithium tối ưu cho xe nâng điện với sạc nhanh, giảm bảo trì và hỗ trợ cường độ vận hành cao trong kho vận, logistics và nhà máy.",
    tag: "Forklift",
    img: "https://images.unsplash.com/photo-1714627798569-b3e36d409c4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1400&q=80",
    large: true,
  },
  {
    n: "02",
    t: "Pin Lithium cho Xe Điện Du Lịch",
    d: "Thiết kế cho xe điện du lịch, buggy và phương tiện chuyên dụng cần độ ổn định, tuổi thọ cao và trải nghiệm vận hành bền bỉ.",
    tag: "Resort / Mobility",
    img: "https://images.unsplash.com/photo-1758551940959-eacf38206d28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80",
  },
  {
    n: "03",
    t: "Pin cho Xe AGV / Robot",
    d: "Giải pháp năng lượng cho hệ thống tự động hóa cần độ ổn định, độ chính xác, tính tương thích và khả năng tích hợp kỹ thuật cao.",
    tag: "Automation",
    img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80",
  },
  {
    n: "04",
    t: "Bộ Sạc & Trạm Sạc",
    d: "Giải pháp sạc đồng bộ giúp tối ưu hiệu suất pin, rút ngắn thời gian chờ và phù hợp nhiều môi trường vận hành công nghiệp.",
    tag: "Charging",
    img: "https://images.unsplash.com/photo-1634255068148-f2c820a5ab2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1200&q=80",
  },
  {
    n: "05",
    t: "Hệ thống Pin Lưu Trữ ESS",
    d: "Giải pháp lưu trữ năng lượng cho doanh nghiệp cần tăng tính chủ động, ổn định nguồn điện và nâng cao hiệu quả vận hành dài hạn.",
    tag: "ESS",
    img: "https://images.unsplash.com/photo-1753272691001-4d68806ac590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=1400&q=80",
    large: true,
  },
];

export function Products() {
  return (
    <section className="relative bg-white py-24 lg:py-32">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end mb-14">
          <div className="lg:col-span-7">
            <Eyebrow>5 Dòng giải pháp chính</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(32px, 4.2vw, 58px)", lineHeight: 1.05, fontWeight: 500, letterSpacing: "-0.03em" }}>
              Giải pháp pin & sạc được thiết kế theo từng ứng dụng công nghiệp.
            </h2>
          </div>
          <div className="lg:col-span-5 flex lg:justify-end">
            <PillButton variant="outline">Xem toàn bộ danh mục</PillButton>
          </div>
        </div>

        <div className="grid lg:grid-cols-12 gap-6">
          {PRODUCTS.map((p, i) => {
            const span = p.large ? "lg:col-span-6" : "lg:col-span-4";
            return (
              <article
                key={p.n}
                className={`group relative overflow-hidden border border-black/10 hover:border-black transition-all duration-500 ${span} ${i === 0 ? "lg:row-span-2" : ""}`}
              >
                <div className="relative aspect-[4/3] lg:aspect-[5/4] overflow-hidden bg-black">
                  <ImageWithFallback
                    src={p.img}
                    alt={p.t}
                    className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute top-5 left-5 right-5 flex items-center justify-between text-white">
                    <span className="tabular-nums" style={{ fontSize: 12, letterSpacing: "0.22em" }}>{p.n} / 05</span>
                    <span className="px-2.5 py-1 border border-white/40 backdrop-blur-sm" style={{ fontSize: 10, letterSpacing: "0.18em" }}>{p.tag.toUpperCase()}</span>
                  </div>
                  <div className="absolute bottom-5 left-5 right-5 text-white">
                    <h3 style={{ fontSize: p.large ? 26 : 20, fontWeight: 500, letterSpacing: "-0.015em", lineHeight: 1.15 }}>{p.t}</h3>
                  </div>
                </div>

                <div className="p-6 bg-white">
                  <p className="text-black/65" style={{ fontSize: 14, lineHeight: 1.65 }}>{p.d}</p>
                  <div className="mt-6 flex items-center justify-between">
                    <button className="inline-flex items-center gap-2 text-black group-hover:text-[#E10E1C] transition-colors" style={{ fontSize: 13, fontWeight: 500, letterSpacing: "0.04em" }}>
                      Xem chi tiết
                      <span className="inline-block group-hover:translate-x-1 transition-transform">→</span>
                    </button>
                    <div className="h-px w-10 bg-[#E10E1C] group-hover:w-20 transition-all" />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
