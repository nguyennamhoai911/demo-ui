import { motion } from "motion/react";
import { Eyebrow, SignalDivider } from "./decor";

const PARTNERS_ROW_1 = [
  "LOGIXCORP", "VINAPORT", "SUMIDA-VN", "TECHNIKA", "MEKONG LOGISTICS", "AURELIA", "DELTA AUTO", "KINETIC",
];
const PARTNERS_ROW_2 = [
  "BAYPEAK RESORT", "PACIFICA ESS", "NAGANO ROBOTICS", "FDI NETWORK", "NORD INDUSTRIES", "ZENITH FARM", "APEX FLEET", "HANOI WORKS",
];

const TABS = ["All", "Enterprise", "OEM / ODM", "Dealers", "Technical Partners"];

export function TrustedBy() {
  return (
    <section className="relative bg-white py-24 lg:py-32 overflow-hidden">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end">
          <div className="lg:col-span-7">
            <Eyebrow>Hệ sinh thái đối tác & khách hàng</Eyebrow>
            <h2 className="mt-6" style={{ fontSize: "clamp(30px, 4vw, 52px)", lineHeight: 1.1, fontWeight: 500, letterSpacing: "-0.025em" }}>
              Đồng hành cùng doanh nghiệp trong nhiều môi trường vận hành trọng yếu.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-black/60" style={{ fontSize: 15, lineHeight: 1.7 }}>
              PKG Battery hiện diện trong các bối cảnh vận hành như logistics, nhà máy, kho vận,
              tự động hóa, xe điện chuyên dụng và lưu trữ năng lượng — với định hướng giải pháp,
              hỗ trợ kỹ thuật và hợp tác dài hạn.
            </p>
          </div>
        </div>

        <div className="mt-12 flex flex-wrap gap-2">
          {TABS.map((t, i) => (
            <button
              key={t}
              className={`px-4 py-2 border transition-colors ${i === 0 ? "bg-black text-white border-black" : "border-black/15 text-black/70 hover:border-black"}`}
              style={{ fontSize: 12, letterSpacing: "0.04em" }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-16 space-y-6">
        {[PARTNERS_ROW_1, PARTNERS_ROW_2].map((row, idx) => (
          <div
            key={idx}
            className="relative overflow-hidden"
            style={{
              maskImage: "linear-gradient(90deg, transparent, black 10%, black 90%, transparent)",
              WebkitMaskImage: "linear-gradient(90deg, transparent, black 10%, black 90%, transparent)",
            }}
          >
            <motion.div
              className="flex gap-16 whitespace-nowrap"
              animate={{ x: idx === 0 ? ["0%", "-50%"] : ["-50%", "0%"] }}
              transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
            >
              {[...row, ...row, ...row].map((p, i) => (
                <div
                  key={`${p}-${i}`}
                  className="group flex items-center gap-3 text-black/40 hover:text-black transition-colors cursor-pointer"
                  style={{ fontSize: idx === 0 ? 22 : 18, fontWeight: 500, letterSpacing: "0.08em" }}
                >
                  <span className="h-2 w-2 bg-black/20 group-hover:bg-[#E10E1C] transition-colors" />
                  {p}
                </div>
              ))}
            </motion.div>
          </div>
        ))}
      </div>

      <div className="max-w-[1440px] mx-auto px-6 lg:px-10 mt-16">
        <SignalDivider />
        <div className="mt-10 grid md:grid-cols-3 gap-6">
          {[
            { k: "Khách hàng doanh nghiệp", v: "Logistics, nhà máy, kho vận, tự động hóa, resort & khu công nghiệp." },
            { k: "Đối tác OEM / ODM", v: "Cấu hình theo yêu cầu kỹ thuật, tích hợp vào sản phẩm và hệ thống." },
            { k: "Mạng lưới phân phối", v: "Hiện diện tại nhiều tỉnh thành, mở rộng theo nhu cầu thị trường." },
          ].map((c) => (
            <div key={c.k} className="group p-8 border border-black/10 hover:border-black transition-all bg-white">
              <div className="flex items-center gap-2 text-[#E10E1C]" style={{ fontSize: 11, letterSpacing: "0.22em" }}>
                <span className="h-1.5 w-1.5 rounded-full bg-[#E10E1C]" />
                TRUST LAYER
              </div>
              <h3 className="mt-5" style={{ fontSize: 20, fontWeight: 500, letterSpacing: "-0.01em" }}>{c.k}</h3>
              <p className="mt-3 text-black/60" style={{ fontSize: 14, lineHeight: 1.6 }}>{c.v}</p>
              <div className="mt-6 h-px w-8 bg-black group-hover:w-20 group-hover:bg-[#E10E1C] transition-all" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
