const COLS = [
  {
    t: "Giải pháp",
    items: ["Pin xe nâng điện", "Pin xe điện du lịch", "Pin AGV / Robot", "Bộ sạc & Trạm sạc", "ESS lưu trữ năng lượng"],
  },
  {
    t: "Doanh nghiệp",
    items: ["Về PKG Battery", "Hồ sơ năng lực", "Chứng chỉ & Tiêu chuẩn", "Nhà máy & Đội ngũ", "Tin tức"],
  },
  {
    t: "Đối tác",
    items: ["OEM / ODM", "Gửi yêu cầu dự án", "Hệ thống đại lý", "FDI & Quốc tế", "Hợp tác kỹ thuật"],
  },
  {
    t: "Hỗ trợ",
    items: ["Liên hệ", "Tư vấn kỹ thuật", "Bảo hành", "Tài liệu kỹ thuật", "Chính sách"],
  },
];

export function Footer() {
  return (
    <footer className="relative bg-black text-white">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10 py-20">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 bg-[#E10E1C] relative">
                <div className="absolute inset-[6px] bg-black" />
                <div className="absolute inset-[10px] bg-[#E10E1C]" />
              </div>
              <div className="flex flex-col leading-none">
                <span style={{ fontSize: 16, fontWeight: 600, letterSpacing: "0.02em" }}>PKG BATTERY</span>
                <span className="text-white/50 mt-0.5" style={{ fontSize: 10, letterSpacing: "0.24em" }}>
                  INDUSTRIAL LITHIUM SOLUTIONS
                </span>
              </div>
            </div>
            <p className="mt-6 text-white/55 max-w-[360px]" style={{ fontSize: 14, lineHeight: 1.7 }}>
              PKG Battery — đối tác pin lithium công nghiệp, bộ sạc và giải pháp kỹ thuật
              cho doanh nghiệp Việt Nam, FDI và đối tác quốc tế.
            </p>
            <div className="mt-8 space-y-2 text-white/65" style={{ fontSize: 13, lineHeight: 1.7 }}>
              <div>Trụ sở: [Địa chỉ doanh nghiệp]</div>
              <div>Hotline: 1900 — PKG</div>
              <div>Email: contact@pkgbattery.vn</div>
            </div>
          </div>

          <div className="lg:col-span-8 grid grid-cols-2 md:grid-cols-4 gap-8">
            {COLS.map((c) => (
              <div key={c.t}>
                <div className="text-white/50" style={{ fontSize: 11, letterSpacing: "0.22em", fontWeight: 500 }}>{c.t.toUpperCase()}</div>
                <ul className="mt-5 space-y-3">
                  {c.items.map((it) => (
                    <li key={it}>
                      <a href="#" className="text-white/80 hover:text-[#E10E1C] transition-colors" style={{ fontSize: 13 }}>
                        {it}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-white/50" style={{ fontSize: 12 }}>
          <div>© 2026 PKG Battery. All rights reserved.</div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">Điều khoản</a>
            <a href="#" className="hover:text-white">Bảo mật</a>
            <a href="#" className="hover:text-white">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
