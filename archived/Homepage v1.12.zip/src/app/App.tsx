import { Header } from "./components/pkg/Header";
import { Hero } from "./components/pkg/Hero";
import { TrustedBy } from "./components/pkg/TrustedBy";
import { PainPoints } from "./components/pkg/PainPoints";
import { About } from "./components/pkg/About";
import { Solutions } from "./components/pkg/Solutions";
import { Products } from "./components/pkg/Products";
import { OEM } from "./components/pkg/OEM";
import { Industries } from "./components/pkg/Industries";
import { WhyChoose } from "./components/pkg/WhyChoose";
import { Capability } from "./components/pkg/Capability";
import { DealerMap } from "./components/pkg/DealerMap";
import { News } from "./components/pkg/News";
import { CTABlock } from "./components/pkg/CTABlock";
import { Footer } from "./components/pkg/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white text-black antialiased selection:bg-[#E10E1C] selection:text-white">
      <Header />
      <main>
        <Hero />
        <TrustedBy />
        <PainPoints />
        <About />
        <Solutions />
        <Products />
        <OEM />
        <Industries />
        <WhyChoose />
        <Capability />
        <DealerMap />
        <News />
        <CTABlock />
      </main>
      <Footer />
    </div>
  );
}
