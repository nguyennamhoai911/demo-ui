import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface Partner {
  id: string;
  name: string;
  period: string;
  type: string;
  description: string;
  industry: string;
  status: string;
  monoLogo: string;
  colorLogo: string;
}

const partners: Partner[] = [
  {
    id: '1',
    name: 'Nike',
    period: '2023',
    type: 'Brand Experience / UI Design / Frontend Development',
    description: 'Thiết kế landing page chiến dịch cao cấp cho dòng sản phẩm mới.',
    industry: 'Global Fashion Brand',
    status: 'Selected Partner',
    monoLogo: '✓',
    colorLogo: '✓'
  },
  {
    id: '2',
    name: 'Spotify',
    period: '2022 — 2023',
    type: 'Product Design / Motion / Frontend',
    description: 'Xây dựng trải nghiệm digital campaign khu vực Đông Nam Á.',
    industry: 'Music Technology',
    status: 'Ongoing',
    monoLogo: '♫',
    colorLogo: '♫'
  },
  {
    id: '3',
    name: 'Apple',
    period: '2024',
    type: 'UI/UX Design / Interactive Experience',
    description: 'Phát triển giao diện người dùng cho sự kiện ra mắt sản phẩm toàn cầu.',
    industry: 'Technology',
    status: 'Long-term Client',
    monoLogo: '',
    colorLogo: ''
  },
  {
    id: '4',
    name: 'Adidas',
    period: '2023 — 2024',
    type: 'Digital Campaign / Creative Development',
    description: 'Thiết kế và triển khai chiến dịch digital cho bộ sưu tập thể thao.',
    industry: 'Sportswear',
    status: 'Selected Partner',
    monoLogo: '▲',
    colorLogo: '▲'
  },
  {
    id: '5',
    name: 'Tesla',
    period: '2024',
    type: 'Web Experience / Motion Design',
    description: 'Xây dựng trải nghiệm web tương tác cho showroom ảo.',
    industry: 'Automotive Technology',
    status: 'Ongoing',
    monoLogo: 'T',
    colorLogo: 'T'
  },
  {
    id: '6',
    name: 'Google',
    period: '2023',
    type: 'Product Interface / Interaction Design',
    description: 'Thiết kế giao diện cho công cụ nội bộ và dashboard phân tích.',
    industry: 'Technology',
    status: 'Selected Partner',
    monoLogo: 'G',
    colorLogo: 'G'
  }
];

export default function PartnerTrustSection() {
  const [activePartner, setActivePartner] = useState<Partner>(partners[0]);

  return (
    <section className="relative min-h-screen w-full bg-white overflow-hidden">
      {/* Subtle Background Patterns */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(to right, #000 1px, transparent 1px),
            linear-gradient(to bottom, #000 1px, transparent 1px)
          `,
          backgroundSize: '80px 80px'
        }} />
      </div>

      {/* Radial Glow */}
      <div className="absolute top-0 left-1/4 w-[800px] h-[800px] opacity-[0.08]">
        <div
          className="w-full h-full blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgb(209, 213, 219) 0%, transparent 70%)'
          }}
        />
      </div>

      {/* Animated Background Lines */}
      <motion.div
        className="absolute top-1/4 right-0 w-px h-64 bg-gradient-to-b from-transparent via-gray-200 to-transparent"
        animate={{
          opacity: [0.2, 0.4, 0.2],
          y: [0, 50, 0]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      <motion.div
        className="absolute bottom-1/3 left-1/4 w-64 h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"
        animate={{
          opacity: [0.2, 0.4, 0.2],
          x: [0, 30, 0]
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Main Content Container */}
      <div className="relative max-w-[1600px] mx-auto px-8 lg:px-16 py-24 lg:py-32">
        <div className="grid lg:grid-cols-[1fr,1.5fr] gap-16 lg:gap-24 items-start">

          {/* LEFT SIDE - Detail Panel */}
          <div className="space-y-12">
            {/* Headline */}
            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              >
                <h2 className="text-5xl lg:text-6xl font-light tracking-tight text-black leading-[1.1]">
                  Trusted by<br />
                  <span className="relative inline-block">
                    Industry Leaders
                    <motion.span
                      className="absolute bottom-2 left-0 h-px bg-red-600"
                      initial={{ width: 0 }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 1, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    />
                  </span>
                </h2>
              </motion.div>

              <motion.p
                className="text-lg text-gray-600 max-w-md font-light leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              >
                Collaborating with world-class brands to create exceptional digital experiences.
              </motion.p>
            </div>

            {/* Active Partner Detail */}
            <div className="relative">
              <div className="absolute -left-8 top-0 w-0.5 h-full bg-gradient-to-b from-red-600 via-red-600/50 to-transparent" />

              <AnimatePresence mode="wait">
                <motion.div
                  key={activePartner.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                  className="space-y-6"
                >
                  {/* Partner Name & Period */}
                  <div className="space-y-2">
                    <h3 className="text-3xl lg:text-4xl font-light tracking-tight text-black">
                      {activePartner.name}
                    </h3>
                    <p className="text-sm uppercase tracking-[0.2em] text-gray-400 font-light">
                      {activePartner.period}
                    </p>
                  </div>

                  {/* Type of Work */}
                  <div className="space-y-3">
                    <p className="text-base text-gray-700 leading-relaxed">
                      {activePartner.type}
                    </p>
                    <div className="h-px w-16 bg-red-600/30" />
                  </div>

                  {/* Description */}
                  <p className="text-lg text-gray-600 leading-relaxed font-light max-w-lg">
                    {activePartner.description}
                  </p>

                  {/* Industry & Status */}
                  <div className="flex flex-wrap gap-4 pt-4">
                    <span className="px-4 py-2 bg-gray-50 text-gray-700 text-sm font-light border border-gray-200/50">
                      {activePartner.industry}
                    </span>
                    <span className="px-4 py-2 bg-red-50 text-red-700 text-sm font-light border border-red-200/50">
                      {activePartner.status}
                    </span>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* RIGHT SIDE - Partner Logos Grid */}
          <div className="relative">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="grid grid-cols-2 md:grid-cols-3 gap-8 lg:gap-12"
            >
              {partners.map((partner, index) => (
                <motion.button
                  key={partner.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.7,
                    delay: 0.6 + index * 0.1,
                    ease: [0.22, 1, 0.36, 1]
                  }}
                  onMouseEnter={() => setActivePartner(partner)}
                  onClick={() => setActivePartner(partner)}
                  className="group relative aspect-square flex items-center justify-center bg-white border border-gray-200/50 hover:border-gray-300/80 transition-all duration-500 cursor-pointer overflow-hidden"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {/* Hover Background */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white opacity-0 group-hover:opacity-100"
                    transition={{ duration: 0.4 }}
                  />

                  {/* Logo Container */}
                  <div className="relative z-10">
                    {/* Monochrome Logo (Default) */}
                    <motion.div
                      className="text-6xl lg:text-7xl font-light text-gray-900 group-hover:opacity-0"
                      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    >
                      {partner.monoLogo || partner.name.charAt(0)}
                    </motion.div>

                    {/* Full Color Logo (Hover) */}
                    <motion.div
                      className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100"
                      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <div className="text-6xl lg:text-7xl font-light bg-gradient-to-br from-red-600 to-red-800 bg-clip-text text-transparent">
                        {partner.colorLogo || partner.name.charAt(0)}
                      </div>
                    </motion.div>
                  </div>

                  {/* Active Indicator */}
                  {activePartner.id === partner.id && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600"
                      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    />
                  )}

                  {/* Subtle Corner Accent */}
                  <div className="absolute top-0 right-0 w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="absolute top-0 right-0 w-full h-px bg-gradient-to-l from-red-600/50 to-transparent" />
                    <div className="absolute top-0 right-0 h-full w-px bg-gradient-to-b from-red-600/50 to-transparent" />
                  </div>
                </motion.button>
              ))}
            </motion.div>

            {/* Floating Accent Element */}
            <motion.div
              className="absolute -bottom-12 -right-12 w-64 h-64 border border-gray-200/30 rounded-full"
              animate={{
                scale: [1, 1.1, 1],
                rotate: [0, 90, 0]
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "linear"
              }}
            />
          </div>
        </div>
      </div>

      {/* Bottom Decorative Line */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-gray-300 to-transparent" />
    </section>
  );
}
