/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { 
  Truck, 
  Warehouse, 
  ChevronRight, 
  Phone, 
  FileText, 
  Globe, 
  ShieldCheck, 
  ArrowRight,
  Menu,
  X,
  MapPin,
  Activity,
  ArrowUpRight
} from "lucide-react";
import { useState, useEffect } from "react";

// --- Components ---

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? "bg-white/95 backdrop-blur-md shadow-sm py-4" : "bg-transparent py-6"}`}>
      <div className="container-custom flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-pkg-red flex items-center justify-center font-bold text-white text-xl">P</div>
          <div className="flex flex-col leading-none">
            <span className={`font-bold tracking-tighter text-2xl ${isScrolled ? "text-pkg-black" : "text-white"}`}>PKG BATTERY</span>
            <span className={`text-[8px] tracking-[0.2em] font-medium ${isScrolled ? "text-pkg-black/60" : "text-white/60"}`}>INDUSTRIAL SOLUTIONS</span>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-8">
          {["Giải pháp", "Sản phẩm", "Ứng dụng", "OEM / ODM", "Về PKG", "Liên hệ"].map((item) => (
            <a 
              key={item} 
              href={`#`}
              className={`text-sm font-medium transition-colors hover:text-pkg-red ${isScrolled ? "text-pkg-black" : "text-white"}`}
            >
              {item}
            </a>
          ))}
        </div>

        <div className="hidden lg:block">
          <button className="bg-pkg-red hover:bg-red-700 text-white px-6 py-3 text-sm font-bold transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-red-600/20">
            NHẬN TƯ VẤN KỸ THUẬT
          </button>
        </div>

        <button className="lg:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X className={isScrolled ? "text-pkg-black" : "text-white"} /> : <Menu className={isScrolled ? "text-pkg-black" : "text-white"} />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 w-full bg-pkg-black text-white p-8 border-t border-white/10 lg:hidden h-screen"
        >
          <div className="flex flex-col gap-6">
            {["Giải pháp", "Sản phẩm", "Ứng dụng", "OEM / ODM", "Về PKG"].map((item) => (
              <a key={item} href="#" className="text-xl font-bold border-b border-white/5 pb-2">{item}</a>
            ))}
            <button className="bg-pkg-red text-white py-4 font-bold text-center">NHẬN TƯ VẤN KỸ THUẬT</button>
          </div>
        </motion.div>
      )}
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-pkg-black">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2070" 
          alt="Industrial Automation" 
          className="w-full h-full object-cover opacity-40 mix-blend-overlay"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-pkg-black via-pkg-black/80 to-transparent"></div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-[radial-gradient(circle_at_70%_30%,rgba(227,30,36,0.15)_0%,transparent_60%)]"></div>
      </div>

      <div className="container-custom relative z-10 grid lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-pkg-red/10 border border-pkg-red/30 mb-6">
              <div className="w-2 h-2 rounded-full bg-pkg-red animate-pulse"></div>
              <span className="text-pkg-red text-xs font-bold tracking-widest uppercase">Giải pháp pin lithium công nghiệp</span>
            </div>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-[0.95] tracking-tight mb-8 font-display uppercase italic">
              ĐỐI TÁC <br /> <span className="text-pkg-red">TOÀN DIỆN</span>
            </h1>
            <p className="text-lg md:text-xl text-white/70 max-w-2xl mb-10 leading-relaxed font-light">
              Hệ sinh thái pin – sạc – giải pháp kỹ thuật cao cấp dành riêng cho doanh nghiệp. 
              Giảm downtime, tối ưu vận hành và nâng cao lợi nhuận dài hạn.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <button className="w-full sm:w-auto bg-pkg-red hover:bg-red-700 text-white px-10 py-5 font-bold transition-all flex items-center justify-center gap-3">
                NHẬN TƯ VẤN KỸ THUẬT <ArrowRight size={18} />
              </button>
              <button className="w-full sm:w-auto bg-white/5 hover:bg-white/10 border border-white/10 text-white px-10 py-5 font-bold transition-all">
                XEM NHÓM GIẢI PHÁP
              </button>
            </div>
          </motion.div>
        </div>

        <div className="lg:col-span-4 hidden lg:block">
           <motion.div
             initial={{ opacity: 0, scale: 0.9 }}
             animate={{ opacity: 1, scale: 1 }}
             transition={{ delay: 0.3, duration: 1 }}
             className="relative pt-10"
           >
             <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 relative overflow-hidden">
               <div className="mb-8">
                  <div className="text-xs text-pkg-red font-bold tracking-[0.2em] mb-2">AVAILABILITY</div>
                  <div className="text-4xl font-bold text-white tracking-tighter">OEM / ODM</div>
                  <div className="text-white/40 text-sm mt-1 uppercase tracking-widest">Custom Solutions</div>
               </div>
               
               <div className="space-y-6">
                  <div className="flex items-center gap-4 group cursor-pointer border-b border-white/5 pb-4">
                    <div className="w-12 h-12 bg-white/5 border border-white/10 flex items-center justify-center text-pkg-red group-hover:bg-pkg-red group-hover:text-white transition-all">
                      <Truck size={20} />
                    </div>
                    <div>
                      <div className="text-white text-sm font-bold">Logistics & Warehousing</div>
                      <div className="text-white/40 text-[10px] uppercase">Forklift Specialists</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 group cursor-pointer border-b border-white/5 pb-4">
                    <div className="w-12 h-12 bg-white/5 border border-white/10 flex items-center justify-center text-pkg-red group-hover:bg-pkg-red group-hover:text-white transition-all">
                      <Warehouse size={20} />
                    </div>
                    <div>
                      <div className="text-white text-sm font-bold">Energy Storage ESS</div>
                      <div className="text-white/40 text-[10px] uppercase">Business Resilience</div>
                    </div>
                  </div>
               </div>
             </div>
           </motion.div>
        </div>
      </div>
    </section>
  );
};

const TrustStrip = () => {
  return (
    <section className="bg-white py-12 border-b border-pkg-gray">
      <div className="container-custom">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/4 shrink-0">
            <h3 className="text-xs font-bold tracking-[0.2em] text-pkg-black/40 uppercase">Phục vụ đa lĩnh vực</h3>
          </div>
          <div className="lg:w-3/4 flex flex-wrap items-center justify-between gap-8 opacity-20 filter grayscale">
               {["LOGISTICS", "AUTOMATION", "MANUFACTURING", "RESORTS", "WAREHOUSING"].map(t => (
                 <span key={t} className="text-2xl font-black tracking-tighter">{t}</span>
               ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const PainPoints = () => {
  return (
    <section className="py-24 bg-white industrial-grid">
      <div className="container-custom">
        <div className="grid lg:grid-cols-12 gap-20 items-end mb-20">
          <div className="lg:col-span-7">
            <h2 className="text-4xl md:text-6xl font-bold tracking-tight font-display text-balance leading-tight uppercase">
              Downtime và chi phí ẩn đang làm doanh nghiệp <span className="text-pkg-red italic underline underline-offset-8">mất tiền</span> hàng ngày
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-lg text-pkg-black/60 leading-relaxed font-light">
              Khi hệ thống pin không phù hợp, doanh nghiệp không chỉ mất điện năng mà còn mất thời gian, năng suất và khả năng kiểm soát vận hành.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { title: "Downtime kéo dài", desc: "Thời gian sạc quá lâu làm gián đoạn dòng vận hành doanh nghiệp." },
            { title: "Chi phí ẩn", desc: "Pin chì-axit yêu cầu bảo trì định kỳ phức tạp và thay mới nhanh." },
            { title: "Mất an toàn", desc: "Các hệ thống cũ không có BMS kiểm soát, tiềm ẩn rủi ro cháy nổ." },
            { title: "Khó tích hợp", desc: "Sản phẩm đại trà không tương thích hoàn hảo với đặc thù vận hành." }
          ].map((p, idx) => (
            <div key={idx} className="p-10 border border-pkg-gray bg-white relative group overflow-hidden">
              <div className="absolute top-0 right-0 w-2 h-0 bg-pkg-red group-hover:h-full transition-all duration-500"></div>
              <div className="text-pkg-red mb-8"><Activity size={32} /></div>
              <h4 className="text-xl font-bold mb-4 uppercase">{p.title}</h4>
              <p className="text-sm text-pkg-black/50 leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const AboutEnterprise = () => {
  return (
    <section className="py-32 bg-pkg-gray">
      <div className="container-custom grid lg:grid-cols-2 gap-24 items-center">
        <div className="relative">
          <div className="aspect-square bg-pkg-dark p-2">
            <img 
              src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=1000" 
              className="w-full h-full object-cover filter grayscale hover:grayscale-0 transition-all duration-700" 
              alt="Engineering" 
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-10 -left-10 bg-pkg-red p-10 text-white max-w-xs shadow-2xl">
            <div className="text-6xl font-black mb-4">PKG</div>
            <p className="text-xs font-bold leading-relaxed tracking-wider uppercase">Đối tác năng lượng Lithium công nghiệp tiêu chuẩn quốc tế.</p>
          </div>
        </div>

        <div>
          <div className="text-pkg-red font-bold text-xs tracking-widest mb-6 uppercase">Về PKG Battery</div>
          <h2 className="text-4xl md:text-5xl font-bold mb-8 tracking-tight font-display uppercase italic">Định hướng giải pháp năng lượng thay vì chỉ bán sản phẩm</h2>
          <div className="space-y-6 text-pkg-black/60 leading-relaxed text-lg font-light">
            <p>
              PKG Battery được định hướng như một doanh nghiệp B2B chuyên biệt về pin lithium công nghiệp, 
              bộ sạc và các giải pháp kỹ thuật theo ứng dụng thực tế.
            </p>
            <p>
              Chúng tôi không chỉ cung cấp pin, chúng tôi cung cấp sự an tâm trong vận hành thông qua việc đồng hành 
              cùng doanh nghiệp khảo sát, thiết kế và triển khai giải pháp tối ưu từng chi tiết nhỏ nhất.
            </p>
          </div>
          <button className="mt-12 flex items-center gap-3 text-pkg-red font-bold uppercase tracking-widest border-b-2 border-pkg-red/20 pb-4 hover:border-pkg-red transition-all">
            Tìm hiểu năng lực của chúng tôi <ArrowRight size={20} />
          </button>
        </div>
      </div>
    </section>
  );
};

const ProductShowcase = () => {
  const products = [
    { name: "Pin Xe Nâng Điện", desc: "Sạc nhanh, không bảo trì, vận hành 3-shift liên tục.", img: "https://picsum.photos/seed/forklift/800/1000" },
    { name: "Pin Xe Điện Du Lịch", desc: "Vận hành êm ái, bền bỉ cho resort & khu du lịch.", img: "https://picsum.photos/seed/buggy/800/1000" },
    { name: "Pin cho AGV / Robot", desc: "Tích hợp BMS thông minh cho tự động hóa nhà máy.", img: "https://picsum.photos/seed/robot/800/1000" },
    { name: "Bộ Sạc Công Nghiệp", desc: "Thuật toán sạc thông minh bảo vệ tuổi thọ pin.", img: "https://picsum.photos/seed/charger/800/1000" },
    { name: "Lưu Trữ Năng Lượng ESS", desc: "Đảm bảo nguồn điện dự phòng cho doanh nghiệp.", img: "https://picsum.photos/seed/ess/800/1000" }
  ];

  return (
    <section className="py-32 bg-pkg-black text-white">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row justify-between items-end gap-10 mb-24">
          <div className="max-w-xl">
            <div className="text-pkg-red font-bold text-xs tracking-widest mb-6 uppercase">Product Catalog</div>
            <h2 className="text-5xl font-bold tracking-tight font-display uppercase italic">5 Dòng giải pháp cốt lõi</h2>
          </div>
          <button className="text-white/40 hover:text-white border-b border-white/20 pb-2 transition-all uppercase text-[10px] tracking-widest font-bold font-sans">View Full Range</button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
          {products.map((item, idx) => (
            <div key={idx} className="group relative aspect-[3/4] overflow-hidden bg-pkg-dark">
              <img 
                src={item.img} 
                alt={item.name} 
                className="w-full h-full object-cover opacity-40 grayscale group-hover:scale-105 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-700" 
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <div className="text-pkg-red font-bold text-lg mb-2">0{idx + 1}</div>
                <h3 className="text-xl font-bold mb-4 uppercase tracking-tighter leading-tight">{item.name}</h3>
                <p className="text-[10px] opacity-0 group-hover:opacity-100 transition-opacity duration-500 uppercase tracking-widest leading-loose text-white/60 mb-6">{item.desc}</p>
                <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center group-hover:bg-pkg-red group-hover:border-pkg-red transition-all">
                  <ArrowUpRight size={14} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const DealerMap = () => {
  return (
    <section className="py-32 bg-white industrial-grid">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto text-center mb-24">
          <div className="text-pkg-red font-bold text-xs tracking-widest mb-6 uppercase">Presence</div>
          <h2 className="text-5xl font-bold font-display uppercase italic mb-8">Mạng lưới 08 đại lý chiến lược</h2>
          <p className="text-lg text-pkg-black/60 font-light">
            Chúng tôi hiện diện tại các trung tâm kinh tế trọng điểm để đảm bảo 
            hỗ trợ kỹ thuật nhanh nhất cho khách hàng doanh nghiệp trên toàn lãnh thổ Việt Nam.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
           <div className="lg:col-span-2 bg-pkg-gray aspect-video relative flex items-center justify-center p-12 overflow-hidden">
              <div className="absolute inset-0 opacity-10 bg-[url('https://picsum.photos/seed/map/1200/800')] bg-cover"></div>
              <div className="relative z-10 w-full h-full flex items-center justify-center border border-pkg-black/10">
                 <div className="text-8xl font-black text-pkg-black/5 uppercase tracking-[0.2em] -rotate-12">VIETNAM NETWORK</div>
                 {/* Dealer Pins */}
                 {[
                   { t: 10, l: 50 }, { t: 30, l: 45 }, { t: 60, l: 55 }, { t: 80, l: 40 }
                 ].map((p, i) => (
                   <div key={i} className="absolute w-4 h-4 bg-pkg-red rounded-full animate-ping" style={{ top: `${p.t}%`, left: `${p.l}%` }}></div>
                 ))}
              </div>
           </div>
           <div className="space-y-4">
              {["Hà Nội", "Hải Phòng", "Bình Dương (Head Office)", "Đồng Nai", "TP. Hồ Chí Minh", "Long An", "Đà Nẵng", "Cần Thơ"].map(loc => (
                <div key={loc} className="p-6 border border-pkg-gray hover:bg-pkg-black hover:text-white transition-all group flex items-center justify-between">
                  <span className="font-bold uppercase text-sm tracking-widest">{loc}</span>
                  <MapPin size={16} className="text-pkg-red group-hover:text-white" />
                </div>
              ))}
           </div>
        </div>
      </div>
    </section>
  );
};

const TrustSection = () => {
  return (
    <section className="py-24 bg-pkg-black">
      <div className="container-custom">
        <div className="grid lg:grid-cols-4 gap-12">
          {[
            { v: "150+", l: "Dự án Doanh nghiệp" },
            { v: "99.9%", l: "Tỷ lệ Uptime" },
            { v: "10+", l: "Năm kinh nghiệm" },
            { v: "24/7", l: "Hỗ trợ kỹ thuật" }
          ].map((s, i) => (
            <div key={i} className="text-center lg:text-left">
              <div className="text-6xl font-black text-white mb-2 font-display italic tracking-tighter">{s.v}</div>
              <div className="text-xs font-bold text-pkg-red uppercase tracking-widest">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-pkg-black pt-32 pb-12 border-t border-white/5">
      <div className="container-custom">
        <div className="grid lg:grid-cols-12 gap-20 mb-32">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-12 h-12 bg-pkg-red text-white flex items-center justify-center font-black text-2xl italic tracking-tighter">P</div>
              <div className="text-2xl font-bold text-white tracking-tighter uppercase italic">PKG BATTERY</div>
            </div>
            <p className="text-white/40 text-lg leading-relaxed font-light mb-10 max-w-md">
              Chuyên gia giải pháp pin Lithium công nghiệp theo yêu cầu. Giúp doanh nghiệp tối ưu vận hành và dẫn đầu trong kỷ nguyên năng lượng sạch.
            </p>
            <div className="flex items-center gap-4">
               {["Globe", "ShieldCheck", "Phone"].map(i => (
                 <div key={i} className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-pkg-red transition-all cursor-pointer">
                    <div className="text-white"><Globe size={20} /></div>
                 </div>
               ))}
            </div>
          </div>

          <div className="lg:col-span-7 grid md:grid-cols-3 gap-12">
            <div>
              <h5 className="text-white font-bold text-sm uppercase tracking-widest mb-8">Giải pháp</h5>
              <ul className="space-y-4 text-white/40 text-sm">
                <li><a href="#" className="hover:text-pkg-red">Pin Xe Nâng</a></li>
                <li><a href="#" className="hover:text-pkg-red">Hệ thống ESS</a></li>
                <li><a href="#" className="hover:text-pkg-red">OEM / ODM</a></li>
                <li><a href="#" className="hover:text-pkg-red">Custom BMS</a></li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-bold text-sm uppercase tracking-widest mb-8">Liên hệ</h5>
              <div className="space-y-6 text-white/40 text-sm">
                <div className="flex items-start gap-4">
                  <MapPin size={18} className="text-pkg-red shrink-0" />
                  <span>Khu công nghiệp VSIP II-A, <br />Bình Dương, Việt Nam</span>
                </div>
                <div className="flex items-center gap-4">
                  <Phone size={18} className="text-pkg-red shrink-0" />
                  <span className="text-white font-bold tracking-widest">1900 XXXX</span>
                </div>
              </div>
            </div>
            <div>
              <h5 className="text-white font-bold text-sm uppercase tracking-widest mb-8">PKG Studio</h5>
              <p className="text-[10px] leading-relaxed text-white/40 uppercase tracking-widest font-bold italic">Designed for High Performance Industrial Growth.</p>
            </div>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-8 text-[10px] font-bold text-white/30 uppercase tracking-[0.4em]">
          <div>© 2026 PKG BATTERY. EXPERT SOLUTIONS.</div>
          <div className="flex gap-10">
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- App ---

export default function App() {
  return (
    <div className="bg-white min-h-screen selection:bg-pkg-red selection:text-white">
      <Navigation />
      <Hero />
      <TrustStrip />
      <PainPoints />
      <AboutEnterprise />
      <div className="h-px bg-pkg-gray mx-auto max-w-7xl"></div>
      <ProductShowcase />
      <TrustSection />
      <DealerMap />
      <section className="py-24 bg-pkg-red text-white text-center">
         <div className="container-custom">
            <h2 className="text-5xl font-black italic uppercase tracking-tighter mb-10">Ẵn sàng cho kỷ nguyên Pin Lithium mới?</h2>
            <button className="bg-white text-pkg-red px-14 py-6 font-bold uppercase tracking-widest shadow-2xl hover:bg-pkg-black hover:text-white transition-all text-xl">
              NHẬN TƯ VẤN NGAY
            </button>
         </div>
      </section>
      <Footer />
    </div>
  );
}

