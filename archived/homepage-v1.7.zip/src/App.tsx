import Navbar from "./components/layout/Navbar";
import Hero from "./components/home/Hero";
import PainPoints from "./components/home/PainPoints";
import Solutions from "./components/home/Solutions";
import Applications from "./components/home/Applications";
import WhyChoose from "./components/home/WhyChoose";
import TrustSignals from "./components/home/TrustSignals";
import Process from "./components/home/Process";
import FinalCTA from "./components/home/FinalCTA";
import Footer from "./components/layout/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <PainPoints />
        <Solutions />
        <Applications />
        <WhyChoose />
        <TrustSignals />
        <Process />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
