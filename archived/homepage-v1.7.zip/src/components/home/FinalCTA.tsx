import { motion } from "motion/react";
import { ArrowRight, Mail, Phone, MapPin } from "lucide-react";

export default function FinalCTA() {
  return (
    <section className="section-padding bg-dark text-white relative overflow-hidden">
      {/* Background Graphic */}
      <div className="absolute top-0 right-0 w-full h-full industrial-grid opacity-10 pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-brand-red/10 blur-[120px] rounded-full" />

      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div>
            <h2 className="text-5xl lg:text-8xl font-bold tracking-tight mb-10 leading-[0.9]">
              Nhận tư vấn <br />
              kỹ thuật cho <br />
              <span className="text-brand-red italic">doanh nghiệp</span>
            </h2>
            <p className="text-xl text-white/50 mb-12 max-w-xl leading-relaxed italic">
              Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu vận hành, 
              đề xuất cấu hình phù hợp và tối ưu hơn cho chi phí dài hạn.
            </p>
            
            <div className="flex flex-col gap-6">
              <div className="flex items-center gap-4 text-white/60">
                <Phone className="w-5 h-5 text-brand-red" />
                <span className="font-medium">Hotline (Zalo): 0XXX XXX XXX [Cần xác nhận]</span>
              </div>
              <div className="flex items-center gap-4 text-white/60">
                <Mail className="w-5 h-5 text-brand-red" />
                <span className="font-medium">Email: contact@pkgbattery.com [Cần xác nhận]</span>
              </div>
              <div className="flex items-center gap-4 text-white/60">
                <MapPin className="w-5 h-5 text-brand-red" />
                <span className="font-medium">Khu công nghiệp / TP.HCM [Cần xác nhận]</span>
              </div>
            </div>
          </div>

          <div className="bg-white/5 p-10 lg:p-16 border border-white/10 backdrop-blur-sm">
            <div className="mb-10">
              <h3 className="text-2xl font-bold mb-2">Gửi yêu cầu trực tiếp</h3>
              <p className="text-white/40 text-sm italic">Đội ngũ kỹ thuật sẽ phản hồi trong vòng 24h làm việc.</p>
            </div>
            
            <form className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Tên doanh nghiệp</label>
                  <input className="w-full bg-white/5 border border-white/10 p-4 focus:border-brand-red transition-colors outline-none" placeholder="Tên công ty..." />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Họ và tên</label>
                  <input className="w-full bg-white/5 border border-white/10 p-4 focus:border-brand-red transition-colors outline-none" placeholder="Họ tên người liên hệ..." />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Lĩnh vực / Thiết bị cần lắp đặt</label>
                <input className="w-full bg-white/5 border border-white/10 p-4 focus:border-brand-red transition-colors outline-none" placeholder="Xe nâng, AGV, ESS..." />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-white/40">Nội dung chi tiết</label>
                <textarea className="w-full bg-white/5 border border-white/10 p-4 focus:border-brand-red transition-colors outline-none h-32" placeholder="Mô tả bài toán vận hành của bạn..." />
              </div>
              <button className="w-full bg-brand-red text-white py-5 font-bold uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-white hover:text-dark transition-all group">
                Gửi yêu cầu tư vấn
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
