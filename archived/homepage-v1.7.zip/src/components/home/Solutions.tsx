import { motion } from "motion/react";
import { CheckCircle2, Factory, Zap, HardDrive, Headphones, Search, Cpu, Settings } from "lucide-react";

export default function Solutions() {
  const steps = [
    { icon: <Search className="w-6 h-6" />, title: "Đánh giá nhu cầu", desc: "Khảo sát thực tế cường độ vận hành và bối cảnh sử dụng." },
    { icon: <Cpu className="w-6 h-6" />, title: "Cấu hình Pin & Sạc", desc: "Đề xuất thông số kỹ thuật tối ưu cho từng loại thiết bị." },
    { icon: <Settings className="w-6 h-6" />, title: "Tùy chỉnh ứng dụng", desc: "Thiết kế giải pháp tích hợp riêng cho doanh nghiệp." },
    { icon: <Zap className="w-6 h-6" />, title: "Triển khai lắp đặt", desc: "Đồng hành lắp đặt và hướng dẫn vận hành chuyên nghiệp." },
    { icon: <Headphones className="w-6 h-6" />, title: "Hỗ trợ kỹ thuật", desc: "Hậu mãi và hỗ trợ kỹ thuật nhanh chóng tại hiện trường." }
  ];

  return (
    <section className="section-padding bg-white relative overflow-hidden">
      <div className="container-custom">
        <div className="max-w-3xl mb-24">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-[1px] bg-brand-red" />
            <span className="text-xs font-bold uppercase tracking-[0.3em] text-brand-red">Our Ecosystem</span>
          </div>
          <h2 className="text-5xl lg:text-7xl font-bold tracking-tight text-dark mb-10">
            Từ pin đến giải pháp vận hành hoàn chỉnh
          </h2>
          <p className="text-xl text-dark/60 leading-relaxed italic">
            PKG Battery xây dựng giải pháp pin lithium công nghiệp theo bài toán thực tế của doanh nghiệp.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          {/* Left: Logic Diagram / Image */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-7 bg-dark p-2 relative overflow-hidden group"
          >
            <div className="absolute top-0 left-0 w-full h-full industrial-grid opacity-10 pointer-events-none" />
            <img 
              src="https://picsum.photos/seed/battery_tech/1200/800" 
              alt="Technology" 
              className="w-full grayscale group-hover:grayscale-0 transition-all duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark to-transparent opacity-60" />
            
            <div className="absolute bottom-12 left-12 right-12">
              <div className="flex items-center gap-4 mb-4">
                <span className="w-10 h-10 bg-brand-red flex items-center justify-center text-white font-bold">01</span>
                <span className="text-sm font-bold uppercase tracking-widest text-white">Integrated Solution</span>
              </div>
              <h4 className="text-3xl font-bold text-white mb-4">Hệ sinh thái Năng lượng Công nghiệp</h4>
              <p className="text-white/60 text-sm max-w-md">
                Tích hợp công nghệ BMS thông minh, Cell pin Grade-A và hệ thống sạc ổn định cho môi trường khắc nghiệt.
              </p>
            </div>
          </motion.div>

          {/* Right: Step points */}
          <div className="lg:col-span-5 flex flex-col gap-10">
            {steps.map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="flex gap-6 group cursor-default"
              >
                <div className="flex-shrink-0 w-14 h-14 border border-dark/5 flex items-center justify-center text-dark group-hover:bg-brand-red group-hover:text-white group-hover:border-brand-red transition-all duration-300">
                  {step.icon}
                </div>
                <div>
                  <h4 className="text-lg font-bold uppercase tracking-wider text-dark mb-2 group-hover:text-brand-red transition-colors">
                    {step.title}
                  </h4>
                  <p className="text-dark/50 text-sm leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
