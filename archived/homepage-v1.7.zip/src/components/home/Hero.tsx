import { motion } from "motion/react";
import { ArrowRight, Zap, Shield, Cpu } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-white">
      {/* Background Industrial Grid */}
      <div className="absolute inset-0 industrial-grid opacity-20 pointer-events-none" />
      
      {/* Cinematic Background Gradient */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-brand-red/5 to-transparent pointer-events-none" />

      <div className="container-custom relative z-10 grid lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-[1px] bg-brand-red" />
            <span className="text-xs font-bold uppercase tracking-[0.3em] text-brand-red">
              Industrial Energy Solutions
            </span>
          </div>
          
          <h1 className="text-6xl lg:text-8xl font-bold tracking-tight leading-[0.9] text-dark mb-8 text-balance">
            Đối tác pin lithium & sạc <br />
            <span className="text-brand-red">toàn diện</span> cho doanh nghiệp
          </h1>
          
          <p className="text-xl text-dark/70 max-w-xl mb-12 leading-relaxed text-balance">
            Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp vận hành ổn định, 
            giảm downtime và tối ưu chi phí sở hữu dài hạn.
          </p>

          <div className="flex flex-wrap gap-5">
            <button className="bg-dark text-white px-10 py-5 font-bold uppercase tracking-widest hover:bg-brand-red transition-all flex items-center gap-3 group">
              Nhận tư vấn kỹ thuật
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="border border-dark/10 px-10 py-5 font-bold uppercase tracking-widest hover:bg-dark hover:text-white transition-all">
              Xem nhóm giải pháp
            </button>
          </div>

          <div className="grid grid-cols-3 gap-8 mt-16 pt-12 border-t border-dark/5">
            <div className="flex flex-col gap-2">
              <Zap className="text-brand-red w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-dark/50">Uptime</span>
              <span className="text-lg font-bold text-dark">99.9%</span>
            </div>
            <div className="flex flex-col gap-2">
              <Cpu className="text-brand-red w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-dark/50">Technology</span>
              <span className="text-lg font-bold text-dark">LFP Grade-A</span>
            </div>
            <div className="flex flex-col gap-2">
              <Shield className="text-brand-red w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-widest text-dark/50">Warranty</span>
              <span className="text-lg font-bold text-dark">5+ Years</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative"
        >
          {/* Main Visual */}
          <div className="aspect-square relative z-10 overflow-hidden bg-dark">
            <img 
              src="https://picsum.photos/seed/industrial_battery/1200/1200" 
              alt="Industrial Lithium Battery" 
              className="w-full h-full object-cover grayscale opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-700 hover:scale-105"
              referrerPolicy="no-referrer"
            />
            {/* Absolute Badges */}
            <div className="absolute top-8 left-0 glass p-6 border-l-4 border-l-brand-red hidden lg:block">
              <span className="block text-2xl font-black text-dark">TCO Optimized</span>
              <span className="text-[10px] font-bold uppercase tracking-widest opacity-60">Total Cost of Ownership</span>
            </div>
          </div>
          
          {/* Decorative shapes */}
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-brand-red/10 -z-10" />
          <div className="absolute top-10 -left-10 w-64 h-64 border border-dark/5 -z-10" />
        </motion.div>
      </div>
    </section>
  );
}
