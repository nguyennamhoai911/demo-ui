import { motion } from "motion/react";
import { Check } from "lucide-react";

export default function WhyChoose() {
  const reasons = [
    { title: "Giải pháp thiết kế theo nhu cầu", desc: "Không áp đặt sản phẩm sẵn có, chúng tôi tùy chỉnh để khớp hoàn toàn với thiết bị của bạn." },
    { title: "Tư duy kỹ thuật & Đồng hành", desc: "Từ khảo sát đến lắp đặt và hậu mãi, đội ngũ kỹ sư đồng hành sát sao cùng doanh nghiệp." },
    { title: "Tối ưu hiệu quả & Chi phí dài hạn", desc: "Tập trung vào Uptime và TCO để mang lại giá trị bền vững cho đối tác." },
    { title: "Đa dạng ứng dụng", desc: "Phục vụ logistics, nhà máy, xe điện chuyên dụng và giải pháp lưu trữ năng lượng." }
  ];

  return (
    <section className="section-padding bg-white relative overflow-hidden" id="Năng lực">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div className="relative">
            <div className="absolute -top-10 -left-10 w-40 h-40 border border-brand-red opacity-10" />
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative aspect-[4/5] bg-dark overflow-hidden"
            >
              <img 
                src="https://picsum.photos/seed/tech_center/800/1000" 
                alt="Tech Team" 
                className="w-full h-full object-cover opacity-70 grayscale"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark to-transparent opacity-60" />
              <div className="absolute bottom-10 left-10 p-8 glass border-l-brand-red border-l-4">
                <span className="text-3xl font-bold block mb-1">Customer First</span>
                <span className="text-xs font-bold uppercase tracking-widest opacity-50">B2B Strategy & Support</span>
              </div>
            </motion.div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-[1px] bg-brand-red" />
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-brand-red">Why Partner With Us</span>
            </div>
            <h2 className="text-5xl lg:text-7xl font-bold tracking-tight text-dark mb-12">
              Lý do doanh nghiệp chọn PKG Battery
            </h2>
            
            <div className="flex flex-col gap-10">
              {reasons.map((reason, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex gap-6 group"
                >
                  <div className="w-8 h-8 rounded-full bg-brand-red/5 flex items-center justify-center text-brand-red flex-shrink-0 group-hover:bg-brand-red group-hover:text-white transition-colors">
                    <Check size={18} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-dark mb-2 tracking-tight group-hover:text-brand-red transition-colors">
                      {reason.title}
                    </h4>
                    <p className="text-dark/50 leading-relaxed max-w-lg italic">
                      {reason.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
