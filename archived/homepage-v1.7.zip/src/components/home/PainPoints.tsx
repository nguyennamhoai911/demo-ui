import { motion } from "motion/react";
import { AlertCircle, Clock, DollarSign, Settings, ShieldAlert } from "lucide-react";

const pains = [
  {
    icon: <Clock />,
    title: "Vận hành gián đoạn",
    desc: "Thời gian sạc dài hoặc pin xuống cấp nhanh làm chậm tiến độ nhà máy."
  },
  {
    icon: <Settings />,
    title: "Chi phí bảo trì cao",
    desc: "Tốn kém nhân lực và tài chính cho việc bảo trì, thay thế hệ thống cũ."
  },
  {
    icon: <ShieldAlert />,
    title: "Lo ngại an toàn",
    desc: "Khó đảm bảo ổn định trong môi trường công nghiệp làm việc liên tục."
  },
  {
    icon: <DollarSign />,
    title: "Chi phí ẩn khổng lồ",
    desc: "Khó tính toán đúng tổng chi phí sở hữu thực tế (TCO) dài hạn."
  }
];

export default function PainPoints() {
  return (
    <section className="section-padding bg-dark text-white overflow-hidden relative">
      {/* Background Graphic */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-brand-red/10 blur-[120px] rounded-full" />
      
      <div className="container-custom relative z-10">
        <div className="grid lg:grid-cols-2 gap-20 items-end mb-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-3 mb-6">
              <AlertCircle className="text-brand-red w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-[0.3em] text-brand-red">The Challenge</span>
            </div>
            <h2 className="text-5xl lg:text-7xl font-bold tracking-tight mb-8">
              Downtime và chi phí ẩn đang làm vận hành kém hiệu quả
            </h2>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="pb-2"
          >
            <p className="text-xl text-white/60 leading-relaxed text-balance">
              Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện năng 
              mà còn mất thời gian, năng suất và khả năng kiểm soát chi phí dài hạn.
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-1px bg-white/10 border border-white/10">
          {pains.map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-dark p-10 hover:bg-brand-red transition-all duration-500 group"
            >
              <div className="w-12 h-12 bg-white/5 flex items-center justify-center text-brand-red mb-8 group-hover:bg-white group-hover:text-brand-red transition-colors">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold mb-4 uppercase tracking-wider">{item.title}</h3>
              <p className="text-white/50 group-hover:text-white/90 transition-colors leading-relaxed">
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
