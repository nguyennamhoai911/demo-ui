import { motion } from "motion/react";
import { Award, Users, Briefcase, Globe } from "lucide-react";

export default function TrustSignals() {
  const stats = [
    { label: "Năm kinh nghiệm", value: "10+", icon: <Briefcase /> },
    { label: "Khách hàng B2B", value: "200+", icon: <Users /> },
    { label: "Tiêu chuẩn quốc tế", value: "ISO/CE", icon: <Award /> },
    { label: "Thị trường", value: "Toàn quốc", icon: <Globe /> }
  ];

  return (
    <section className="section-padding bg-dark text-white relative border-y border-white/5">
      <div className="container-custom">
        <div className="max-w-2xl mb-24">
          <h2 className="text-4xl lg:text-5xl font-bold tracking-tight mb-8">
            Năng lực kỹ thuật tạo nên sự yên tâm
          </h2>
          <p className="text-lg text-white/50 leading-relaxed max-w-xl italic">
            Với định hướng kỹ thuật rõ ràng và năng lực triển khai thực tế, chúng tôi xây dựng 
            niềm tin bằng quy trình, tiêu chuẩn và khả năng đáp ứng cao.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-24">
          {stats.map((stat, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group"
            >
              <div className="text-brand-red mb-8 opacity-50 group-hover:opacity-100 transition-opacity">
                {stat.icon}
              </div>
              <div className="text-5xl lg:text-7xl font-black italic tracking-tighter mb-4 group-hover:text-brand-red transition-colors">
                {stat.value}
              </div>
              <div className="text-xs font-bold uppercase tracking-[0.3em] text-white/40 group-hover:text-white transition-colors">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Note on data verification */}
        <div className="mt-20 pt-8 border-t border-white/5 flex flex-wrap gap-10 items-center justify-between opacity-30">
          <span className="text-[10px] font-bold uppercase tracking-widest">[Dữ liệu cần xác nhận với PKG Battery]</span>
          <div className="flex gap-12">
            {["Premium Cells", "Smart BMS", "Active Cooling", "Remote Control"].map(tag => (
              <span key={tag} className="text-[10px] font-bold uppercase tracking-widest">{tag}</span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
