import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";

const apps = [
  {
    id: "01",
    title: "Xe Nâng Điện",
    desc: "Tối ưu cho logistics và kho vận với khả năng sạc nhanh và giảm bảo trì.",
    img: "https://picsum.photos/seed/forklift/800/800"
  },
  {
    id: "02",
    title: "Xe AGV / Robot",
    desc: "Độ ổn định cao cho các hệ thống vận hành tự động thông minh.",
    img: "https://picsum.photos/seed/agv/800/800"
  },
  {
    id: "03",
    title: "Xe Điện Du Lịch",
    desc: "An toàn, tuổi thọ cao cho các phương tiện buggy và chuyên dụng.",
    img: "https://picsum.photos/seed/buggy/800/800"
  },
  {
    id: "04",
    title: "Trạm Sạc Thông Minh",
    desc: "Giải pháp sạc đồng bộ giúp tối ưu hiệu suất hệ thống pin.",
    img: "https://picsum.photos/seed/charger/800/800"
  },
  {
    id: "05",
    title: "Lưu Trữ ESS",
    desc: "Hệ thống lưu trữ năng lượng giúp doanh nghiệp chủ động nguồn điện.",
    img: "https://picsum.photos/seed/ess/800/800"
  },
];

export default function Applications() {
  return (
    <section className="section-padding bg-dark text-white overflow-hidden" id="Sản phẩm">
      <div className="container-custom">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-24">
          <div className="max-w-2xl">
            <h2 className="text-5xl lg:text-7xl font-bold tracking-tight mb-8">
              Giải pháp theo ứng dụng công nghiệp
            </h2>
            <p className="text-xl text-white/50 leading-relaxed italic">
              Danh mục giải pháp được xây dựng cho nhiều bối cảnh vận hành doanh nghiệp khác nhau.
            </p>
          </div>
          <button className="flex items-center gap-4 text-sm font-bold uppercase tracking-[0.3em] text-brand-red border-b border-brand-red pb-2 hover:opacity-80 transition-opacity">
            All Products <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid lg:grid-cols-2 lg:grid-rows-2 gap-8 lg:h-[900px]">
          {/* Main big box */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="lg:row-span-2 group relative overflow-hidden bg-white/5 border border-white/5"
          >
            <img 
              src={apps[0].img} 
              alt={apps[0].title}
              className="absolute inset-0 w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-60 transition-all duration-700 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/20 to-transparent" />
            <div className="relative h-full p-12 flex flex-col justify-between z-10">
              <span className="text-4xl font-black text-brand-red opacity-50">{apps[0].id}</span>
              <div>
                <h3 className="text-4xl lg:text-5xl font-bold mb-6 italic">{apps[0].title}</h3>
                <p className="text-xl text-white/70 mb-8 max-w-sm">{apps[0].desc}</p>
                <button className="flex items-center gap-3 text-sm font-bold uppercase tracking-widest text-white group-hover:text-brand-red transition-colors">
                  Tìm hiểu chi tiết <ArrowUpRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>

          {/* Grid for other 4 items */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:row-span-2">
            {apps.slice(1).map((app, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group relative overflow-hidden aspect-square lg:aspect-auto bg-white/5 border border-white/5 p-10 flex flex-col justify-between hover:bg-white/10 transition-colors"
              >
                <div className="flex justify-between items-start relative z-10">
                  <span className="text-sm font-bold uppercase tracking-widest text-brand-red">{app.id}</span>
                  <ArrowUpRight className="w-6 h-6 opacity-20 group-hover:opacity-100 group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                </div>
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold mb-4">{app.title}</h3>
                  <p className="text-white/40 text-sm leading-relaxed mb-6 group-hover:text-white/70 transition-colors">{app.desc}</p>
                  <div className="w-10 h-1 bg-brand-red scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500" />
                </div>
                {/* Subtle background image hover */}
                <img 
                  src={app.img} 
                  alt={app.title}
                  className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-10 transition-opacity duration-700 pointer-events-none grayscale"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
