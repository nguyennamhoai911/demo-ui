import { motion } from "motion/react";

const steps = [
  { id: "01", title: "Tiếp nhận & Đánh giá", desc: "Phân tích loại xe, công suất và bối cảnh vận hành thực tế tại nhà máy/kho." },
  { id: "02", title: "Đề xuất cấu hình", desc: "Tính toán đúng Dung lượng (Ah) và Điện áp (V) để đảm bảo tối ưu chi phí." },
  { id: "03", title: "Thiết kế & Sản xuất", desc: "Tùy chỉnh hệ thống pin, sạc và các module điều khiển theo chuẩn riêng." },
  { id: "04", title: "Triển khai thực tế", desc: "Lắp đặt tại hiện trường, kiểm tra thông số và hướng dẫn đội ngũ vận hành." },
  { id: "05", title: "Đồng hành kỹ thuật", desc: "Giám sát hiệu suất và hỗ trợ kỹ thuật định kỳ cho doanh nghiệp." },
];

export default function Process() {
  return (
    <section className="section-padding bg-white overflow-hidden" id="Quy trình">
      <div className="container-custom">
        <div className="flex flex-col lg:flex-row gap-24">
          <div className="lg:w-1/3">
            <div className="sticky top-32">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-12 h-[1px] bg-brand-red" />
                <span className="text-xs font-bold uppercase tracking-[0.3em] text-brand-red">The Workflow</span>
              </div>
              <h2 className="text-5xl lg:text-7xl font-bold tracking-tight text-dark mb-10">
                Quy trình tư vấn rõ ràng
              </h2>
              <p className="text-xl text-dark/50 leading-relaxed italic">
                PKG Battery hướng tới một quy trình làm việc thực tế, bài bản và phù hợp 
                với tiêu chuẩn của các đối tác doanh nghiệp lớn.
              </p>
            </div>
          </div>

          <div className="lg:w-2/3 flex flex-col gap-px bg-dark/5">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white py-12 flex flex-col md:flex-row gap-10 md:items-center group"
              >
                <div className="flex-shrink-0 text-7xl font-black italic tracking-tighter text-dark/5 group-hover:text-brand-red/10 transition-colors">
                  {step.id}
                </div>
                <div>
                  <h4 className="text-xl font-bold text-dark mb-4 group-hover:text-brand-red transition-colors">
                    {step.title}
                  </h4>
                  <p className="text-dark/50 max-w-xl group-hover:text-dark transition-colors leading-relaxed italic">
                    {step.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
