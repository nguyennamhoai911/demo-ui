import { ArrowRight, Linkedin, Facebook, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-dark text-white pt-24 pb-12 border-t border-white/5">
      <div className="container-custom">
        <div className="grid lg:grid-cols-4 gap-16 mb-24">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-8">
              <div className="w-8 h-8 bg-brand-red flex items-center justify-center text-white font-bold text-lg">P</div>
              <span className="text-xl font-bold tracking-tighter">
                PKG <span className="text-brand-red">BATTERY</span>
              </span>
            </div>
            <p className="text-white/40 text-sm leading-relaxed mb-8 italic">
              Đối tác giải pháp năng lượng lithium công nghiệp toàn diện cho doanh nghiệp tại Việt Nam và quốc tế.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all"><Linkedin size={18} /></a>
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all"><Facebook size={18} /></a>
              <a href="#" className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all"><Youtube size={18} /></a>
            </div>
          </div>

          <div>
            <h5 className="text-[10px] font-bold uppercase tracking-widest text-brand-red mb-8">Sản phẩm & Giải pháp</h5>
            <ul className="space-y-4">
              {["Pin Xe Nâng Điện", "Pin Xe AGV / Robot", "Pin Xe Du Lịch", "Hệ thống ESS", "Trạm Sạc Thông Minh"].map(link => (
                <li key={link}><a href="#" className="text-sm text-white/60 hover:text-white transition-colors">{link}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="text-[10px] font-bold uppercase tracking-widest text-brand-red mb-8">PKG Battery</h5>
            <ul className="space-y-4">
              {["Về chúng tôi", "Năng lực kỹ thuật", "Dự án tiêu biểu", "Tuyển dụng", "Liên hệ"].map(link => (
                <li key={link}><a href="#" className="text-sm text-white/60 hover:text-white transition-colors">{link}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="text-[10px] font-bold uppercase tracking-widest text-brand-red mb-8">Newsletter</h5>
            <p className="text-sm text-white/40 mb-6">Đăng ký nhận cập nhật mới nhất về công nghệ năng lượng liti.</p>
            <div className="flex">
              <input className="bg-white/5 border border-white/10 p-3 text-sm italic w-full focus:outline-none focus:border-brand-red" placeholder="Email của bạn..." />
              <button className="bg-brand-red p-3 hover:bg-white hover:text-dark transition-all">
                <ArrowRight size={18} />
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-white/5 gap-6 text-[10px] font-bold uppercase tracking-widest text-white/20">
          <div>© 2024 PKG BATTERY. ALL RIGHTS RESERVED.</div>
          <div className="flex gap-8">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Technical Support</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
