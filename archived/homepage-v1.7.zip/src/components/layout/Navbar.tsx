import { motion } from "motion/react";
import { Menu, X, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-white/90 backdrop-blur-md py-4 shadow-sm" : "bg-transparent py-8"
      }`}
    >
      <div className="container-custom flex items-center justify-between">
        <a href="/" className="group flex items-center gap-2">
          <div className="w-8 h-8 bg-brand-red flex items-center justify-center text-white font-bold text-lg">P</div>
          <span className={`text-xl font-bold tracking-tighter transition-colors ${scrolled ? "text-dark" : "text-dark"}`}>
            PKG <span className="text-brand-red">BATTERY</span>
          </span>
        </a>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center gap-10">
          {["Giải pháp", "Sản phẩm", "Năng lực", "Quy trình", "Tin tức"].map((item) => (
            <a 
              key={item} 
              href={`#${item}`} 
              className="text-sm font-medium uppercase tracking-widest text-dark/70 hover:text-brand-red transition-colors"
            >
              {item}
            </a>
          ))}
          <button className="bg-dark text-white px-6 py-3 text-xs font-bold uppercase tracking-widest hover:bg-brand-red transition-all flex items-center gap-2 group">
            Nhận tư vấn
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Mobile Toggle */}
        <button className="lg:hidden text-dark" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <motion.div 
        initial={false}
        animate={isOpen ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
        className={`lg:hidden fixed inset-0 bg-white z-40 pt-24 px-6 ${isOpen ? "pointer-events-auto" : "pointer-events-none"}`}
      >
        <div className="flex flex-col gap-8">
          {["Giải pháp", "Sản phẩm", "Năng lực", "Quy trình", "Tin tức"].map((item) => (
            <a 
              key={item} 
              href={`#${item}`} 
              className="text-2xl font-bold text-dark hover:text-brand-red transition-colors"
              onClick={() => setIsOpen(false)}
            >
              {item}
            </a>
          ))}
          <button className="bg-brand-red text-white w-full py-4 font-bold uppercase tracking-widest">
            Nhận tư vấn kỹ thuật
          </button>
        </div>
      </motion.div>
    </nav>
  );
}
