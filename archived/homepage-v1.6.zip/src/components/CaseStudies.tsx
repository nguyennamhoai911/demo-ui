import { motion } from "motion/react";
import { TrendingDown, TrendingUp, ArrowRight } from "lucide-react";

const studies = [
  {
    category: "Logistics",
    title: "Tối ưu vận hành cho kho lạnh Miền Bắc",
    metrics: [
      { label: "Downtime", value: "-45%", icon: TrendingDown },
      { label: "Uptime", value: "+30%", icon: TrendingUp },
    ],
    desc: "Thay thế ắc quy chì bằng pin lithium PKG với khả năng chịu lạnh cực tốt (-20°C)."
  },
  {
    category: "Nhà máy sản xuất",
    title: "Chuyển đổi năng lượng 150 xe nâng",
    metrics: [
      { label: "Chi phí bảo trì", value: "-60%", icon: TrendingDown },
      { label: "Sạc nhanh", value: "2h", icon: TrendingUp },
    ],
    desc: "Giải pháp trạm sạc tập trung tích hợp BMS quản lý từ xa cho toàn bộ đội xe."
  },
  {
    category: "Resort & Travel",
    title: "Hệ thống trạm sạc xe điện khu nghỉ dưỡng",
    metrics: [
      { label: "Tiết kiệm điện", value: "25%", icon: TrendingDown },
      { label: "Hài lòng", value: "98%", icon: TrendingUp },
    ],
    desc: "Thiết kế bộ sạc thẩm mỹ cao và pin lithium an toàn tuyệt đối cho khách du lịch."
  }
];

export default function CaseStudies() {
  return (
    <section className="py-24 bg-white overflow-hidden border-t border-brand-dark/5">
      <div className="container-custom">
        <div className="flex flex-col lg:flex-row justify-between items-start mb-20 gap-12">
          <div className="max-w-xl">
            <div className="kicker">Case Studies</div>
            <h2 className="text-4xl md:text-6xl mb-6 text-brand-dark">KẾT QUẢ TỪ <br /> <span className="text-brand-red">THỰC TIỄN</span></h2>
          </div>
          <button className="btn-outline">VIEW ALL PROJECTS</button>
        </div>

        <div className="grid lg:grid-cols-3 gap-[1px] bg-brand-dark/5 border border-brand-dark/5">
          {studies.map((study, index) => (
            <motion.div
              key={study.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="p-10 bg-white hover:bg-brand-muted transition-all group"
            >
              <div className="label-mono text-brand-red mb-6">
                {study.category}
              </div>
              <h3 className="text-2xl mb-10 text-brand-dark group-hover:text-brand-red transition-colors min-h-[64px]">{study.title}</h3>
              
              <div className="grid grid-cols-2 gap-[1px] bg-brand-dark/5 border border-brand-dark/5 mb-10">
                {study.metrics.map((metric) => (
                  <div key={metric.label} className="bg-white p-6 group-hover:bg-brand-muted transition-colors text-brand-dark">
                     <div className="text-3xl font-black text-brand-dark mb-2 leading-none">{metric.value}</div>
                     <div className="label-mono !mb-0 opacity-50">{metric.label}</div>
                  </div>
                ))}
              </div>

              <p className="text-sm text-brand-dark/40 leading-relaxed mb-10 h-16 overflow-hidden">{study.desc}</p>
              
              <a href="#" className="inline-flex items-center text-xs font-black uppercase tracking-widest text-brand-red group-hover:translate-x-3 transition-all">
                Read Story <ArrowRight size={14} className="ml-2" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
