import { motion } from "motion/react";
import { CheckCircle2, History, Settings, Zap, Headphones, Factory, Globe } from "lucide-react";

const usps = [
  { icon: History, text: "Hơn 10 năm kinh nghiệm" },
  { icon: CheckCircle2, text: "Giải pháp trọn gói từ A-Z" },
  { icon: Settings, text: "Tùy chỉnh kỹ thuật theo yêu cầu" },
  { icon: Zap, text: "Tối ưu uptime & TCO thực tế" },
  { icon: Headphones, text: "Hỗ trợ kỹ thuật 24/7" },
  { icon: Factory, text: "Năng lực OEM/ODM mạnh mẽ" },
  { icon: Globe, text: "Tiêu chuẩn quốc tế (ISO, IEC)" },
  { icon: CheckCircle2, text: "Đối tác tin cậy của doanh nghiệp FDI" },
];

export default function USP() {
  return (
    <section className="py-32 bg-brand-dark text-white border-t border-white/5">
      <div className="container-custom">
        <div className="grid lg:grid-cols-[1fr_1.5fr] gap-20 items-start">
          <div className="sticky top-32">
            <div className="kicker">Why choose us</div>
            <h2 className="text-4xl md:text-7xl mb-10 leading-[0.85] text-white">
              VÌ SAO CÁC <br />
              TẬP ĐOÀN LỚN <br />
              CHỌN <span className="text-brand-red">PKG</span>
            </h2>
            <p className="text-white/40 text-xl leading-relaxed max-w-sm mb-12">
              Nền tảng kỹ thuật vững chắc và trải nghiệm thực tế dày dặn là cam kết từ chúng tôi.
            </p>
            <button className="btn-primary">TƯ VẤN NGAY</button>
          </div>

          <div className="grid sm:grid-cols-2 gap-[1px] bg-white/10 border border-white/10">
            {usps.map((usp, index) => (
              <motion.div
                key={usp.text}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: index * 0.05 }}
                viewport={{ once: true }}
                className="p-12 bg-brand-dark group hover:bg-brand-muted/10 transition-all text-white"
              >
                <div className="flex flex-col h-full">
                  <div className="w-12 h-12 flex items-center justify-center bg-brand-red text-white mb-8 group-hover:scale-110 transition-transform">
                    <usp.icon size={22} />
                  </div>
                  <span className="text-lg font-black tracking-tight leading-tight group-hover:text-brand-red transition-colors">
                    {usp.text}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
