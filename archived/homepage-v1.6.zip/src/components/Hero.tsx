import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-white">
      <div className="bg-mesh-light"></div>
      
      <div className="container-custom relative z-10 w-full grid lg:grid-cols-[1.2fr_1fr] gap-0 border-x border-brand-dark/5 min-h-[80vh]">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="py-20 lg:pr-20 flex flex-col justify-center border-r border-brand-dark/5"
        >
          <div className="kicker">Industrial Energy Excellence</div>
          
          <h1 className="text-6xl md:text-8xl lg:text-[100px] leading-[0.85] mb-10 tracking-[-0.04em] text-brand-dark">
            ĐỐI TÁC PIN <br />
            LITHIUM & SẠC <br />
            <span className="text-brand-red">TOÀN DIỆN</span>
          </h1>
          
          <p className="text-lg text-brand-dark/50 max-w-lg mb-12 leading-relaxed">
            Hệ sinh thái pin – sạc – BMS giúp giảm downtime và tối ưu chi phí sở hữu cho doanh nghiệp vận hành chuỗi cung ứng toàn cầu.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6">
            <button className="btn-primary group">
              NHẬN TƯ VẤN KỸ THUẬT
              <ArrowRight className="ml-3 group-hover:translate-x-2 transition-transform" size={20} />
            </button>
          </div>

          <div className="mt-20 flex gap-12 border-t border-brand-dark/5 pt-10">
            <div>
              <div className="label-mono">Experience</div>
              <div className="text-2xl font-black text-brand-dark">10+ Years</div>
            </div>
            <div>
              <div className="label-mono">Projects</div>
              <div className="text-2xl font-black text-brand-dark">500+ Active</div>
            </div>
            <div>
              <div className="label-mono">Standards</div>
              <div className="text-2xl font-black text-brand-dark">ISO / UL / IEC</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative hidden lg:grid grid-rows-2 bg-brand-muted"
        >
          <div className="p-12 flex flex-col justify-between border-b border-brand-dark/5 relative group overflow-hidden">
             <img 
               src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=800" 
               className="absolute inset-0 w-full h-full object-cover opacity-20 group-hover:scale-110 transition-transform duration-1000 grayscale"
               referrerPolicy="no-referrer"
             />
             <div className="relative z-10">
               <div className="label-mono">Optimization Metric</div>
               <div className="text-5xl font-light mb-2 text-brand-dark">-45%</div>
               <div className="text-[11px] uppercase tracking-widest font-bold text-brand-dark/40">Downtime reduction</div>
             </div>
             <p className="text-[12px] text-brand-dark/60 relative z-10 max-w-[240px]">PKG solutions are engineered to eliminate battery-related operational delays.</p>
          </div>

          <div className="p-12 flex flex-col justify-center">
            <div className="label-mono">Market Segments</div>
            <div className="space-y-4 mt-6">
              {[
                { name: "Intralogistics", val: "85%" },
                { name: "Manufacturing / AGV", val: "92%" },
                { name: "Energy Storage (ESS)", val: "78%" }
              ].map(item => (
                <div key={item.name} className="flex justify-between items-end border-b border-brand-dark/5 pb-4">
                  <span className="font-bold text-sm text-brand-dark">{item.name}</span>
                  <span className="text-brand-red font-black text-xl">{item.val}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
