import { motion } from "motion/react";
import { AlertCircle, Clock, Zap, ShieldAlert, TrendingUp, HelpCircle } from "lucide-react";

const points = [
  { icon: Clock, title: "Downtime tăng cao", desc: "Sạc chậm hoặc hết pin giữa chừng gây gián đoạn vận hành." },
  { icon: Zap, title: "Tuổi thọ ngắn", desc: "Ắc quy chì truyền thống xuống cấp nhanh, chi phí thay thế liên tục." },
  { icon: ShieldAlert, title: "Rủi ro an toàn", desc: "Cháy nổ, rò rỉ acid từ các dòng pin/ắc quy kém chất lượng." },
  { icon: TrendingUp, title: "Chi phí ẩn khổng lồ", desc: "Bảo trì tốn nhân lực, tiền điện sạc lãng phí do hiệu năng thấp." },
];

export default function PainPoints() {
  return (
    <section className="py-24 bg-brand-muted overflow-hidden border-t border-brand-dark/5">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-20 items-center mb-24">
          <div>
            <div className="kicker">Operational Challenges</div>
            <h2 className="text-4xl md:text-6xl mb-8 leading-[0.9] text-brand-dark">
              DOWNTIME VÀ CHI PHÍ ẨN <br />
              <span className="text-brand-red">ĐANG BÀO MÒN</span> HIỆU QUẢ
            </h2>
          </div>
          <div>
            <p className="text-xl text-brand-dark/40 leading-relaxed border-l border-brand-red pl-8">
              Doanh nghiệp đang lãng phí hàng nghìn USD mỗi năm do hệ thống năng lượng lỗi thời và thiếu sự đồng hành của đối tác kỹ thuật thực thụ.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 bg-brand-dark/5 gap-[1px]">
          {points.map((point, index) => (
            <motion.div 
              key={point.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="p-12 bg-white group hover:bg-brand-red transition-all duration-300"
            >
              <div className="label-mono mb-6 text-brand-red group-hover:text-white">0{index + 1} / Problem</div>
              <h3 className="text-xl mb-6 text-brand-dark group-hover:text-white transition-colors">{point.title}</h3>
              <p className="text-sm text-brand-dark/40 group-hover:text-white/80 leading-relaxed">{point.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
