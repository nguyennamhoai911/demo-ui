import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";

const products = [
  {
    title: "Pin xe nâng điện",
    desc: "Pin lithium 24V–80V, sạc nhanh, không bảo trì, nâng cao 30% hiệu suất vận hành.",
    image: "https://picsum.photos/seed/forklift/800/600",
    tag: "Industrial"
  },
  {
    title: "Pin AGV / Robot",
    desc: "Module gọn nhẹ, mật độ năng lượng cao, kết nối BMS thông minh cho tự động hoá.",
    image: "https://picsum.photos/seed/agv/800/600",
    tag: "Automation"
  },
  {
    title: "Pin xe điện du lịch",
    desc: "An toàn, bền bỉ, thời gian hoạt động dài cho resort và các khu chuyên dụng.",
    image: "https://picsum.photos/seed/ev/800/600",
    tag: "Mobility"
  },
  {
    title: "Trạm sạc thông minh",
    desc: "Giao thức sạc nhanh đồng bộ, bảo vệ pin tối đa và tối ưu hiệu suất sạc.",
    image: "https://picsum.photos/seed/charger/800/600",
    tag: "Infrastructure"
  },
  {
    title: "Hệ thống lưu trữ ESS",
    desc: "Backup power, peak shaving, tích hợp năng lượng mặt trời cho nhà máy.",
    image: "https://picsum.photos/seed/ess/800/600",
    tag: "Energy"
  },
];

export default function ProductCategory() {
  return (
    <section className="py-24 bg-white" id="Sản phẩm">
      <div className="container-custom">
        <div className="mb-20">
          <div className="kicker">Product Showcase</div>
          <h2 className="text-4xl md:text-6xl mb-0 text-brand-dark">SẢN PHẨM & ỨNG DỤNG</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 bg-brand-dark/5 gap-[1px] border border-brand-dark/5">
          {products.slice(0, 4).map((product, index) => (
            <motion.div
              key={product.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group cursor-pointer bg-white p-10 relative overflow-hidden min-h-[400px] flex flex-col justify-between hover:bg-brand-red transition-all duration-300 shadow-sm"
            >
              <div className="relative z-10 transition-transform group-hover:-translate-y-2">
                <div className="label-mono mb-4 text-brand-red group-hover:text-white">{product.tag}</div>
                <h3 className="text-xl mb-4 text-brand-dark group-hover:text-white transition-colors">{product.title}</h3>
                <p className="text-xs text-brand-dark/40 group-hover:text-white/80 leading-relaxed">{product.desc}</p>
              </div>
              
              <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity">
                 <img src={product.image} className="w-full h-full object-cover" />
              </div>

              <div className="relative z-10 flex justify-between items-end">
                <div className="text-6xl font-black text-brand-dark opacity-5 group-hover:opacity-10 transition-opacity font-sans">0{index + 1}</div>
                <ArrowUpRight size={24} className="text-brand-dark opacity-0 group-hover:opacity-100 group-hover:text-white transition-all transform translate-y-4 group-hover:translate-y-0" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
