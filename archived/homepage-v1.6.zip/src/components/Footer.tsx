import { motion } from "motion/react";
import { Mail, Phone, MapPin, Facebook, Linkedin, Youtube, ArrowRight } from "lucide-react";

export function ContactCTA() {
  return (
    <section className="py-32 bg-brand-red relative overflow-hidden">
      <div className="bg-mesh opacity-30"></div>
      
      <div className="container-custom relative z-10 text-white">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl"
        >
          <div className="label-mono-white !text-white opacity-60 mb-6 tracking-[0.4em]">Next Step</div>
          <h2 className="text-5xl md:text-8xl mb-12 leading-[0.85]">
            SẴN SÀNG TỐI ƯU <br /> <span className="text-brand-dark">NĂNG LƯỢNG</span>?
          </h2>
          <p className="text-white/80 max-w-2xl mb-16 text-xl leading-relaxed">
            Hãy để đội ngũ chuyên gia của chúng tôi giúp bạn thiết kế giải pháp lithium phù hợp nhất.
          </p>
          <div className="flex flex-col sm:flex-row gap-6">
            <button className="px-12 py-6 bg-brand-dark text-white font-black uppercase tracking-widest text-sm hover:bg-white hover:text-brand-dark transition-all shadow-2xl border-none">
              NHẬN TƯ VẤN KỸ THUẬT
            </button>
            <button className="px-12 py-6 bg-transparent text-white font-black uppercase tracking-widest text-sm hover:bg-white/10 transition-all border border-white/30">
              TẢI CATALOGUE 2024
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-brand-dark text-white pt-32 pb-12 border-t border-white/5">
      <div className="container-custom">
        <div className="grid lg:grid-cols-12 gap-20 mb-32">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-2 mb-10">
              <div className="font-display font-black text-3xl tracking-[-0.05em]">
                PKG <span className="text-brand-red">BATTERY</span>
              </div>
            </div>
            <p className="text-white/30 mb-12 max-w-md text-lg leading-relaxed">
              Nhà cung cấp giải pháp năng lượng lithium toàn diện. Chất lượng quốc tế - Kỹ thuật chuyên sâu - Đối tác tin cậy.
            </p>
            <div className="flex gap-4">
              {[Facebook, Linkedin, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-12 h-12 border border-white/10 flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all">
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7 grid sm:grid-cols-3 gap-16">
            <div>
              <div className="label-mono-white text-brand-red mb-10">Solutions</div>
              <ul className="space-y-4 text-white/40 text-sm font-bold">
                <li><a href="#" className="hover:text-brand-red transition-colors">Pin xe nâng điện</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Pin AGV / Robot</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Pin xe du lịch</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Hệ thống ESS</a></li>
              </ul>
            </div>
            <div>
              <div className="label-mono-white text-brand-red mb-10">Company</div>
              <ul className="space-y-4 text-white/40 text-sm font-bold">
                <li><a href="#" className="hover:text-brand-red transition-colors">Về chúng tôi</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Năng lực kỹ thuật</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Dự án tiêu biểu</a></li>
                <li><a href="#" className="hover:text-brand-red transition-colors">Tuyển dụng</a></li>
              </ul>
            </div>
            <div>
              <div className="label-mono-white text-brand-red mb-10">Contact</div>
              <ul className="space-y-6 text-white/40 text-sm font-bold">
                <li className="leading-relaxed">VSIP Industrial Park, Thuận An, Bình Dương</li>
                <li className="text-white">+84 123 456 789</li>
                <li className="text-white underline underline-offset-4 decoration-brand-red">info@pkgbattery.vn</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between gap-6 text-[10px] uppercase tracking-[0.2em] font-black text-white/20">
          <div>© 2024 PKG BATTERY JOINT STOCK COMPANY.</div>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">OEM/ODM Services</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

