import { motion } from "motion/react";
import { Search, PenTool, Cpu, Users, HeartHandshake, Layers, ArrowRight } from "lucide-react";

const steps = [
  { icon: Search, title: "Tư vấn & Đánh giá", desc: "Khảo sát thực địa và phân tích nhu cầu năng lượng thực tế." },
  { icon: Layers, title: "Mô phỏng TCO", desc: "Phân tích ứng dụng và tính toán tổng chi phí sở hữu dài hạn." },
  { icon: PenTool, title: "Thiết kế & Tùy biến", desc: "Thiết kế pin lithium, bộ sạc và hệ thống BMS tối ưu nhất." },
  { icon: Cpu, title: "Sản xuất & Tích hợp", desc: "Sản xuất tiêu chuẩn cao và tích hợp vào hệ thống hiện có." },
  { icon: Users, title: "Đào tạo vận hành", desc: "Hướng dẫn kỹ thuật và đào tạo bảo trì cho đội ngũ doanh nghiệp." },
  { icon: HeartHandshake, title: "Hậu mãi dài hạn", desc: "Đồng hành kỹ thuật xuyên suốt vòng đời sản phẩm." },
];

export default function SolutionEcosystem() {
  return (
    <section className="py-24 bg-white relative overflow-hidden border-t border-brand-dark/5" id="Giải pháp">
      <div className="bg-mesh-light opacity-5"></div>
      
      <div className="container-custom relative z-10">
        <div className="mb-20">
          <div className="kicker">The Ecosystem</div>
          <h2 className="text-4xl md:text-6xl mb-8 text-brand-dark">GIẢI PHÁP NĂNG LƯỢNG <br /> <span className="text-brand-red">TRỌN GÓI</span></h2>
          <p className="text-brand-dark/40 max-w-xl text-lg">
            PKG Battery xây dựng hệ sinh thái giúp doanh nghiệp tối ưu chi phí sở hữu cao nhất.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 bg-brand-dark/5 gap-[1px]">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: index * 0.05 }}
              viewport={{ once: true }}
              className="bg-white p-12 group hover:bg-brand-muted transition-all"
            >
              <div className="flex flex-col h-full">
                <div className="label-mono text-brand-red mb-8">Process / 0{index + 1}</div>
                <h3 className="text-2xl mb-6 font-bold text-brand-dark group-hover:text-brand-red transition-colors">{step.title}</h3>
                <p className="text-sm text-brand-dark/40 leading-relaxed overflow-hidden">{step.desc}</p>
                <div className="mt-12 pt-8 border-t border-brand-dark/5 flex justify-between items-center">
                  <div className="w-8 h-8 rounded-full border border-brand-dark/10 flex items-center justify-center group-hover:bg-brand-red group-hover:border-brand-red transition-all">
                    <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform group-hover:text-white" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
