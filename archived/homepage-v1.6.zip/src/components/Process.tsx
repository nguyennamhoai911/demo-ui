import { motion } from "motion/react";

const steps = [
  { title: "Đánh giá & Khảo sát", desc: "Đội ngũ kỹ thuật trực tiếp đánh giá hiện trạng và nhu cầu tại doanh nghiệp." },
  { title: "Thiết kế & Mô phỏng", desc: "Tạo bản vẽ kỹ thuật chi tiết và mô phỏng hiệu suất vận hành thực tế." },
  { title: "Sản xuất & Tích hợp", desc: "Sản xuất tổ hợp pin và tích hợp hệ thống quản lý năng lượng BMS." },
  { title: "Đào tạo & Chạy thử", desc: "Bàn giao kỹ thuật, hướng dẫn vận hành và chạy thử nghiệm đầy tải." },
  { title: "Hậu mãi & Giám sát", desc: "Cung cấp chế độ bảo hành chuyên sâu và hỗ trợ kỹ thuật định kỳ." },
];

export default function Process() {
  return (
    <section className="py-24 bg-brand-muted" id="Quy trình">
      <div className="container-custom border-x border-brand-dark/5">
        <div className="mb-20">
          <div className="kicker">Step by Step</div>
          <h2 className="text-4xl md:text-6xl mb-0 uppercase tracking-tighter text-brand-dark">
            QUY TRÌNH HỢP TÁC <br /> <span className="text-brand-red">CHUYÊN NGHIỆP</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-5 bg-brand-dark/5 gap-[1px]">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-12 group hover:bg-brand-red transition-all"
            >
              <div className="text-8xl font-black text-brand-dark group-hover:text-white transition-all duration-500 tracking-[-0.05em] mb-8 opacity-5 group-hover:opacity-100">
                0{index + 1}
              </div>
              <h3 className="text-lg mb-4 font-bold tracking-tight text-brand-dark group-hover:text-white">{step.title}</h3>
              <p className="text-sm text-brand-dark/40 group-hover:text-white/80 leading-relaxed h-20 overflow-hidden">{step.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 border-l border-brand-red p-12 bg-white border-r border-brand-dark/5">
          <h4 className="text-2xl mb-4 font-bold text-brand-dark">CAM KẾT KỸ THUẬT TỪ PKG</h4>
          <p className="text-brand-dark/40 text-lg italic max-w-3xl">
            "Chúng tôi đồng hành cùng khách hàng không chỉ như một nhà cung cấp, mà là một đội ngũ kỹ thuật nội bộ, 
            đảm bảo hệ thống năng lượng luôn ở trạng thái sẵn sàng cao nhất."
          </p>
        </div>
      </div>
    </section>
  );
}
