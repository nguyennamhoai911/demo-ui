import { motion } from "motion/react";
import { ArrowRight, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? "nav-glass py-4 shadow-xl text-brand-dark" : "bg-transparent py-8 text-brand-dark"
      }`}
    >
      <div className="container-custom flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="font-display font-black text-2xl tracking-[-0.05em] flex items-center gap-1">
            PKG <span className="text-brand-red">BATTERY</span>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-12">
          {["Sản phẩm", "Giải pháp", "Năng lực", "Quy trình"].map((item) => (
            <a 
              key={item} 
              href={`#${item}`} 
              className="font-bold text-[11px] uppercase tracking-[0.1em] hover:text-brand-red transition-colors"
            >
              {item}
            </a>
          ))}
          <div className="h-4 w-[1px] bg-brand-dark/10 mx-2"></div>
          <div className="text-[11px] font-black tracking-widest opacity-50">EN / VN</div>
        </div>

        <button 
          className="lg:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-full left-0 right-0 bg-white shadow-xl p-8 lg:hidden flex flex-col gap-6"
        >
          {["Sản phẩm", "Giải pháp", "Năng lực", "Quy trình"].map((item) => (
            <a 
              key={item} 
              href={`#${item}`} 
              className="font-bold text-lg uppercase tracking-widest text-brand-dark hover:text-brand-red"
              onClick={() => setMobileMenuOpen(false)}
            >
              {item}
            </a>
          ))}
          <button className="btn-primary w-full">
            NHẬN TƯ VẤN KỸ THUẬT
          </button>
        </motion.div>
      )}
    </nav>
  );
}
