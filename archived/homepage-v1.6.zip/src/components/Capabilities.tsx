import { motion } from "motion/react";

const stats = [
  { label: "Năm kinh nghiệm", value: "10+" },
  { label: "Dự án hoàn thành", value: "500+" },
  { label: "Khách hàng doanh nghiệp", value: "200+" },
  { label: "Chứng nhận quốc tế", value: "05+" },
];

export default function Capabilities() {
  return (
    <section className="py-24 bg-white" id="Năng lực">
      <div className="container-custom border-x border-brand-dark/5">
        <div className="grid lg:grid-cols-2 gap-20 py-20 border-b border-brand-dark/5">
          <div>
            <div className="kicker">Real World Performance</div>
            <h2 className="text-4xl md:text-7xl mb-0 leading-[0.85] text-brand-dark">NĂNG LỰC <br /> <span className="text-brand-red">THỰC TIỄN</span></h2>
          </div>
          <div className="flex items-end">
            <p className="max-w-md text-brand-dark/40 text-lg leading-relaxed">
              PKG Battery đầu tư vào công nghệ và khả năng đồng hành dài hạn cùng doanh nghiệp, đáp ứng các tiêu chuẩn khắt khe nhất thế giới.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 bg-brand-dark/5 gap-[1px]">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-12 group hover:bg-brand-muted transition-all"
            >
              <div className="label-mono mb-6 text-brand-red">{stat.label}</div>
              <div className="text-6xl md:text-8xl font-black mb-4 text-brand-dark group-hover:text-brand-red transition-all duration-500 tracking-[-0.05em]">
                {stat.value}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="relative group overflow-hidden mt-20 border border-brand-dark/5">
          <img 
            src="https://images.unsplash.com/photo-1565173385839-86646543787a?auto=format&fit=crop&q=80&w=1600" 
            alt="PKG Factory" 
            className="w-full h-[600px] object-cover grayscale opacity-10 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000"
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-0 left-0 right-0 p-12 bg-gradient-to-t from-white to-transparent">
             <div className="grid md:grid-cols-2 gap-12 items-end">
               <div>
                  <div className="label-mono text-brand-red">Innovation / Production</div>
                  <h3 className="text-3xl mb-4 text-brand-dark">DÂY CHUYỀN SẢN XUẤT ĐẠT CHUẨN QUỐC TẾ</h3>
                  <div className="flex gap-4 mt-8">
                    {['ISO 9001', 'IEC 62133', 'UL', 'CE'].map(cert => (
                      <div key={cert} className="px-5 py-2 border border-brand-dark/10 text-brand-dark text-[10px] font-black tracking-widest bg-white/50 backdrop-blur-md">
                        {cert}
                      </div>
                    ))}
                  </div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
}
