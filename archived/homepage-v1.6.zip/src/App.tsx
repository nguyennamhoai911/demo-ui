import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import PainPoints from "./components/PainPoints";
import SolutionEcosystem from "./components/SolutionEcosystem";
import ProductCategory from "./components/ProductCategory";
import USP from "./components/USP";
import Capabilities from "./components/Capabilities";
import Process from "./components/Process";
import CaseStudies from "./components/CaseStudies";
import { ContactCTA, Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <PainPoints />
        <SolutionEcosystem />
        <ProductCategory />
        <USP />
        <Capabilities />
        <Process />
        <CaseStudies />
        <ContactCTA />
      </main>
      <Footer />
    </div>
  );
}
