import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const POINTS = [
  "Tư duy giải pháp, không chỉ bán sản phẩm",
  "Phục vụ nhiều ứng dụng doanh nghiệp",
  "Hỗ trợ kỹ thuật và triển khai tận nơi",
  "Tùy chỉnh theo bài toán cụ thể",
  "Hướng tới uptime, reliability và TCO",
  "Hợp tác với khách hàng trong nước, FDI và đối tác kỹ thuật",
];

export function Why() {
  return (
    <section className="relative bg-[#f5f5f5] py-32">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-12 gap-8">
          <div className="col-span-12 lg:col-span-5 relative overflow-hidden bg-black min-h-[520px]">
            <ImageWithFallback src="https://images.unsplash.com/photo-1720036236192-9607cc3f262b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" alt="" className="w-full h-full object-cover opacity-75" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            <div className="absolute inset-0 p-8 flex flex-col justify-end text-white">
              <div className="text-white/70 tracking-[0.22em]" style={{ fontSize: 10 }}>WHY PKG</div>
              <h3 className="mt-3" style={{ fontSize: 32, fontWeight: 600, lineHeight: 1.05 }}>Kỹ thuật nghiêm túc.<br />Triển khai thực chiến.</h3>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-7">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-black/60" style={{ fontSize: 11 }}>08 · WHY PKG BATTERY</span>
            </div>
            <h2 className="text-black mb-10" style={{ fontSize: "clamp(28px, 3.8vw, 48px)", fontWeight: 600, lineHeight: 1.05, letterSpacing: "-0.02em" }}>
              Lý do PKG Battery phù hợp<br />với các doanh nghiệp cần<br /><span className="text-[#E11D2A]">giải pháp nghiêm túc.</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-black/10">
              {POINTS.map((p, i) => (
                <motion.div
                  key={p}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.06 }}
                  className="bg-[#f5f5f5] p-6 group relative"
                >
                  <div className="absolute top-0 left-0 w-0 h-0.5 bg-[#E11D2A] group-hover:w-full transition-all duration-500" />
                  <div className="text-[#E11D2A] mb-3" style={{ fontSize: 13, fontWeight: 600 }}>0{i + 1}</div>
                  <p className="text-black" style={{ fontSize: 15, lineHeight: 1.5, fontWeight: 500 }}>{p}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
