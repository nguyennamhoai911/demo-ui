import { motion, useInView } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const STATS = [
  { v: 15, suf: "+", t: "Năm kinh nghiệm ngành", note: "[Cần xác nhận]" },
  { v: 8, suf: "", t: "Đại lý toàn quốc", note: "[Cần xác nhận]" },
  { v: 120, suf: "+", t: "Dự án / khách hàng B2B", note: "[Cần xác nhận]" },
  { v: 7, suf: "", t: "Nhóm ứng dụng phục vụ", note: "" },
];

function Counter({ to, suf }: { to: number; suf: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const dur = 1500;
    const tick = (now: number) => {
      const p = Math.min((now - start) / dur, 1);
      setN(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, to]);
  return <div ref={ref} style={{ fontSize: "clamp(56px, 7vw, 104px)", fontWeight: 600, lineHeight: 0.95, letterSpacing: "-0.03em" }}>{n}<span className="text-[#E11D2A]">{suf}</span></div>;
}

const CERTS = ["ISO 9001", "IEC 62619", "UN 38.3", "CE / RoHS", "Test Report", "Compliance"];

export function TrustCenter() {
  return (
    <section className="relative bg-black text-white py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.04]" style={{
        backgroundImage: "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
        backgroundSize: "60px 60px",
      }} />

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-px bg-[#E11D2A]" />
            <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>09 · TRUST CENTER</span>
          </div>
          <h2 style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}>
            Quy mô, năng lực và<br />
            <span className="text-[#E11D2A]">chứng nhận kỹ thuật.</span>
          </h2>
        </div>

        {/* Tier A — stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10 mb-20">
          {STATS.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
              className="bg-black p-8"
            >
              <Counter to={s.v} suf={s.suf} />
              <div className="mt-4 text-white/70" style={{ fontSize: 14 }}>{s.t}</div>
              {s.note && <div className="mt-1 text-white/30 tracking-wider" style={{ fontSize: 10 }}>{s.note}</div>}
            </motion.div>
          ))}
        </div>

        {/* Tier B — certifications */}
        <div className="grid grid-cols-12 gap-6 mb-20">
          <div className="col-span-12 lg:col-span-4">
            <div className="text-white/50 tracking-[0.22em] mb-4" style={{ fontSize: 10 }}>— CERTIFICATIONS</div>
            <h3 style={{ fontSize: 28, fontWeight: 600, lineHeight: 1.1 }}>Chứng chỉ, test report<br />và compliance.</h3>
            <p className="mt-4 text-white/60" style={{ fontSize: 14, lineHeight: 1.6 }}>
              Các tài liệu xác nhận và compliance hỗ trợ triển khai cho khách hàng doanh nghiệp, FDI và đối tác quốc tế. [Cần xác nhận]
            </p>
          </div>
          <div className="col-span-12 lg:col-span-8 grid grid-cols-2 md:grid-cols-3 gap-4">
            {CERTS.map((c, i) => (
              <motion.div
                key={c}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.06 }}
                className="relative aspect-[3/4] bg-white/[0.03] border border-white/15 p-5 flex flex-col justify-between hover:bg-white/[0.07] transition-colors group"
              >
                <div className="text-white/50 tracking-[0.2em]" style={{ fontSize: 9 }}>CERT · 0{i + 1}</div>
                <div>
                  <div className="w-full h-px bg-white/20 mb-4" />
                  <div style={{ fontSize: 16, fontWeight: 500 }}>{c}</div>
                  <div className="mt-2 text-white/40" style={{ fontSize: 11 }}>Hỗ trợ compliance</div>
                </div>
                <div className="absolute inset-0 border-2 border-[#E11D2A] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Tier C — Enterprise capability gallery */}
        <div className="grid grid-cols-12 gap-4">
          <div className="col-span-12 md:col-span-8 aspect-video relative overflow-hidden">
            <ImageWithFallback src="https://images.unsplash.com/photo-1720036236486-d0ea78059919?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1600" alt="" className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>FACILITY · 01</div>
          </div>
          <div className="col-span-6 md:col-span-4 aspect-square relative overflow-hidden">
            <ImageWithFallback src="https://images.unsplash.com/photo-1745267652572-573ae6e81e40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" alt="" className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>TEAM · 02</div>
          </div>
          <div className="col-span-6 md:col-span-4 aspect-[3/4] relative overflow-hidden">
            <ImageWithFallback src="https://images.unsplash.com/photo-1736779181091-5fed004bea5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" alt="" className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>TESTING · 03</div>
          </div>
          <div className="col-span-6 md:col-span-4 aspect-[3/4] relative overflow-hidden">
            <ImageWithFallback src="https://images.unsplash.com/photo-1721937127582-ed331de95a04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" alt="" className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>WAREHOUSE · 04</div>
          </div>
          <div className="col-span-12 md:col-span-4 aspect-[3/4] relative overflow-hidden">
            <ImageWithFallback src="https://images.unsplash.com/photo-1720036236828-1c6a472db1c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" alt="" className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>ENGINEERING · 05</div>
          </div>
        </div>
      </div>
    </section>
  );
}
