import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, ArrowUpRight, Menu, X } from "lucide-react";

const NAV = [
  { label: "Giải pháp", items: ["Pin công nghiệp", "Bộ sạc / Trạm sạc", "ESS", "Tư vấn kỹ thuật"] },
  { label: "Sản phẩm", items: ["Xe nâng điện", "Xe điện du lịch", "AGV / Robot", "Bộ sạc", "ESS"] },
  { label: "Ứng dụng", items: ["Logistics", "Manufacturing", "Warehousing", "Automation", "Resort Mobility"] },
  { label: "OEM / ODM" },
  { label: "Về doanh nghiệp" },
  { label: "Đại lý" },
  { label: "Tin tức" },
  { label: "Liên hệ" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-black/85 backdrop-blur-xl border-b border-white/10"
          : "bg-gradient-to-b from-black/60 to-transparent"
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 h-20 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="relative w-9 h-9 flex items-center justify-center">
            <div className="absolute inset-0 bg-[#E11D2A] rotate-45 group-hover:rotate-[60deg] transition-transform duration-500" />
            <span className="relative text-white tracking-widest" style={{ fontSize: 13, fontWeight: 700 }}>P</span>
          </div>
          <div className="text-white tracking-[0.18em]" style={{ fontSize: 14, fontWeight: 600 }}>
            PKG<span className="text-[#E11D2A]">·</span>BATTERY
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map((n) => (
            <div
              key={n.label}
              className="relative"
              onMouseEnter={() => n.items && setOpen(n.label)}
              onMouseLeave={() => setOpen(null)}
            >
              <button className="flex items-center gap-1 px-3.5 py-2 text-white/80 hover:text-white transition-colors" style={{ fontSize: 13, letterSpacing: "0.02em" }}>
                {n.label}
                {n.items && <ChevronDown className="w-3 h-3 opacity-60" />}
              </button>
              <AnimatePresence>
                {n.items && open === n.label && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-full left-0 pt-3 min-w-[260px]"
                  >
                    <div className="bg-black border border-white/10 p-2">
                      {n.items.map((it) => (
                        <a key={it} href="#" className="flex items-center justify-between px-3 py-2.5 text-white/70 hover:text-white hover:bg-white/5 transition-colors group" style={{ fontSize: 13 }}>
                          <span>{it}</span>
                          <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 text-[#E11D2A] transition-opacity" />
                        </a>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-1.5 text-white/60 border-l border-white/10 pl-4" style={{ fontSize: 11, letterSpacing: "0.12em" }}>
            <span className="text-white">VI</span>
            <span className="opacity-40">/</span>
            <span>EN</span>
          </div>
          <a href="#contact" className="hidden md:inline-flex items-center gap-2 bg-[#E11D2A] hover:bg-[#c9141f] text-white px-5 py-2.5 transition-colors group" style={{ fontSize: 13, letterSpacing: "0.04em" }}>
            Nhận tư vấn kỹ thuật
            <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
          <button onClick={() => setMobile(!mobile)} className="lg:hidden text-white p-2">
            {mobile ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobile && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="lg:hidden overflow-hidden bg-black border-t border-white/10"
          >
            <div className="p-6 space-y-1">
              {NAV.map((n) => (
                <a key={n.label} href="#" className="block py-3 text-white/80 border-b border-white/5" style={{ fontSize: 14 }}>
                  {n.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
