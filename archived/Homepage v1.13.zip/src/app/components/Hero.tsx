import { motion } from "motion/react";
import { ArrowUpRight, Zap, Cpu, Battery, Network } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section className="relative min-h-screen bg-black text-white overflow-hidden pt-20">
      {/* Background layers */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1721938170874-318bdeddea6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920"
          alt=""
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />
      </div>

      {/* Grid overlay */}
      <div className="absolute inset-0 opacity-[0.06]" style={{
        backgroundImage: "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
        backgroundSize: "80px 80px",
      }} />

      {/* Animated red signal traces */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
        className="absolute top-[30%] left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#E11D2A] to-transparent origin-left"
      />
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 2.2, delay: 0.3, ease: "easeOut" }}
        className="absolute bottom-[22%] left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent origin-right"
      />

      {/* Ambient glow */}
      <motion.div
        animate={{ opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 6, repeat: Infinity }}
        className="absolute right-[10%] top-[30%] w-[500px] h-[500px] bg-[#E11D2A]/20 blur-[160px] rounded-full"
      />

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10 pt-14 pb-28">
        {/* Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="flex items-center gap-3 mb-10"
        >
          <div className="w-10 h-px bg-[#E11D2A]" />
          <span className="tracking-[0.22em] text-white/70" style={{ fontSize: 11 }}>
            PIN LITHIUM CÔNG NGHIỆP · GIẢI PHÁP SẠC · OEM / ODM
          </span>
        </motion.div>

        <div className="grid grid-cols-12 gap-8">
          {/* Headline */}
          <div className="col-span-12 lg:col-span-8">
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.1 }}
              className="text-white"
              style={{ fontSize: "clamp(44px, 7vw, 104px)", fontWeight: 600, lineHeight: 0.98, letterSpacing: "-0.03em" }}
            >
              Giải pháp pin<br />
              lithium<span className="text-[#E11D2A]">_</span>công nghiệp<br />
              <span className="text-white/50">cho vận hành</span><br />
              quy mô lớn.
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="mt-10 text-white/65 max-w-xl"
              style={{ fontSize: 16, lineHeight: 1.65 }}
            >
              PKG Battery phát triển hệ pin, sạc và giải pháp kỹ thuật cho xe nâng điện, AGV/robot, xe điện du lịch, ESS và nhiều ứng dụng doanh nghiệp khác — với định hướng tối ưu uptime, độ tin cậy và chi phí dài hạn.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="mt-10 flex flex-wrap items-center gap-4"
            >
              <a href="#contact" className="inline-flex items-center gap-3 bg-[#E11D2A] hover:bg-[#c9141f] text-white px-7 py-4 group transition-colors" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
                NHẬN TƯ VẤN KỸ THUẬT
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
              <a href="#products" className="inline-flex items-center gap-3 border border-white/20 hover:border-white/50 text-white px-7 py-4 group transition-colors" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
                KHÁM PHÁ HỆ GIẢI PHÁP
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
            </motion.div>
          </div>

          {/* Right stat panel */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.4 }}
            className="col-span-12 lg:col-span-4 flex flex-col gap-4 self-end"
          >
            <div className="relative border border-white/15 bg-white/[0.03] backdrop-blur-sm p-6 overflow-hidden">
              <div className="absolute top-0 left-0 w-12 h-px bg-[#E11D2A]" />
              <div className="flex items-center gap-2 text-white/50 tracking-[0.2em] mb-4" style={{ fontSize: 10 }}>
                <span className="w-1 h-1 bg-[#E11D2A]" /> SYSTEM OVERVIEW
              </div>
              <div className="text-white" style={{ fontSize: 52, fontWeight: 600, lineHeight: 1 }}>05</div>
              <div className="mt-2 text-white/70" style={{ fontSize: 13 }}>Dòng sản phẩm chủ lực</div>
              <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between text-white/50" style={{ fontSize: 11 }}>
                <span>Xem hệ giải pháp</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Battery, k: "OEM", v: "ODM" },
                { icon: Network, k: "Đại lý", v: "Toàn quốc" },
                { icon: Cpu, k: "BMS", v: "Tích hợp" },
                { icon: Zap, k: "Uptime", v: "24/7" },
              ].map((x, i) => (
                <div key={i} className="border border-white/10 bg-white/[0.02] p-4 hover:bg-white/[0.05] transition-colors">
                  <x.icon className="w-4 h-4 text-[#E11D2A] mb-3" />
                  <div className="text-white/50 tracking-wider" style={{ fontSize: 10 }}>{x.k}</div>
                  <div className="text-white mt-1" style={{ fontSize: 14 }}>{x.v}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom ticker */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="mt-20 pt-8 border-t border-white/10 flex flex-wrap items-center justify-between gap-6 text-white/50"
          style={{ fontSize: 11, letterSpacing: "0.18em" }}
        >
          <span>◐ CINEMATIC ENTERPRISE SYSTEMS</span>
          <span>LOGISTICS · AGV · ESS · FORKLIFT · MOBILITY</span>
          <span className="flex items-center gap-2">
            <motion.span animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 2, repeat: Infinity }} className="w-1.5 h-1.5 bg-[#E11D2A]" />
            LIVE · 2026
          </span>
        </motion.div>
      </div>
    </section>
  );
}
