import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const PRODUCTS = [
  {
    k: "01",
    t: "Pin Lithium cho Xe Nâng Điện",
    d: "Giải pháp pin công suất cao cho forklift điện hoạt động liên tục trong kho vận và sản xuất.",
    tags: ["Logistics", "Manufacturing", "3-shift"],
    img: "https://images.unsplash.com/photo-1740914994657-f1cdffdc418e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1600",
    featured: true,
  },
  {
    k: "02",
    t: "Pin Lithium cho Xe Điện Du Lịch",
    d: "Pin tối ưu cho xe du lịch, resort mobility — nhẹ, bền, sạc nhanh.",
    tags: ["Resort", "Mobility"],
    img: "https://images.unsplash.com/photo-1622118490627-e7db0f0765ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
  },
  {
    k: "03",
    t: "Pin cho Xe AGV / Robot",
    d: "Tích hợp BMS chuyên biệt cho tự hành, sạc opportunity & swap.",
    tags: ["AGV", "Robot", "Automation"],
    img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
  },
  {
    k: "04",
    t: "Bộ Sạc – Trạm Sạc",
    d: "Hệ sạc công nghiệp đa cổng, công suất lớn, giao thức chuẩn OEM.",
    tags: ["Charger", "Station"],
    img: "https://images.unsplash.com/photo-1755555707440-188120a3c521?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
  },
  {
    k: "05",
    t: "Hệ thống Pin Lưu Trữ ESS",
    d: "Cabinet ESS cho peak-shaving, backup và tích hợp năng lượng tái tạo.",
    tags: ["ESS", "Energy", "Backup"],
    img: "https://images.unsplash.com/photo-1563456019560-2b37aa7ad890?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200",
  },
];

function Card({ p, className = "" }: { p: typeof PRODUCTS[number]; className?: string }) {
  return (
    <motion.a
      href="#"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className={`group relative block overflow-hidden bg-black ${className}`}
    >
      <div className="absolute inset-0">
        <ImageWithFallback src={p.img} alt={p.t} className="w-full h-full object-cover opacity-85 group-hover:opacity-100 group-hover:scale-105 transition-all duration-[1.2s]" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
      </div>
      <div className="relative p-7 lg:p-9 flex flex-col justify-between min-h-full text-white">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2 text-white/70 tracking-[0.2em]" style={{ fontSize: 10 }}>
            <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> PRODUCT · {p.k}
          </div>
          <ArrowUpRight className="w-5 h-5 text-white/70 group-hover:text-[#E11D2A] group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
        </div>
        <div className="mt-16">
          <h3 className="text-white" style={{ fontSize: p.featured ? 32 : 22, fontWeight: 600, lineHeight: 1.1, letterSpacing: "-0.01em" }}>{p.t}</h3>
          <p className="mt-3 text-white/65 max-w-md" style={{ fontSize: 13, lineHeight: 1.6 }}>{p.d}</p>
          <div className="mt-5 flex flex-wrap gap-2">
            {p.tags.map((tag) => (
              <span key={tag} className="border border-white/20 px-3 py-1 text-white/80 tracking-wider" style={{ fontSize: 10 }}>{tag}</span>
            ))}
          </div>
          <div className="mt-6 flex items-center gap-2 text-white/70 group-hover:text-white transition-colors" style={{ fontSize: 12, letterSpacing: "0.06em" }}>
            XEM CHI TIẾT
            <span className="w-8 h-px bg-[#E11D2A] group-hover:w-16 transition-all" />
          </div>
        </div>
      </div>
    </motion.a>
  );
}

export function Products() {
  return (
    <section id="products" className="relative bg-[#0a0a0a] text-white py-32">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-16">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>05 · PRODUCT SYSTEM</span>
            </div>
            <h2 style={{ fontSize: "clamp(32px, 4.8vw, 64px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}>
              5 nhóm sản phẩm<br />và giải pháp <span className="text-[#E11D2A]">chủ lực.</span>
            </h2>
          </div>
          <a href="#" className="inline-flex items-center gap-2 text-white/80 hover:text-white group" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
            XEM TOÀN BỘ DANH MỤC <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>

        <div className="grid grid-cols-12 gap-5">
          <Card p={PRODUCTS[0]} className="col-span-12 lg:col-span-8 min-h-[560px]" />
          <Card p={PRODUCTS[1]} className="col-span-12 md:col-span-6 lg:col-span-4 min-h-[560px]" />
          <Card p={PRODUCTS[2]} className="col-span-12 md:col-span-6 lg:col-span-4 min-h-[420px]" />
          <Card p={PRODUCTS[3]} className="col-span-12 md:col-span-6 lg:col-span-4 min-h-[420px]" />
          <Card p={PRODUCTS[4]} className="col-span-12 md:col-span-12 lg:col-span-4 min-h-[420px]" />
        </div>
      </div>
    </section>
  );
}
