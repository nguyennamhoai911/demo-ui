import { motion } from "motion/react";
import { ArrowUpRight, Layers, Cpu, Settings, Handshake } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const CAPS = [
  { icon: Layers, t: "Cấu hình tùy biến", d: "Dung lượng, điện áp, form-factor theo yêu cầu tích hợp thiết bị." },
  { icon: Cpu, t: "BMS chuyên biệt", d: "Firmware, giao thức CAN/RS485/Modbus và logic bảo vệ theo ứng dụng." },
  { icon: Settings, t: "Tích hợp cơ khí", d: "Hỗ trợ thiết kế cabinet, kết nối, giải nhiệt và an toàn vận hành." },
  { icon: Handshake, t: "Hợp tác OEM / ODM", d: "Đồng phát triển sản phẩm cho đối tác doanh nghiệp và quốc tế." },
];

export function OEM() {
  return (
    <section className="relative bg-black text-white py-32 overflow-hidden">
      <div className="absolute inset-0">
        <ImageWithFallback src="https://images.unsplash.com/photo-1760842543741-876d7837fa0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920" alt="" className="w-full h-full object-cover opacity-25" />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/40" />
      </div>

      <div className="absolute inset-0 opacity-[0.05]" style={{
        backgroundImage: "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
        backgroundSize: "60px 60px",
      }} />

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-12 gap-8">
          <div className="col-span-12 lg:col-span-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>06 · OEM / ODM · CUSTOM ENGINEERING</span>
            </div>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}
            >
              Tùy chỉnh giải pháp<br />
              và hợp tác <span className="text-[#E11D2A]">OEM / ODM.</span>
            </motion.h2>
            <p className="mt-8 text-white/65 max-w-xl" style={{ fontSize: 16, lineHeight: 1.7 }}>
              PKG Battery định hướng hỗ trợ các bài toán pin lithium theo yêu cầu kỹ thuật riêng — tùy chỉnh cấu hình, ứng dụng, tích hợp và hướng hợp tác OEM / ODM cho doanh nghiệp và đối tác kỹ thuật. <span className="text-white/40">[Cần xác nhận với PKG Battery]</span>
            </p>

            <div className="mt-10 flex flex-wrap gap-4">
              <a href="#contact" className="inline-flex items-center gap-3 bg-[#E11D2A] hover:bg-[#c9141f] text-white px-7 py-4 group" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
                TRAO ĐỔI OEM / ODM <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
              <a href="#contact" className="inline-flex items-center gap-3 border border-white/25 hover:border-white/60 text-white px-7 py-4 group" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
                GỬI YÊU CẦU DỰ ÁN <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-6 grid grid-cols-2 gap-4">
            {CAPS.map((c, i) => (
              <motion.div
                key={c.t}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="relative border border-white/15 bg-white/[0.03] backdrop-blur-sm p-7 hover:bg-white/[0.06] transition-colors group"
              >
                <div className="absolute top-0 left-0 w-0 h-0.5 bg-[#E11D2A] group-hover:w-full transition-all duration-500" />
                <c.icon className="w-6 h-6 text-[#E11D2A] mb-6" />
                <h3 style={{ fontSize: 17, fontWeight: 500 }}>{c.t}</h3>
                <p className="mt-3 text-white/60" style={{ fontSize: 13, lineHeight: 1.6 }}>{c.d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
