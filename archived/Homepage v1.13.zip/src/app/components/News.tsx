import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const FEATURED = {
  tag: "KỸ THUẬT",
  t: "Tối ưu TCO pin lithium trong vận hành xe nâng điện 3 ca",
  d: "Phân tích các yếu tố ảnh hưởng đến tổng chi phí sở hữu khi chuyển đổi sang hệ pin lithium công nghiệp cho kho vận quy mô lớn.",
  date: "14.04.2026",
  read: "8 phút",
  img: "https://images.unsplash.com/photo-1740914994657-f1cdffdc418e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1600",
};

const POSTS = [
  { tag: "ỨNG DỤNG", t: "AGV/Robot: chọn cấu hình pin cho sạc opportunity", date: "09.04.2026", img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" },
  { tag: "CÔNG NGHỆ", t: "BMS thế hệ mới: điều phối nhiệt thông minh", date: "02.04.2026", img: "https://images.unsplash.com/photo-1760842543741-876d7837fa0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" },
  { tag: "DOANH NGHIỆP", t: "PKG mở rộng mạng lưới đại lý miền Trung", date: "28.03.2026", img: "https://images.unsplash.com/photo-1722003227551-7fe5b6f0f6ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" },
];

export function News() {
  return (
    <section className="relative bg-white py-32">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-16">
          <div className="max-w-2xl">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-black/60" style={{ fontSize: 11 }}>11 · TECHNICAL INSIGHTS</span>
            </div>
            <h2 className="text-black" style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}>
              Tin tức, kiến thức kỹ thuật<br />và cập nhật <span className="text-[#E11D2A]">từ PKG Battery.</span>
            </h2>
          </div>
          <a href="#" className="inline-flex items-center gap-2 text-black/80 hover:text-black group" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
            XEM TẤT CẢ BÀI VIẾT <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>

        <div className="grid grid-cols-12 gap-6">
          <motion.a
            href="#"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="col-span-12 lg:col-span-7 group block"
          >
            <div className="relative aspect-[4/3] overflow-hidden bg-black">
              <ImageWithFallback src={FEATURED.img} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
              <div className="absolute top-5 left-5 bg-[#E11D2A] text-white tracking-[0.2em] px-3 py-1.5" style={{ fontSize: 10 }}>FEATURED</div>
            </div>
            <div className="mt-6 flex items-center gap-4 text-black/50 tracking-wider" style={{ fontSize: 11 }}>
              <span>{FEATURED.tag}</span>
              <span className="w-1 h-1 bg-black/30 rounded-full" />
              <span>{FEATURED.date}</span>
              <span className="w-1 h-1 bg-black/30 rounded-full" />
              <span>{FEATURED.read} đọc</span>
            </div>
            <h3 className="mt-4 text-black group-hover:text-[#E11D2A] transition-colors" style={{ fontSize: 28, fontWeight: 600, lineHeight: 1.15, letterSpacing: "-0.01em" }}>{FEATURED.t}</h3>
            <p className="mt-3 text-black/60 max-w-xl" style={{ fontSize: 15, lineHeight: 1.6 }}>{FEATURED.d}</p>
          </motion.a>

          <div className="col-span-12 lg:col-span-5 flex flex-col gap-6">
            {POSTS.map((p, i) => (
              <motion.a
                key={p.t}
                href="#"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="group grid grid-cols-12 gap-4 items-center pb-6 border-b border-black/10 last:border-b-0"
              >
                <div className="col-span-4 aspect-square overflow-hidden bg-black">
                  <ImageWithFallback src={p.img} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
                </div>
                <div className="col-span-8">
                  <div className="flex items-center gap-2 text-black/50 tracking-wider" style={{ fontSize: 10 }}>
                    <span className="w-1 h-1 bg-[#E11D2A]" /> {p.tag} · {p.date}
                  </div>
                  <h4 className="mt-2 text-black group-hover:text-[#E11D2A] transition-colors" style={{ fontSize: 16, fontWeight: 500, lineHeight: 1.3 }}>{p.t}</h4>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
