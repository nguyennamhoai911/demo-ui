import { motion } from "motion/react";
import { MapPin, Phone, ArrowUpRight } from "lucide-react";

const DEALERS = [
  { city: "Hà Nội", region: "Miền Bắc", phone: "024 · ****", x: 48, y: 18 },
  { city: "Hải Phòng", region: "Miền Bắc", phone: "0225 · ****", x: 54, y: 22 },
  { city: "Đà Nẵng", region: "Miền Trung", phone: "0236 · ****", x: 62, y: 48 },
  { city: "Quy Nhơn", region: "Miền Trung", phone: "0256 · ****", x: 68, y: 58 },
  { city: "TP. HCM", region: "Miền Nam", phone: "028 · ****", x: 54, y: 84 },
  { city: "Bình Dương", region: "Miền Nam", phone: "0274 · ****", x: 50, y: 82 },
  { city: "Cần Thơ", region: "Miền Nam", phone: "0292 · ****", x: 42, y: 92 },
  { city: "Nha Trang", region: "Miền Trung", phone: "0258 · ****", x: 72, y: 68 },
];

export function DealerMap() {
  return (
    <section className="relative bg-[#0a0a0a] text-white py-32 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="mb-16 max-w-3xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-px bg-[#E11D2A]" />
            <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>10 · DEALER NETWORK</span>
          </div>
          <h2 style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}>
            Mạng lưới đại lý và phân phối<br />trên <span className="text-[#E11D2A]">toàn Việt Nam.</span>
          </h2>
          <p className="mt-6 text-white/60" style={{ fontSize: 15, lineHeight: 1.7 }}>
            {DEALERS.length} điểm phục vụ hiện tại [Cần xác nhận] — mở rộng liên tục theo nhu cầu doanh nghiệp.
          </p>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Map */}
          <div className="col-span-12 lg:col-span-7 relative aspect-[3/4] bg-black border border-white/10">
            <div className="absolute inset-0 opacity-[0.08]" style={{
              backgroundImage: "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
              backgroundSize: "40px 40px",
            }} />
            {/* Stylized Vietnam shape */}
            <svg viewBox="0 0 100 120" className="absolute inset-0 w-full h-full p-6" preserveAspectRatio="xMidYMid meet">
              <path
                d="M48 8 Q52 14 50 20 Q55 24 54 30 Q60 36 62 44 Q68 50 66 58 Q74 64 72 72 Q66 78 60 80 Q56 86 52 92 Q46 96 42 100 L40 108 L44 110 L40 115 L36 110 Q32 102 34 94 Q38 86 40 78 Q42 68 44 58 Q40 48 42 38 Q44 28 46 18 Z"
                fill="none"
                stroke="rgba(255,255,255,0.2)"
                strokeWidth="0.3"
              />
              <path
                d="M48 8 Q52 14 50 20 Q55 24 54 30 Q60 36 62 44 Q68 50 66 58 Q74 64 72 72 Q66 78 60 80 Q56 86 52 92 Q46 96 42 100 L40 108 L44 110 L40 115 L36 110 Q32 102 34 94 Q38 86 40 78 Q42 68 44 58 Q40 48 42 38 Q44 28 46 18 Z"
                fill="rgba(225,29,42,0.08)"
              />
            </svg>

            {DEALERS.map((d, i) => (
              <motion.div
                key={d.city}
                initial={{ scale: 0, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 + i * 0.08, type: "spring" }}
                className="absolute group cursor-pointer"
                style={{ left: `${d.x}%`, top: `${d.y}%`, transform: "translate(-50%, -50%)" }}
              >
                <div className="relative">
                  <motion.div
                    animate={{ scale: [1, 2.2, 1], opacity: [0.6, 0, 0.6] }}
                    transition={{ duration: 2, repeat: Infinity, delay: i * 0.3 }}
                    className="absolute inset-0 bg-[#E11D2A] rounded-full"
                  />
                  <div className="relative w-3 h-3 bg-[#E11D2A] rounded-full border-2 border-black" />
                </div>
                <div className="absolute left-5 top-1/2 -translate-y-1/2 bg-black border border-white/20 px-3 py-2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-10">
                  <div className="text-white" style={{ fontSize: 12, fontWeight: 500 }}>{d.city}</div>
                  <div className="text-white/50" style={{ fontSize: 10 }}>{d.region}</div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* List */}
          <div className="col-span-12 lg:col-span-5">
            <div className="grid grid-cols-1 gap-px bg-white/10 border border-white/10">
              {DEALERS.map((d, i) => (
                <motion.a
                  key={d.city}
                  href="#"
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.05 }}
                  className="bg-[#0a0a0a] p-5 flex items-center gap-4 group hover:bg-white/[0.03] transition-colors"
                >
                  <div className="w-10 h-10 border border-white/20 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-[#E11D2A]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white" style={{ fontSize: 14, fontWeight: 500 }}>{d.city}</div>
                    <div className="text-white/50 flex items-center gap-2" style={{ fontSize: 12 }}>
                      {d.region} <span className="opacity-40">·</span> <Phone className="w-3 h-3" /> {d.phone}
                    </div>
                  </div>
                  <ArrowUpRight className="w-4 h-4 text-white/40 group-hover:text-[#E11D2A] group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                </motion.a>
              ))}
            </div>
            <a href="#" className="mt-6 inline-flex items-center gap-2 text-white/70 hover:text-white group" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
              XEM HỆ THỐNG ĐẠI LÝ ĐẦY ĐỦ <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
