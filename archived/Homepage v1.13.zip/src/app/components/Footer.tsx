const COLS = [
  { h: "Sản phẩm", items: ["Xe nâng điện", "Xe điện du lịch", "AGV / Robot", "Bộ sạc / Trạm sạc", "ESS"] },
  { h: "Giải pháp", items: ["Logistics", "Manufacturing", "Automation", "Resort Mobility", "Energy Storage"] },
  { h: "Doanh nghiệp", items: ["Về PKG Battery", "OEM / ODM", "Tin tức", "Đại lý", "Liên hệ"] },
];

export function Footer() {
  return (
    <footer className="bg-black text-white border-t border-white/10">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-20 pb-10">
        <div className="grid grid-cols-12 gap-10 pb-16 border-b border-white/10">
          <div className="col-span-12 lg:col-span-4">
            <div className="flex items-center gap-2.5">
              <div className="relative w-10 h-10 flex items-center justify-center">
                <div className="absolute inset-0 bg-[#E11D2A] rotate-45" />
                <span className="relative text-white tracking-widest" style={{ fontSize: 14, fontWeight: 700 }}>P</span>
              </div>
              <div className="text-white tracking-[0.18em]" style={{ fontSize: 15, fontWeight: 600 }}>
                PKG<span className="text-[#E11D2A]">·</span>BATTERY
              </div>
            </div>
            <p className="mt-6 text-white/55 max-w-sm" style={{ fontSize: 14, lineHeight: 1.65 }}>
              Giải pháp pin lithium công nghiệp, bộ sạc, ESS và tư vấn kỹ thuật cho doanh nghiệp, nhà máy, logistics, AGV/robot và đối tác OEM / ODM.
            </p>
            <div className="mt-8 flex items-center gap-3">
              {["LinkedIn", "YouTube", "Zalo OA"].map((s) => (
                <a key={s} href="#" className="border border-white/15 hover:border-[#E11D2A] px-3 py-1.5 text-white/70 hover:text-white transition-colors" style={{ fontSize: 11, letterSpacing: "0.06em" }}>{s}</a>
              ))}
            </div>
          </div>

          {COLS.map((c) => (
            <div key={c.h} className="col-span-6 md:col-span-4 lg:col-span-2">
              <div className="text-white/50 tracking-[0.22em] mb-5" style={{ fontSize: 10 }}>{c.h.toUpperCase()}</div>
              <ul className="space-y-3">
                {c.items.map((it) => (
                  <li key={it}>
                    <a href="#" className="text-white/70 hover:text-white transition-colors" style={{ fontSize: 13 }}>{it}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="col-span-12 lg:col-span-2">
            <div className="text-white/50 tracking-[0.22em] mb-5" style={{ fontSize: 10 }}>THÔNG TIN</div>
            <div className="space-y-3 text-white/70" style={{ fontSize: 13, lineHeight: 1.6 }}>
              <div>PKG Battery Vietnam</div>
              <div className="text-white/50">Địa chỉ · [Cần xác nhận]</div>
              <div>project@pkgbattery.vn</div>
              <div>+84 · **** · ****</div>
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-white/40" style={{ fontSize: 11, letterSpacing: "0.08em" }}>
          <div>© 2026 PKG BATTERY · ALL RIGHTS RESERVED</div>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">Terms</a>
            <a href="#" className="hover:text-white">Sitemap</a>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> INDUSTRIAL FLAGSHIP · 2026
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
