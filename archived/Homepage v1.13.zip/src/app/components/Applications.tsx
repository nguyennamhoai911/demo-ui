import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const INDUSTRIES = [
  { t: "Logistics", d: "Kho vận, phân phối, chuỗi cung ứng đa ca.", img: "https://images.unsplash.com/photo-1721937127582-ed331de95a04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" },
  { t: "Manufacturing", d: "Nhà máy sản xuất quy mô lớn, dây chuyền tự động.", img: "https://images.unsplash.com/photo-1720036236632-fdb6211cf317?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" },
  { t: "Warehouse", d: "Kho lạnh, kho cao tầng, hệ thống kệ selective.", img: "https://images.unsplash.com/photo-1740914994162-0b2a49280aeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" },
  { t: "AGV / Robot", d: "Tự hành, picking robot, logistics bots.", img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" },
  { t: "Resort Mobility", d: "Xe du lịch điện khu nghỉ dưỡng, campus.", img: "https://images.unsplash.com/photo-1622118490627-e7db0f0765ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" },
  { t: "ESS / Energy", d: "Hệ lưu trữ, peak-shaving, backup infrastructure.", img: "https://images.unsplash.com/photo-1639195046198-a73b6d2d9606?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" },
];

export function Applications() {
  return (
    <section className="relative bg-white py-32">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="mb-16 max-w-3xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-px bg-[#E11D2A]" />
            <span className="tracking-[0.22em] text-black/60" style={{ fontSize: 11 }}>07 · INDUSTRY APPLICATIONS</span>
          </div>
          <h2 className="text-black" style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}>
            Thiết kế cho nhiều môi trường<br />vận hành <span className="text-[#E11D2A]">công nghiệp.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-black/10">
          {INDUSTRIES.map((ind, i) => (
            <motion.a
              key={ind.t}
              href="#"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.05 }}
              className="group relative block bg-white overflow-hidden aspect-[4/5]"
            >
              <ImageWithFallback src={ind.img} alt={ind.t} className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent group-hover:from-black/90 transition-all duration-500" />
              <div className="absolute inset-0 p-7 flex flex-col justify-end text-white">
                <div className="flex items-center gap-2 text-white/70 tracking-[0.22em] mb-3" style={{ fontSize: 10 }}>
                  <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> 0{i + 1}
                </div>
                <h3 style={{ fontSize: 26, fontWeight: 600, letterSpacing: "-0.01em" }}>{ind.t}</h3>
                <div className="overflow-hidden max-h-0 group-hover:max-h-24 transition-all duration-500">
                  <p className="mt-3 text-white/75" style={{ fontSize: 13, lineHeight: 1.6 }}>{ind.d}</p>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
