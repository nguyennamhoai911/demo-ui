import { motion } from "motion/react";

const SECTORS = [
  "Logistics", "Manufacturing", "Warehousing", "Automation",
  "Resort Mobility", "Energy Storage", "Industrial Vehicles", "AGV / Robot",
];

export function TrustBand() {
  return (
    <section className="relative bg-black border-t border-white/10 py-14 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8 mb-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-px bg-[#E11D2A]" />
            <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>TRUSTED ACROSS INDUSTRIES</span>
          </div>
          <p className="text-white/50 max-w-md" style={{ fontSize: 13 }}>
            Phục vụ hệ sinh thái doanh nghiệp công nghiệp — từ logistics đến lưu trữ năng lượng.
          </p>
        </div>

        <div className="relative overflow-hidden">
          <motion.div
            animate={{ x: ["0%", "-50%"] }}
            transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            className="flex gap-12 whitespace-nowrap"
          >
            {[...SECTORS, ...SECTORS, ...SECTORS].map((s, i) => (
              <div key={i} className="flex items-center gap-6 text-white/40 hover:text-white transition-colors" style={{ fontSize: 28, fontWeight: 500, letterSpacing: "-0.01em" }}>
                <span className="w-2 h-2 bg-[#E11D2A]/60 rotate-45" />
                {s}
              </div>
            ))}
          </motion.div>
          <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-black to-transparent" />
          <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-black to-transparent" />
        </div>
      </div>
    </section>
  );
}
