import { motion } from "motion/react";
import { Clock, Wrench, Activity, ShieldAlert, TrendingDown } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const PAINS = [
  { icon: Clock, k: "01", t: "Downtime vận hành", d: "Sạc chậm và hiệu suất kém khiến dây chuyền gián đoạn, gây mất năng suất theo giờ." },
  { icon: Wrench, k: "02", t: "Chi phí bảo trì", d: "Thay thế pin thường xuyên làm tăng OPEX và phức tạp hóa vận hành dài hạn." },
  { icon: Activity, k: "03", t: "Hiệu suất sai kịch bản", d: "Cấu hình không đúng cường độ làm việc khiến tuổi thọ pin giảm, năng suất không đạt." },
  { icon: ShieldAlert, k: "04", t: "Rủi ro an toàn", d: "BMS yếu, hệ nhiệt không kiểm soát — nguy cơ cháy, nổ, ngắt bất thường." },
  { icon: TrendingDown, k: "05", t: "TCO không tối ưu", d: "Chọn sai giải pháp ban đầu khiến tổng chi phí sở hữu đội lên theo chu kỳ vận hành." },
];

export function Pain() {
  return (
    <section className="relative bg-[#0a0a0a] text-white py-32 overflow-hidden">
      <div className="absolute inset-0">
        <ImageWithFallback src="https://images.unsplash.com/photo-1720036236486-d0ea78059919?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920" alt="" className="w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#0a0a0a]/90 to-[#0a0a0a]" />
      </div>

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-12 gap-8 mb-20">
          <div className="col-span-12 lg:col-span-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>03 · BUSINESS PAIN</span>
            </div>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              style={{ fontSize: "clamp(32px, 4.8vw, 64px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}
            >
              Khi nguồn năng lượng<br />
              không phù hợp,<br />
              <span className="text-[#E11D2A]">toàn bộ vận hành</span><br />
              phải trả giá.
            </motion.h2>
          </div>
          <div className="col-span-12 lg:col-span-5 lg:col-start-8 self-end">
            <p className="text-white/65" style={{ fontSize: 16, lineHeight: 1.7 }}>
              Downtime, bảo trì, tuổi thọ, tốc độ sạc, độ an toàn và khả năng tương thích đều ảnh hưởng trực tiếp đến hiệu suất vận hành và tổng chi phí sở hữu của doanh nghiệp.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-px bg-white/10">
          {PAINS.map((p, i) => (
            <motion.div
              key={p.k}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.08 }}
              className="bg-[#0a0a0a] p-8 hover:bg-[#111] transition-colors group relative"
            >
              <div className="absolute top-0 left-0 w-0 h-px bg-[#E11D2A] group-hover:w-full transition-all duration-500" />
              <div className="flex items-center justify-between mb-8">
                <div className="text-white/30 tracking-[0.2em]" style={{ fontSize: 11 }}>{p.k}</div>
                <p.icon className="w-5 h-5 text-[#E11D2A]" />
              </div>
              <h3 className="text-white mb-3" style={{ fontSize: 18, fontWeight: 500 }}>{p.t}</h3>
              <p className="text-white/55" style={{ fontSize: 13, lineHeight: 1.6 }}>{p.d}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
