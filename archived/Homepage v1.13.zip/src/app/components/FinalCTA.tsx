import { motion } from "motion/react";
import { ArrowUpRight, Mail, Phone, MapPin } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function FinalCTA() {
  return (
    <section id="contact" className="relative bg-black text-white py-32 overflow-hidden">
      <div className="absolute inset-0">
        <ImageWithFallback src="https://images.unsplash.com/photo-1732128031392-fb14c3b8e542?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920" alt="" className="w-full h-full object-cover opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/60" />
      </div>

      <motion.div
        animate={{ opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute -left-40 top-1/3 w-[600px] h-[600px] bg-[#E11D2A]/25 blur-[200px] rounded-full"
      />

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-12 gap-10">
          <div className="col-span-12 lg:col-span-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-white/60" style={{ fontSize: 11 }}>13 · CONTACT EXPERIENCE</span>
            </div>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              style={{ fontSize: "clamp(36px, 5.2vw, 72px)", fontWeight: 600, lineHeight: 1, letterSpacing: "-0.03em" }}
            >
              Nhận tư vấn kỹ thuật<br />
              cho bài toán<br />
              <span className="text-[#E11D2A]">pin lithium</span><br />
              của doanh nghiệp.
            </motion.h2>
            <p className="mt-8 text-white/65 max-w-lg" style={{ fontSize: 16, lineHeight: 1.7 }}>
              Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu, định hướng giải pháp phù hợp và xây dựng cấu hình tối ưu hơn cho vận hành dài hạn.
            </p>

            <div className="mt-12 space-y-5">
              {[
                { icon: Phone, k: "Hotline doanh nghiệp", v: "+84 · **** · ****" },
                { icon: Mail, k: "Email dự án", v: "project@pkgbattery.vn" },
                { icon: MapPin, k: "Văn phòng chính", v: "Việt Nam · VPĐD · [Cần xác nhận]" },
              ].map((c) => (
                <div key={c.k} className="flex items-center gap-4 group">
                  <div className="w-11 h-11 border border-white/20 flex items-center justify-center group-hover:border-[#E11D2A] transition-colors">
                    <c.icon className="w-4 h-4 text-[#E11D2A]" />
                  </div>
                  <div>
                    <div className="text-white/50 tracking-wider" style={{ fontSize: 10 }}>{c.k}</div>
                    <div className="text-white" style={{ fontSize: 15 }}>{c.v}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <motion.form
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            onSubmit={(e) => e.preventDefault()}
            className="col-span-12 lg:col-span-6 relative bg-white/[0.03] backdrop-blur-xl border border-white/15 p-8 lg:p-10"
          >
            <div className="absolute top-0 left-0 w-16 h-px bg-[#E11D2A]" />
            <div className="flex items-center gap-2 text-white/60 tracking-[0.22em] mb-8" style={{ fontSize: 10 }}>
              <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> INQUIRY FORM · B2B
            </div>

            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <Field label="Họ và tên *" name="name" />
                <Field label="Doanh nghiệp *" name="company" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Field label="Email *" type="email" name="email" />
                <Field label="Số điện thoại" name="phone" />
              </div>
              <div>
                <label className="text-white/50 tracking-wider" style={{ fontSize: 10 }}>LOẠI YÊU CẦU</label>
                <select className="mt-2 w-full bg-transparent border-b border-white/20 py-3 text-white focus:border-[#E11D2A] outline-none transition-colors" style={{ fontSize: 14 }}>
                  <option className="bg-black">Tư vấn kỹ thuật</option>
                  <option className="bg-black">Yêu cầu dự án</option>
                  <option className="bg-black">OEM / ODM</option>
                  <option className="bg-black">Đại lý / phân phối</option>
                </select>
              </div>
              <div>
                <label className="text-white/50 tracking-wider" style={{ fontSize: 10 }}>NỘI DUNG</label>
                <textarea rows={3} className="mt-2 w-full bg-transparent border-b border-white/20 py-3 text-white focus:border-[#E11D2A] outline-none resize-none transition-colors" style={{ fontSize: 14 }} placeholder="Mô tả ứng dụng, cường độ vận hành, yêu cầu kỹ thuật..." />
              </div>

              <div className="pt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
                <button type="submit" className="md:col-span-2 inline-flex items-center justify-center gap-3 bg-[#E11D2A] hover:bg-[#c9141f] text-white px-6 py-4 group transition-colors" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
                  GỬI YÊU CẦU TƯ VẤN <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </button>
                <button type="button" className="inline-flex items-center justify-center gap-2 border border-white/25 hover:border-white/60 text-white px-6 py-4" style={{ fontSize: 13, letterSpacing: "0.06em" }}>
                  OEM / ODM
                </button>
              </div>

              <div className="flex items-start gap-2 text-white/40" style={{ fontSize: 11, lineHeight: 1.5 }}>
                <span className="w-1 h-1 bg-[#E11D2A] mt-1.5" />
                <span>Thông tin doanh nghiệp được bảo mật. PKG Battery cam kết phản hồi trong 24h giờ làm việc.</span>
              </div>
            </div>
          </motion.form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, name, type = "text" }: { label: string; name: string; type?: string }) {
  return (
    <div>
      <label className="text-white/50 tracking-wider" style={{ fontSize: 10 }}>{label.toUpperCase()}</label>
      <input type={type} name={name} className="mt-2 w-full bg-transparent border-b border-white/20 py-3 text-white placeholder-white/30 focus:border-[#E11D2A] outline-none transition-colors" style={{ fontSize: 14 }} />
    </div>
  );
}
