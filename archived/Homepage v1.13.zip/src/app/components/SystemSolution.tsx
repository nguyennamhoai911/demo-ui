import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const STEPS = [
  { n: "01", t: "Phân tích nhu cầu vận hành", d: "Khảo sát kịch bản sử dụng, cường độ làm việc, điều kiện môi trường và chu kỳ sạc." },
  { n: "02", t: "Cấu hình pin và bộ sạc", d: "Đề xuất dung lượng, điện áp, công suất sạc phù hợp theo bài toán cụ thể." },
  { n: "03", t: "Tùy chỉnh theo thiết bị / ứng dụng", d: "Tối ưu BMS, kết nối, kích thước, cổng giao tiếp theo thiết kế thiết bị khách hàng." },
  { n: "04", t: "Tích hợp triển khai", d: "Hỗ trợ lắp đặt, commissioning, nghiệm thu hệ thống tại site." },
  { n: "05", t: "Hỗ trợ kỹ thuật & hậu mãi", d: "Đồng hành vận hành dài hạn, bảo trì chủ động, nâng cấp firmware và BMS." },
];

export function SystemSolution() {
  return (
    <section className="relative bg-white py-32 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-12 gap-8 mb-16">
          <div className="col-span-12 lg:col-span-7">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-px bg-[#E11D2A]" />
              <span className="tracking-[0.22em] text-black/60" style={{ fontSize: 11 }}>04 · SYSTEM SOLUTION</span>
            </div>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-black"
              style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}
            >
              Chúng tôi không chỉ cung cấp pin —<br />
              chúng tôi <span className="text-[#E11D2A]">xây dựng</span> hệ giải pháp.
            </motion.h2>
          </div>
          <div className="col-span-12 lg:col-span-5 self-end">
            <p className="text-black/65" style={{ fontSize: 16, lineHeight: 1.7 }}>
              Từ khảo sát nhu cầu, cấu hình pin và sạc, đến tùy chỉnh theo ứng dụng, hỗ trợ triển khai và đồng hành kỹ thuật, PKG Battery hướng tới giải pháp vận hành hoàn chỉnh cho doanh nghiệp.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-12 lg:col-span-5 relative overflow-hidden bg-black min-h-[560px]">
            <ImageWithFallback src="https://images.unsplash.com/photo-1753272691001-4d68806ac590?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" alt="" className="w-full h-full object-cover opacity-70" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            <div className="absolute inset-0 p-8 flex flex-col justify-between text-white">
              <div className="flex items-center gap-2 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>
                <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> ENGINEERED WORKFLOW
              </div>
              <div>
                <div className="text-white/60" style={{ fontSize: 11, letterSpacing: "0.18em" }}>END-TO-END</div>
                <h3 className="mt-3" style={{ fontSize: 32, fontWeight: 600, lineHeight: 1.05 }}>Từ khảo sát đến<br />triển khai thực địa.</h3>
              </div>
            </div>
          </div>

          <div className="col-span-12 lg:col-span-7 flex flex-col">
            {STEPS.map((s, i) => (
              <motion.div
                key={s.n}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="group relative grid grid-cols-12 gap-4 items-start py-6 border-b border-black/10 hover:bg-black/[0.02] transition-colors"
              >
                <div className="col-span-2 text-[#E11D2A]" style={{ fontSize: 22, fontWeight: 600 }}>{s.n}</div>
                <div className="col-span-4 text-black" style={{ fontSize: 17, fontWeight: 500 }}>{s.t}</div>
                <div className="col-span-6 text-black/60" style={{ fontSize: 14, lineHeight: 1.6 }}>{s.d}</div>
                <div className="absolute left-0 top-0 w-0 h-px bg-[#E11D2A] group-hover:w-full transition-all duration-500" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
