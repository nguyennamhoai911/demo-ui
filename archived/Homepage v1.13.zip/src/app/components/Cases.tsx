import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const CASES = [
  {
    sector: "LOGISTICS · FORKLIFT",
    t: "Chuyển đổi fleet xe nâng 3 ca sang pin lithium",
    problem: "Downtime do sạc acid-lead, bảo trì phức tạp.",
    result: "Uptime ↑, chi phí bảo trì ↓",
    img: "https://images.unsplash.com/photo-1740914994657-f1cdffdc418e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
  },
  {
    sector: "AUTOMATION · AGV",
    t: "Hệ AGV tự hành kho trung chuyển",
    problem: "Cần sạc opportunity 24/7, BMS chuyên biệt.",
    result: "Chu kỳ sạc tối ưu theo workflow",
    img: "https://images.unsplash.com/photo-1697057914230-320d7c251f65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
  },
  {
    sector: "ENERGY · ESS",
    t: "ESS cabinet cho peak-shaving nhà máy",
    problem: "Chi phí điện peak cao, cần backup.",
    result: "Backup + tiết giảm chi phí năng lượng",
    img: "https://images.unsplash.com/photo-1639195046198-a73b6d2d9606?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1400",
  },
];

export function Cases() {
  return (
    <section className="relative bg-[#f5f5f5] py-32">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="mb-16 max-w-3xl">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-px bg-[#E11D2A]" />
            <span className="tracking-[0.22em] text-black/60" style={{ fontSize: 11 }}>12 · APPLICATION PROOF · [Cần xác nhận]</span>
          </div>
          <h2 className="text-black" style={{ fontSize: "clamp(32px, 4.8vw, 60px)", fontWeight: 600, lineHeight: 1.02, letterSpacing: "-0.02em" }}>
            Giải pháp được định hướng<br />cho các bối cảnh <span className="text-[#E11D2A]">thực tế.</span>
          </h2>
        </div>

        <div className="space-y-6">
          {CASES.map((c, i) => (
            <motion.a
              key={c.t}
              href="#"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.1 }}
              className="group grid grid-cols-12 gap-6 items-stretch bg-white overflow-hidden"
            >
              <div className="col-span-12 lg:col-span-5 relative aspect-[4/3] lg:aspect-auto overflow-hidden bg-black">
                <ImageWithFallback src={c.img} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
              </div>
              <div className="col-span-12 lg:col-span-7 p-8 lg:p-10 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-black/50 tracking-[0.22em]" style={{ fontSize: 10 }}>
                    <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> CASE · 0{i + 1} · {c.sector}
                  </div>
                  <h3 className="mt-4 text-black group-hover:text-[#E11D2A] transition-colors" style={{ fontSize: 28, fontWeight: 600, lineHeight: 1.1, letterSpacing: "-0.01em" }}>{c.t}</h3>
                </div>
                <div className="mt-8 grid grid-cols-2 gap-6 pt-6 border-t border-black/10">
                  <div>
                    <div className="text-black/50 tracking-wider" style={{ fontSize: 10 }}>BÀI TOÁN</div>
                    <p className="mt-2 text-black/75" style={{ fontSize: 14, lineHeight: 1.5 }}>{c.problem}</p>
                  </div>
                  <div>
                    <div className="text-[#E11D2A] tracking-wider" style={{ fontSize: 10, fontWeight: 600 }}>KẾT QUẢ</div>
                    <p className="mt-2 text-black/75" style={{ fontSize: 14, lineHeight: 1.5 }}>{c.result}</p>
                  </div>
                </div>
                <div className="mt-6 flex items-center gap-2 text-black/70 group-hover:text-[#E11D2A] transition-colors" style={{ fontSize: 12, letterSpacing: "0.06em" }}>
                  XEM CASE STUDY <ArrowUpRight className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
