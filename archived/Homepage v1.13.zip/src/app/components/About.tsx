import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function About() {
  return (
    <section className="relative bg-white py-32 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-12 gap-8">
          {/* Left column — heading */}
          <div className="col-span-12 lg:col-span-5">
            <div className="sticky top-28">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-px bg-[#E11D2A]" />
                <span className="tracking-[0.22em] text-black/60" style={{ fontSize: 11 }}>02 · VỀ DOANH NGHIỆP</span>
              </div>
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="text-black"
                style={{ fontSize: "clamp(32px, 4.5vw, 60px)", fontWeight: 600, lineHeight: 1.05, letterSpacing: "-0.02em" }}
              >
                Một doanh nghiệp B2B<br />
                được xây dựng cho<br />
                bài toán năng lượng<br />
                <span className="text-[#E11D2A]">công nghiệp hiện đại.</span>
              </motion.h2>
              <p className="mt-8 text-black/65" style={{ fontSize: 16, lineHeight: 1.7 }}>
                PKG Battery được định hướng như đối tác giải pháp pin lithium công nghiệp, kết hợp năng lực sản phẩm, tư duy kỹ thuật và khả năng triển khai theo nhu cầu thực tế của doanh nghiệp.
              </p>
              <div className="mt-10 pl-6 border-l-2 border-[#E11D2A]">
                <p className="text-black" style={{ fontSize: 18, lineHeight: 1.55, fontWeight: 500 }}>
                  "Chúng tôi không chỉ cung cấp pin — chúng tôi xây dựng hệ giải pháp năng lượng cho từng bài toán vận hành."
                </p>
                <div className="mt-4 text-black/50 tracking-[0.18em]" style={{ fontSize: 10 }}>— PKG BATTERY · BRAND STATEMENT</div>
              </div>
            </div>
          </div>

          {/* Right column — editorial collage */}
          <div className="col-span-12 lg:col-span-7">
            <div className="grid grid-cols-6 grid-rows-[220px_180px_220px] gap-4">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7 }}
                className="col-span-4 row-span-1 relative overflow-hidden bg-black group"
              >
                <ImageWithFallback src="https://images.unsplash.com/photo-1720036236632-fdb6211cf317?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
                <div className="absolute top-4 left-4 flex items-center gap-2 text-white/80 tracking-[0.2em]" style={{ fontSize: 10 }}>
                  <span className="w-1.5 h-1.5 bg-[#E11D2A]" /> NĂNG LỰC SẢN XUẤT
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: 0.1 }}
                className="col-span-2 row-span-2 relative overflow-hidden bg-black group"
              >
                <ImageWithFallback src="https://images.unsplash.com/photo-1745267652572-573ae6e81e40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="text-white/70 tracking-[0.2em]" style={{ fontSize: 10 }}>TEAM</div>
                  <div className="mt-1" style={{ fontSize: 15, fontWeight: 500 }}>Đội ngũ kỹ sư</div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: 0.2 }}
                className="col-span-2 row-span-1 bg-black text-white p-6 flex flex-col justify-between"
              >
                <div className="text-white/50 tracking-[0.2em]" style={{ fontSize: 10 }}>SINCE</div>
                <div>
                  <div style={{ fontSize: 48, fontWeight: 600, lineHeight: 1 }}>15<span className="text-[#E11D2A]">+</span></div>
                  <div className="text-white/60 mt-1" style={{ fontSize: 12 }}>năm kinh nghiệm ngành [Cần xác nhận]</div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: 0.3 }}
                className="col-span-2 row-span-1 relative overflow-hidden group"
              >
                <ImageWithFallback src="https://images.unsplash.com/photo-1760842543741-876d7837fa0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800" alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: 0.4 }}
                className="col-span-4 row-span-1 relative overflow-hidden group"
              >
                <ImageWithFallback src="https://images.unsplash.com/photo-1720036236828-1c6a472db1c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1200" alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1.2s]" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white flex items-end justify-between">
                  <div>
                    <div className="text-white/70 tracking-[0.2em]" style={{ fontSize: 10 }}>FACILITY</div>
                    <div className="mt-1" style={{ fontSize: 16, fontWeight: 500 }}>Môi trường kiểm thử kỹ thuật</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
