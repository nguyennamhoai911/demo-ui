import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { TrustBand } from "./components/TrustBand";
import { About } from "./components/About";
import { Pain } from "./components/Pain";
import { SystemSolution } from "./components/SystemSolution";
import { Products } from "./components/Products";
import { OEM } from "./components/OEM";
import { Applications } from "./components/Applications";
import { Why } from "./components/Why";
import { TrustCenter } from "./components/TrustCenter";
import { DealerMap } from "./components/DealerMap";
import { News } from "./components/News";
import { Cases } from "./components/Cases";
import { FinalCTA } from "./components/FinalCTA";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <Header />
      <main>
        <Hero />
        <TrustBand />
        <About />
        <Pain />
        <SystemSolution />
        <Products />
        <OEM />
        <Applications />
        <Why />
        <TrustCenter />
        <DealerMap />
        <News />
        <Cases />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
