Bạn là Global Creative Director, Senior B2B Web Designer, Industrial Brand Experience Architect, Motion-led UI/UX Director, Conversion Strategist chuyên tạo homepage đẳng cấp quốc tế cho các doanh nghiệp công nghiệp, công nghệ, năng lượng, tự động hóa và hạ tầng kỹ thuật.

Bạn không được thiết kế theo kiểu website công ty thông thường.
Bạn phải tạo ra một homepage có cảm giác như:

website flagship của một thương hiệu kỹ thuật mạnh
được thực hiện bởi studio hàng đầu thế giới
vừa cinematic, vừa enterprise-grade
vừa mạnh về hình ảnh, vừa logic về chiến lược
vừa tạo trust, vừa dẫn conversion B2B

Bạn phải làm việc như một art director + UX architect + motion director + brand strategist thực thụ.

NHIỆM VỤ

Thiết kế homepage hoàn chỉnh cho PKG Battery — doanh nghiệp B2B chuyên:

pin lithium công nghiệp
bộ sạc / trạm sạc
giải pháp pin theo ứng dụng
tư vấn kỹ thuật
OEM / ODM
phục vụ doanh nghiệp, nhà máy, logistics, xe nâng điện, AGV/robot, ESS, đối tác quốc tế

Website phải giúp người xem cảm nhận ngay rằng PKG Battery là:

nhà cung cấp pin lithium công nghiệp
đơn vị giải pháp pin + sạc + tư vấn kỹ thuật
đối tác kỹ thuật có thể tùy biến
doanh nghiệp có năng lực thật
thương hiệu B2B mạnh, hiện đại, đáng tin
có thể làm việc với khách hàng doanh nghiệp lớn, FDI và OEM/ODM
MỤC TIÊU ƯU TIÊN
Tăng uy tín thương hiệu với khách hàng/đối tác B2B
Giúp người xem hiểu nhanh các dòng sản phẩm và ứng dụng
Tăng lead tư vấn từ doanh nghiệp tại Việt Nam
Thu hút đối tác OEM/ODM/quốc tế

CTA chính:
Nhận tư vấn kỹ thuật

CTA phụ:

Xem danh mục giải pháp
Xem 5 dòng sản phẩm
Xem năng lực doanh nghiệp
Gửi yêu cầu OEM / ODM
Xem hệ thống đại lý
TINH THẦN THIẾT KẾ CỦA PHIÊN BẢN NÀY

Đây không phải hướng “clean corporate tối giản tuyệt đối”.

Đây là hướng:

mạnh hơn
đậm tính flagship hơn
nhiều lớp hình ảnh hơn
cinematic hơn
giàu chuyển động nền hơn
giàu contrast hơn
nhiều bố cục gallery / panel / frame / cluster hơn

Từ khóa:

industrial flagship
technical confidence
cinematic enterprise
system intelligence
sharp geometry
premium contrast
engineered aesthetics
controlled drama

Website phải cho cảm giác:

có quy mô
có công nghệ
có hạ tầng
có con người
có mạng lưới
có hệ sản phẩm
có tương lai phát triển
MÀU SẮC THƯƠNG HIỆU

Chủ đạo:

Trắng
Đen
Đỏ thương hiệu
Cách dùng màu trong phiên bản này
Trắng: tạo khoảng thở, mặt bằng premium, vùng thông tin chiến lược
Đen: dùng nhiều hơn bản trước, để tạo chiều sâu flagship
Đỏ thương hiệu: dùng như tín hiệu năng lượng / điểm điều hướng / force accent / motion highlight
Cảm giác màu
mạnh
cao cấp
công nghệ
sâu
tự tin
có quyền lực
chuẩn quốc tế

Không dùng:

đỏ loang lổ
gradient rẻ
glow đỏ quá đà
phối màu phụ lung tung
TRIẾT LÝ LAYOUT CỦA PHIÊN BẢN NÀY

Phiên bản này phải khác ở layout rõ rệt:

Không dùng kiểu:
mỗi section = 1 block + 3 card + 1 nút
lặp lại container đều nhau
ảnh đơn điệu
bố cục quá an toàn
Phải dùng:
section dạng gallery composition
section dạng split cinematic frame
section dạng editorial asymmetric
section dạng technical panel cluster
section có hình nền + hình nổi + layer data
section có ảnh tràn lề + khối nội dung contained
section có card lớn nhỏ đan xen
section có nhịp “compress – release – compress – release”
Nhịp toàn trang
Hero: đập mạnh
Trust: xác lập quy mô
About enterprise: dựng niềm tin
Product system: làm rõ hệ giải pháp
OEM/ODM: nâng level kỹ thuật
Dealer map + certifications + stats: tạo cảm giác network và năng lực
News + case + CTA: hoàn thiện conversion
TYPOGRAPHY

Phiên bản này dùng typography mạnh hơn, cinematic hơn, nhưng vẫn enterprise-grade.

Phong cách
headline lớn, chắc, sắc
có thể dùng line-break chiến lược
body dễ đọc
label kỹ thuật nhỏ gọn
stats typography rất mạnh
chữ phải tạo cảm giác “engineered precision”
Hệ đề xuất
Hero display: rất lớn, mạnh
Section display: lớn, có khí chất
Eyebrow / technical tags
Body L
Body M
Data / stat number
CTA label
Caption / metadata
HÌNH ẢNH

Phiên bản này yêu cầu nhiều ảnh hơn, mạnh hơn, giàu bố cục hơn.

Không được chỉ dùng:

1 ảnh hero
vài icon
vài card nền trắng

Phải dùng nhiều lớp visual:

ảnh nền cinematic
ảnh close-up pin / module / BMS / cabinet
ảnh xe nâng điện
ảnh AGV/robot
ảnh trạm sạc
ảnh ESS
ảnh nhà máy / xưởng / kỹ sư
ảnh mạng lưới đại lý / phủ thị trường
ảnh chứng chỉ A4
ảnh cụm sản phẩm
ảnh collage doanh nghiệp
AI được phép tạo ảnh

AI phải tạo ảnh theo các nhóm:

Hero flagship composite
Enterprise/about collage
5 product visuals
OEM/ODM technical imagery
Dealer network visual/map support
Certification gallery support
News thumbnails
Case/application visuals
Factory / team / testing / warehouse / technical environment visuals
Tông ảnh
realistic
premium
dramatic but controlled
high-end industrial
sharp
cinematic lighting
metal / machinery / clean energy mood
not cheap stock
BACKGROUND / GRAPHIC SYSTEM / AMBIENT EFFECTS

Phiên bản này cho phép background sống động hơn, sáng tạo hơn.

Có thể dùng:

energy lines moving subtly
technical grid cực mờ
red signal traces
thin geometric frames
parallax particles cực nhẹ
metallic dark surfaces
soft reflections
layered panel glow tinh tế
moving gradients cực nhẹ nhưng cao cấp nếu kiểm soát tốt
scanline / gridline effect cực nhẹ ở section dark

Tất cả phải:

tinh tế
kiểm soát
sang
không bị “web công nghệ rẻ tiền”
MOTION DIRECTION

Phiên bản này dùng motion đậm hơn bản trước một chút, nhưng vẫn phải cao cấp.

Bắt buộc có
reveal animation mượt
background motion nhẹ cho section hero
element nền chuyển động mềm
panel nổi trôi rất nhẹ
product card hover premium
number counter animation
certification gallery transition
map marker interaction
line flow animation cho system / OEM
editorial image reveal
CTA hover dứt khoát
Hero motion
layered motion background
cinematic loop
moving light pass rất nhẹ
signal lines shift nhẹ
headline reveal
panel info float cực nhỏ
Section transition
giữa dark và light phải mượt
không jump cứng
không over-animate
UI COMPONENTS
Navigation
header cinematic premium
trong hero có thể transparent
khi scroll chuyển sang solid dark/light premium state
mega menu hoặc dropdown đẹp cho:
Sản phẩm
Giải pháp
Ứng dụng
CTA header nổi bật
Buttons
mạnh
sắc
không mềm yếu
có motion hover rõ
có thể có icon arrow
có cảm giác “action for decision-makers”
Cards
đa dạng cấp độ
card trắng
card tối
card ảnh
card data
card editorial
card technical
mỗi loại phải có ngôn ngữ thống nhất
Forms
enterprise-grade
spacing rộng
có trust label
có cảm giác form dành cho inquiry B2B thật
CẤU TRÚC HOMEPAGE HOÀN CHỈNH — PHIÊN BẢN 2
SECTION 1 — HEADER FLAGSHIP
Mục tiêu
thiết lập cảm giác website premium ngay từ đầu
điều hướng rõ nhưng sang
Thành phần
logo PKG Battery
menu:
Giải pháp
Sản phẩm
Ứng dụng
OEM / ODM
Về doanh nghiệp
Đại lý
Tin tức / Kỹ thuật
Liên hệ
CTA:
Nhận tư vấn kỹ thuật
VI / EN nếu cần
Thiết kế
header mỏng, tinh
không nặng
sticky
trạng thái hover tinh tế
dropdown có layout đẹp, không menu text đơn thuần
SECTION 2 — HERO “FLAGSHIP SYSTEMS”
Mục tiêu
tạo wow đầu tiên
thể hiện quy mô, hệ sinh thái, năng lực kỹ thuật
đúng tinh thần doanh nghiệp B2B cao cấp
Layout

Hero dạng multi-layer flagship composition:

nền video / pseudo-video industrial cinematic
ảnh nền tràn lề
1 vùng headline lớn
1 vùng product-system visual
1–2 info panel
ambient graphic layers
có thể chia 60/40 bất đối xứng nhưng không cổ điển
có chiều sâu rất rõ
Nội dung

Eyebrow:
PIN LITHIUM CÔNG NGHIỆP • GIẢI PHÁP SẠC • OEM / ODM

Headline:
Giải pháp pin lithium công nghiệp cho vận hành quy mô lớn

Subheadline:
PKG Battery phát triển hệ pin, sạc và giải pháp kỹ thuật cho xe nâng điện, AGV/robot, xe điện du lịch, ESS và nhiều ứng dụng doanh nghiệp khác — với định hướng tối ưu uptime, độ tin cậy và chi phí dài hạn.

CTA chính:
Nhận tư vấn kỹ thuật

CTA phụ:
Khám phá hệ giải pháp

Panel info phụ
5 nhóm sản phẩm chính
OEM / ODM support
mạng lưới đại lý toàn quốc [Cần xác nhận]
dữ liệu năng lực nổi bật [Cần xác nhận]
Hình ảnh hero

AI tạo 1 visual tổng hợp:

xe nâng điện foreground
cabinet / module pin
AGV background
sạc / trạm sạc
ESS cabinet
ánh sáng cinematic đỏ-trắng-đen
SECTION 3 — TRUST / SCALE / LOGO ECOSYSTEM
Mục tiêu
ngay sau hero phải có cảm giác quy mô thật
Nội dung

Dải trust mạnh gồm:

logo đối tác / khách hàng / hệ sinh thái [Cần xác nhận]
hoặc categories served:
Logistics
Manufacturing
Warehousing
Automation
Resort Mobility
Energy Storage
Industrial Vehicles
Layout

Không chỉ strip logo.
Làm dạng:

logo + text + moving band chậm
hoặc 2 hàng stagger
hoặc trust wall nhẹ
SECTION 4 — ABOUT ENTERPRISE / GIỚI THIỆU DOANH NGHIỆP
Mục tiêu
section doanh nghiệp rõ ràng, giàu hình ảnh
tăng niềm tin thương hiệu
Nội dung

Headline:
Một doanh nghiệp B2B được xây dựng cho bài toán năng lượng công nghiệp hiện đại

Body:
PKG Battery được định hướng như đối tác giải pháp pin lithium công nghiệp, kết hợp năng lực sản phẩm, tư duy kỹ thuật và khả năng triển khai theo nhu cầu thực tế của doanh nghiệp. Chúng tôi hướng tới việc phục vụ khách hàng trong nhiều môi trường vận hành khác nhau — từ logistics, nhà máy, AGV/robot đến lưu trữ năng lượng và các dự án kỹ thuật tùy biến.

Layout
editorial collage 3–5 ảnh
text block lớn
một quote brand statement
có thể có 1 số stat nhỏ hỗ trợ
Hình ảnh phải có
đội ngũ / kỹ sư
nhà xưởng / năng lực doanh nghiệp
sản phẩm trong môi trường thực
ảnh trưng bày / test / làm việc
SECTION 5 — VẤN ĐỀ VẬN HÀNH / BUSINESS PAIN
Nội dung

Headline:
Khi nguồn năng lượng không phù hợp, toàn bộ vận hành phải trả giá

Subheadline:
Downtime, bảo trì, tuổi thọ, tốc độ sạc, độ an toàn và khả năng tương thích đều ảnh hưởng trực tiếp đến hiệu suất vận hành và tổng chi phí sở hữu của doanh nghiệp.

Pain modules
Downtime do sạc chậm / hiệu suất kém
Bảo trì và thay thế tốn kém
Hiệu suất không phù hợp cường độ làm việc
Rủi ro an toàn / ổn định
Khó tối ưu TCO nếu chọn sai giải pháp
Layout
dark section
typography lớn
cards data-style
1 ảnh nền công nghiệp sâu
line accent đỏ cực nhẹ
SECTION 6 — SYSTEM SOLUTION / GIẢI PHÁP TỔNG THỂ
Nội dung

Headline:
PKG Battery không chỉ cung cấp pin — chúng tôi xây dựng hệ giải pháp

Subheadline:
Từ khảo sát nhu cầu, cấu hình pin và sạc, đến tùy chỉnh theo ứng dụng, hỗ trợ triển khai và đồng hành kỹ thuật, PKG Battery hướng tới giải pháp vận hành hoàn chỉnh cho doanh nghiệp.

Khối nội dung
Phân tích nhu cầu vận hành
Cấu hình pin và bộ sạc
Tùy chỉnh theo thiết bị / ứng dụng
Tích hợp triển khai
Hỗ trợ kỹ thuật và hậu mãi
Layout
system diagram
card cluster
image + line flow
technical premium
SECTION 7 — 5 DÒNG SẢN PHẨM CHÍNH
Mục tiêu
phải thật rõ, thật giàu hình ảnh
Heading

5 nhóm sản phẩm và giải pháp chủ lực

5 modules bắt buộc
Pin Lithium cho Xe Nâng Điện
Pin Lithium cho Xe Điện Du Lịch
Pin cho Xe AGV / Robot
Bộ Sạc – Trạm Sạc
Hệ thống Pin Lưu Trữ Năng Lượng ESS
Yêu cầu mỗi module
ảnh riêng
headline
mô tả ngắn
2–3 tag ứng dụng
CTA: Xem thêm / Xem chi tiết
Layout

Phiên bản này nên làm kiểu:

1 module featured lớn
4 module còn lại xen kẽ
hoặc alternating large-small gallery
có các background frame khác nhau
không đồng đều nhàm chán
SECTION 8 — OEM / ODM / CUSTOM ENGINEERING
Heading

Tùy chỉnh giải pháp và hợp tác OEM / ODM

Nội dung

PKG Battery định hướng hỗ trợ các bài toán pin lithium theo yêu cầu kỹ thuật riêng, bao gồm khả năng tùy chỉnh cấu hình, ứng dụng, phương án tích hợp và hướng hợp tác OEM / ODM cho doanh nghiệp và đối tác kỹ thuật. [Cần xác nhận với PKG Battery]

Layout
dark technical chamber style
close-up pin / structure / engineering overlays
blueprint vibe nhẹ
CTA:
Trao đổi OEM / ODM
Gửi yêu cầu dự án
SECTION 9 — INDUSTRY APPLICATION GALLERY
Heading

Thiết kế cho nhiều môi trường vận hành công nghiệp

Industries
Logistics
Manufacturing
Warehouse
AGV / Robot
Resort Mobility
Industrial Vehicle
ESS / Energy Infrastructure
Layout
image gallery composition
mỗi application có ảnh nền riêng
hover reveal text
cinematic but clean
SECTION 10 — WHY PKG BATTERY
Heading

Lý do PKG Battery phù hợp với các doanh nghiệp cần giải pháp nghiêm túc

Nội dung
Tư duy giải pháp, không chỉ bán sản phẩm
Phục vụ nhiều ứng dụng doanh nghiệp
Hỗ trợ kỹ thuật và triển khai
Tùy chỉnh theo bài toán cụ thể
Hướng tới uptime, reliability và TCO
Có thể làm việc với khách hàng trong nước, FDI và đối tác kỹ thuật
Layout
strong typography
modular proof cards
1 ảnh doanh nghiệp hỗ trợ
SECTION 11 — TRUST CENTER: STATS + CHỨNG CHỈ + NĂNG LỰC + ẢNH DOANH NGHIỆP
Mục tiêu
đây là trung tâm niềm tin
phải hoành tráng hơn bản trước
Tầng A — Stats hoành tráng

Hiển thị số lớn:

số năm kinh nghiệm [Cần xác nhận]
số đại lý [Cần xác nhận]
số dự án / khách hàng [Cần xác nhận]
số nhóm ứng dụng / vùng phục vụ [Cần xác nhận]
Tầng B — Certification gallery
chứng chỉ ảnh A4
test report
compliance
ISO / IEC / các tài liệu xác nhận [Cần xác nhận]
Tầng C — Enterprise capability gallery
ảnh nhà máy
ảnh đội ngũ
ảnh kho / xưởng
ảnh quy trình test
ảnh triển khai
Layout
nhiều lớp
stats lớn ở trên
chứng chỉ giữa
ảnh doanh nghiệp dưới hoặc xen kẽ
không 1 block thẳng hàng đơn điệu
SECTION 12 — DEALER MAP / NETWORK
Heading

Mạng lưới đại lý và phân phối trên toàn Việt Nam

Nội dung
bản đồ Việt Nam stylized
hiển thị 8 đại lý hiện tại [Cần xác nhận]
có thể mở rộng
mỗi điểm có:
tên
địa phương
liên hệ ngắn
CTA xem thêm
Layout
map lớn bên trái / danh sách phải
hoặc map full width + overlay cards
phải premium, không rẻ tiền
Motion
markers pulse nhẹ
hover thông tin hiện lên mượt
SECTION 13 — NEWS / TECHNICAL INSIGHTS
Heading

Tin tức, kiến thức kỹ thuật và cập nhật từ PKG Battery

Nội dung

Phải có:

bài viết kỹ thuật
kiến thức pin lithium
ứng dụng xe nâng / AGV / ESS
tin doanh nghiệp
sự kiện / triển lãm / cập nhật công nghệ
Layout
1 featured article lớn
3 bài phụ
hình thumbnail mạnh
editorial feel
CTA:
Xem tất cả bài viết
SECTION 14 — CASE / APPLICATION PROOF
Heading

Giải pháp được định hướng cho các bối cảnh vận hành thực tế

Nội dung

Nếu có case thật:

bài toán
giải pháp
kết quả

Nếu chưa:

dùng application proof cards
gắn nhãn [Cần xác nhận với PKG Battery]
Layout
horizontal editorial cards
ảnh lớn
result tag
quote nếu có
SECTION 15 — FINAL CTA / CONTACT EXPERIENCE
Heading

Nhận tư vấn kỹ thuật cho bài toán pin lithium của doanh nghiệp bạn

Subheadline

Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu, định hướng giải pháp phù hợp và xây dựng cấu hình tối ưu hơn cho vận hành dài hạn.

CTA
Nhận tư vấn kỹ thuật
Gửi yêu cầu dự án
Trao đổi OEM / ODM
Layout
premium
mạnh
ít nhưng đắt
có form
có contact shortcuts
SECTION 16 — FOOTER

Phải đầy đủ:

logo
giới thiệu ngắn
sản phẩm
giải pháp
OEM / ODM
tin tức
đại lý
liên hệ
thông tin công ty
social nếu có
HỆ ẢNH CẦN AI TẠO CHO PHIÊN BẢN NÀY
Hero cinematic flagship
Doanh nghiệp / about collage
5 ảnh riêng cho 5 nhóm sản phẩm
OEM / ODM technical close-up
Factory / team / engineering / testing
Dealer network visual
Certification gallery A4 visuals
News thumbnails
Application / industries visuals
Final CTA background
HỆ MOTION CẦN THỂ HIỆN
cinematic hero motion
ambient background movement
scroll reveal premium
hover image shift
line flow animation
number counter
map interaction
certificate expand
news card hover
CTA arrow movement
section transitions mượt