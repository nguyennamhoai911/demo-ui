
  # Homepage v1.13

  This is a code bundle for Homepage v1.13. The original project is available at https://www.figma.com/design/BfIl74ZbNYggS0cGBnP0U4/Homepage-v1.13.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  