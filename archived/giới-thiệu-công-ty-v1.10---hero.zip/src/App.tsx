/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from "motion/react";
import { ChevronRight, Shield, Zap, Award, Globe } from "lucide-react";

const Navbar = () => (
  <nav className="fixed top-0 left-0 w-full z-50 flex items-center justify-between px-8 py-6 md:px-16">
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 bg-pkg-red flex items-center justify-center rounded-sm">
        <span className="text-white font-bold text-xs">PKG</span>
      </div>
      <span className="font-bold tracking-tighter text-xl text-graphite uppercase">
        Battery
      </span>
    </div>
    <div className="hidden md:flex items-center gap-12 text-[13px] font-medium tracking-wide uppercase text-graphite/60">
      <a href="#" className="hover:text-pkg-red transition-colors">Tầm nhìn</a>
      <a href="#" className="hover:text-pkg-red transition-colors">Năng lực</a>
      <a href="#" className="hover:text-pkg-red transition-colors">Đối tác</a>
    </div>
    <button className="border border-graphite/20 px-6 py-2 rounded-full text-[12px] font-semibold uppercase tracking-wider hover:bg-graphite hover:text-white transition-all">
      Liên hệ đại lý
    </button>
  </nav>
);

const TrustIndicator = ({ icon: Icon, label }: { icon: any, label: string }) => (
  <div className="flex items-center gap-2 text-graphite/40 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-lg border border-silver-gray/30 shadow-sm">
    <Icon size={14} strokeWidth={2.5} />
    <span className="text-[11px] font-bold uppercase tracking-widest leading-none">{label}</span>
  </div>
);

export default function App() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { 
      opacity: 1, y: 0,
      transition: { duration: 0.8, ease: "easeOut" }
    },
  };

  return (
    <div className="relative min-h-screen bg-soft-white overflow-hidden selection:bg-pkg-red selection:text-white">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-silver-gray/20 to-transparent pointer-events-none" />
      <div className="absolute top-0 right-0 w-px h-full bg-pkg-red/5" />
      
      <Navbar />

      <main className="relative z-10 mx-auto max-w-7xl px-8 md:px-16 pt-32 pb-20 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center min-h-[90vh]">
        {/* Left Side: Brand Content */}
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex flex-col gap-8 max-w-2xl"
        >
          <motion.div variants={itemVariants} className="flex items-center gap-4">
            <span className="text-[12px] font-bold tracking-[0.4em] uppercase text-pkg-red">
              PKG BATTERY
            </span>
            <div className="h-px w-12 bg-pkg-red/30" />
            <span className="text-[10px] font-semibold text-graphite/40 uppercase tracking-widest">
              LITHIUM ENERGY SOLUTIONS
            </span>
          </motion.div>

          <motion.h1 
            variants={itemVariants}
            className="text-4xl md:text-6xl font-bold text-graphite leading-[1.1] md:leading-[1.15] tracking-tight"
          >
            ĐỒNG HÀNH CÙNG TƯƠNG LAI <br />
            <span className="text-pkg-red">NĂNG LƯỢNG CÔNG NGHIỆP</span> <br />
            VIỆT NAM
          </motion.h1>

          <motion.div variants={itemVariants} className="flex flex-col gap-4">
            <p className="text-lg md:text-xl text-graphite/80 font-medium leading-relaxed">
              PKG Battery phát triển năng lực nghiên cứu, sản xuất và triển khai các giải pháp năng lượng Lithium phục vụ doanh nghiệp trong công nghiệp, logistics và hạ tầng vận hành hiện đại.
            </p>
            <p className="text-[15px] text-graphite/60 leading-relaxed max-w-xl">
              Chúng tôi xây dựng giá trị từ công nghệ, đội ngũ kỹ thuật và cam kết đồng hành dài hạn, nhằm giúp doanh nghiệp nâng cao hiệu suất vận hành, tăng độ an toàn và sẵn sàng cho giai đoạn tăng trưởng mới.
            </p>
          </motion.div>

          <motion.div variants={itemVariants} className="flex flex-wrap items-center gap-5 mt-4">
            <button className="group bg-graphite text-white px-8 py-4 rounded-sm flex items-center gap-3 text-sm font-bold uppercase tracking-widest hover:bg-pkg-red transition-all duration-300 shadow-xl shadow-graphite/10">
              Khám phá doanh nghiệp
              <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="border border-graphite px-8 py-4 rounded-sm text-sm font-bold uppercase tracking-widest hover:bg-graphite hover:text-white transition-all duration-300">
              Xem năng lực triển khai
            </button>
          </motion.div>

          {/* Trust Bar */}
          <motion.div variants={itemVariants} className="flex flex-wrap items-center gap-3 pt-8 border-t border-silver-gray mt-4">
            <TrustIndicator icon={Shield} label="IEC 62619" />
            <TrustIndicator icon={Zap} label="UN38.3" />
            <TrustIndicator icon={Globe} label="ISO Standard" />
            <p className="ml-2 text-[11px] font-medium text-graphite/50 italic">
              "Đối tác năng lượng cho môi trường vận hành hiện đại"
            </p>
          </motion.div>
        </motion.div>

        {/* Right Side: Visual Composition */}
        <div className="relative h-[600px] w-full hidden lg:block">
          {/* Main Visual Layer: Enterprise/Operations */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.2, ease: "easeOut", delay: 0.4 }}
            className="absolute top-10 right-0 w-[90%] h-[80%] z-20 rounded-2xl overflow-hidden shadow-2xl border-[12px] border-white ring-1 ring-graphite/5"
          >
            <img 
              src="https://picsum.photos/seed/pkg-tech/1400/1000" 
              alt="PKG Battery Enterprise Team"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            {/* Subtle Overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-graphite/20 via-transparent to-transparent mix-blend-overlay" />
          </motion.div>

          {/* Supporting Layer: Human Expertise */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 100 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut", delay: 0.8 }}
            className="absolute bottom-0 left-0 w-[60%] h-[50%] z-30 rounded-xl overflow-hidden shadow-2xl border-[8px] border-white"
          >
            <img 
              src="https://picsum.photos/seed/pkg-engineer/800/800" 
              alt="PKG Technical Capability"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Floating Abstract Element */}
          <motion.div
            animate={{ 
              y: [0, -15, 0],
              rotate: [0, 2, 0]
            }}
            transition={{ 
              duration: 6, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
            className="absolute -top-10 left-10 z-10 w-48 h-48 bg-pkg-red/5 rounded-full blur-3xl"
          />

          {/* Data Accent Detail */}
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: "200px" }}
            transition={{ duration: 1.5, delay: 1 }}
            className="absolute -bottom-4 right-10 z-40 bg-white p-6 rounded-lg shadow-xl border border-silver-gray/50"
          >
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-end">
                <span className="text-[10px] font-bold text-graphite/40 uppercase tracking-widest">Efficiency</span>
                <span className="text-xl font-bold text-pkg-red leading-none">99.8%</span>
              </div>
              <div className="h-1 bg-silver-gray w-full rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: "99.8%" }}
                  transition={{ duration: 2, delay: 1.2 }}
                  className="h-full bg-pkg-red"
                />
              </div>
            </div>
          </motion.div>

          {/* Decorative Corner Lines */}
          <div className="absolute top-2 right-12 w-12 h-12 border-t-2 border-r-2 border-pkg-red/20 z-10" />
          <div className="absolute bottom-2 left-64 w-12 h-12 border-b-2 border-l-2 border-graphite/10 z-10" />
        </div>
      </main>

      {/* Decorative text watermark */}
      <div className="absolute bottom-10 left-8 md:left-16 flex items-center gap-10 opacity-[0.03] select-none pointer-events-none">
        <span className="text-8xl font-black uppercase whitespace-nowrap">Vietnam Energy Leader</span>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-graphite/30">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-graphite/30 to-transparent" />
      </motion.div>
    </div>
  );
}

