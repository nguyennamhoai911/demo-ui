import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Battery, 
  Zap, 
  Truck, 
  Bot, 
  Warehouse, 
  Settings, 
  ShieldCheck, 
  Globe, 
  ArrowRight,
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  BarChart3,
  Search,
  Award,
  Users
} from 'lucide-react';

// --- Types ---
interface ProductCardProps {
  title: string;
  description: string;
  image: string;
}

// --- Shared Components ---

const Button = ({ children, variant = 'primary', className = '', ...props }: any) => {
  const base = "px-6 py-3 font-medium transition-all duration-300 flex items-center justify-center gap-2 group cursor-pointer";
  const variants: any = {
    primary: "bg-brand-red text-white hover:bg-[#c2191e]",
    secondary: "bg-brand-black text-white hover:bg-zinc-800",
    outline: "border border-zinc-300 hover:border-brand-red hover:text-brand-red text-zinc-700",
    white: "bg-white text-brand-black hover:bg-zinc-100",
    ghost: "text-zinc-600 hover:text-brand-red"
  };
  
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
};

// --- Section Components ---

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Giải pháp', href: '#solutions' },
    { name: 'Sản phẩm', href: '#products' },
    { name: 'Ứng dụng', href: '#applications' },
    { name: 'OEM / ODM', href: '#oem' },
    { name: 'Về PKG', href: '#about' },
    { name: 'Liên hệ', href: '#contact' },
  ];

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-[1400px] mx-auto px-6 flex items-center justify-between">
        <a href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-brand-red flex items-center justify-center">
            <Battery className="text-white w-6 h-6" />
          </div>
          <div className="flex flex-col leading-none">
            <span className={`text-xl font-display font-bold tracking-tighter ${!isScrolled ? 'text-white' : 'text-brand-black'}`}>PKG BATTERY</span>
            <span className={`text-[10px] font-medium tracking-[0.2em] uppercase ${!isScrolled ? 'text-white/60' : 'text-brand-black/40'}`}>Industrial Energy</span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className={`text-sm font-medium transition-colors hover:text-brand-red ${!isScrolled ? 'text-white' : 'text-brand-black'}`}
            >
              {link.name}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <button className={`hidden sm:flex text-sm font-bold items-center gap-1 hover:text-brand-red transition-colors ${!isScrolled ? 'text-white' : 'text-brand-black'}`}>
            VI / EN
          </button>
          <Button variant={isScrolled ? 'primary' : 'white'} className="hidden md:flex">
            Nhận tư vấn kỹ thuật
          </Button>
          <button onClick={() => setMobileMenuOpen(true)} className={`lg:hidden ${!isScrolled ? 'text-white' : 'text-brand-black'}`}>
            <Menu className="w-8 h-8" />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 bg-white z-[60] flex flex-col p-8"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="font-display font-bold text-2xl tracking-tighter">PKG BATTERY</span>
              <button onClick={() => setMobileMenuOpen(false)}>
                <X className="w-8 h-8" />
              </button>
            </div>
            <div className="flex flex-col gap-6">
              {navLinks.map((link) => (
                <a key={link.name} href={link.href} onClick={() => setMobileMenuOpen(false)} className="text-3xl font-display font-bold hover:text-brand-red">
                  {link.name}
                </a>
              ))}
            </div>
            <div className="mt-auto">
              <Button className="w-full">Nhận tư vấn kỹ thuật</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

const Hero = () => {
  return (
    <section className="relative h-screen min-h-[800px] w-full overflow-hidden bg-brand-black">
      {/* Background Overlay */}
      <div className="absolute inset-0 opacity-40">
        <img 
          src="https://picsum.photos/seed/factory-hero-pkg/1920/1080" 
          alt="Technical Background" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-black via-brand-black/60 to-transparent"></div>
      </div>

      <div className="absolute inset-0 scanline opacity-30"></div>

      <div className="relative z-10 h-full max-w-[1400px] mx-auto px-6 pt-32 flex flex-col justify-center">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          <span className="inline-block px-3 py-1 bg-brand-red text-white text-xs font-bold tracking-[0.2em] mb-6 uppercase">
            Giải pháp Pin Lithium Công nghiệp
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-white leading-[0.9] tracking-tighter mb-8">
            Đối tác Pin Lithium & Sạc <span className="text-brand-red">toàn diện</span> cho doanh nghiệp
          </h1>
          <p className="text-xl text-white/70 max-w-2xl mb-12 leading-relaxed">
            Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp vận hành ổn định, giảm downtime và tối ưu chi phí sở hữu dài hạn. PKG Battery đồng hành cùng bạn trong hành trình chuyển đổi năng lượng xanh.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="h-14 px-10 text-lg">
              Nhận tư vấn kỹ thuật
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="outline" className="h-14 px-10 text-lg !text-white border-white/20 hover:border-brand-red">
              Xem nhóm giải pháp
            </Button>
          </div>
        </motion.div>

        {/* Floating Technical Stats */}
        <div className="absolute bottom-12 right-6 hidden xl:grid grid-cols-2 gap-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-sm w-64"
          >
            <Zap className="text-brand-red w-8 h-8 mb-4" />
            <div className="text-3xl font-display font-bold text-white mb-1">99.8%</div>
            <div className="text-xs text-white/40 uppercase tracking-widest leading-tight">Uptime Vận Hành<br/>Logistics & Kho Vận</div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7 }}
            className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-sm w-64"
          >
            <Settings className="text-white w-8 h-8 mb-4 opacity-60" />
            <div className="text-xl font-display font-bold text-white mb-1">Custom Built</div>
            <div className="text-xs text-white/40 uppercase tracking-widest leading-tight">OEM / ODM<br/>Solutions Available</div>
          </motion.div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] text-white/40 uppercase tracking-widest">Scroll</span>
        <div className="w-0.5 h-12 bg-gradient-to-b from-brand-red to-transparent"></div>
      </motion.div>
    </section>
  );
};

const TrustStrip = () => {
  return (
    <section className="bg-white py-12 border-b border-zinc-100">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-16">
          <div className="text-sm font-bold uppercase tracking-widest text-zinc-400 whitespace-nowrap">
            Đồng hành cùng doanh nghiệp trong:
          </div>
          <div className="flex flex-wrap justify-center lg:justify-between items-center gap-x-12 gap-y-8 w-full opacity-60 grayscale hover:grayscale-0 transition-all duration-700">
            {['LOGISTICS', 'MANUFACTURING', 'WAREHOUSE', 'AUTOMATION', 'RESORT MOBILITY', 'ENERGY STORAGE'].map((item) => (
              <span key={item} className="text-xl font-display font-bold text-brand-black tracking-tighter">
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const PainPoints = () => {
  const points = [
    {
      title: "Thời gian sạc dài",
      desc: "Lãng phí tiềm năng vận hành khi thiết bị phải chờ sạc quá lâu, gây vỡ kế hoạch logistics."
    },
    {
      title: "Downtime ảnh hưởng năng suất",
      desc: "Mỗi giờ dừng máy là một giờ tổn thất doanh thu trực tiếp và uy tín với khách hàng."
    },
    {
      title: "Chi phí bảo trì cao",
      desc: "Pin truyền thống cần bảo trì định kỳ phức tạp, tốn kém nhân lực và chi phí vật tư."
    },
    {
      title: "Khó đảm bảo an toàn",
      desc: "Nguy cơ cháy nổ nếu không có hệ thống BMS quản lý thông minh và cell pin tiêu chuẩn."
    }
  ];

  return (
    <section className="py-24 bg-zinc-50 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div>
          <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Vấn đề của doanh nghiệp</span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-tight tracking-tighter mb-8">
            Downtime, bảo trì và chi phí ẩn đang làm vận hành kém hiệu quả hơn bạn nghĩ
          </h2>
          <p className="text-lg text-zinc-600 mb-10 leading-relaxed max-w-xl">
            Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện năng mà còn mất thời gian, năng suất và khả năng kiểm soát chi phí dài hạn.
          </p>
          <img 
            src="https://picsum.photos/seed/logistic-efficiency/800/600" 
            alt="Logistic Efficiency" 
            className="w-full aspect-[4/3] object-cover grayscale brightness-90 shadow-2xl"
            referrerPolicy="no-referrer"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {points.map((point, index) => (
            <motion.div 
              key={index}
              whileHover={{ y: -5 }}
              className="p-8 bg-white border-l-4 border-zinc-200 hover:border-brand-red transition-all duration-300 shadow-sm"
            >
              <h3 className="text-xl font-display font-bold mb-4">{point.title}</h3>
              <p className="text-zinc-500 text-sm leading-relaxed">{point.desc}</p>
            </motion.div>
          ))}
          <div className="md:col-span-2 p-8 bg-brand-black text-white">
            <h3 className="text-2xl font-display font-bold mb-6 italic text-brand-red">"Giải bài toán vận hành 24/7"</h3>
            <p className="text-white/60 text-sm leading-relaxed mb-8">
              PKG Battery không chỉ bán pin, chúng tôi cung cấp giải pháp tối ưu TCO giúp doanh nghiệp tăng lợi thế cạnh tranh thông qua hạ tầng năng lượng hiện đại.
            </p>
            <Button variant="white" className="w-full">Khám phá giải pháp</Button>
          </div>
        </div>
      </div>
    </section>
  );
};

const AboutEnterprise = () => {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          <div className="lg:col-span-12 mb-8 border-b border-zinc-100 pb-12">
             <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Hồ sơ năng lực</span>
             <h2 className="text-4xl md:text-5xl font-display font-bold leading-tight tracking-tighter mb-4">Đối tác năng lượng lithium công nghiệp chuẩn quốc tế</h2>
          </div>
          <div className="lg:col-span-5">
            <div className="space-y-6 text-zinc-600 leading-relaxed text-lg">
              <p>
                <b>PKG Battery</b> được định hướng như một doanh nghiệp B2B chuyên cung cấp pin lithium công nghiệp, bộ sạc và giải pháp kỹ thuật theo ứng dụng thực tế. Chúng tôi phục vụ nhu cầu khắt khe của các nhà máy sản xuất, đơn vị logistics và các đối tác FDI tại Việt Nam.
              </p>
              <p>
                Không chỉ dừng lại ở việc cung cấp sản phẩm, PKG Battery hướng tới việc đồng hành cùng doanh nghiệp trong việc lựa chọn cấu hình phù hợp, tối ưu hiệu quả vận hành và hỗ trợ triển khai thực tế.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mt-12 pt-12 border-t border-zinc-100">
              <div>
                <div className="text-5xl font-display font-bold text-brand-black">08+</div>
                <div className="text-xs text-zinc-400 uppercase font-bold mt-1 tracking-widest">Đại lý toàn quốc</div>
              </div>
              <div>
                <div className="text-5xl font-display font-bold text-brand-black">100%</div>
                <div className="text-xs text-zinc-400 uppercase font-bold mt-1 tracking-widest">Tư vấn kỹ thuật</div>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-7 relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="pt-12">
                <img 
                  src="https://picsum.photos/seed/industrial-team/600/800" 
                  alt="Enterprise Office" 
                  className="w-full h-full object-cover grayscale"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="space-y-4">
                <img 
                  src="https://picsum.photos/seed/lithium-module/600/500" 
                  alt="Battery Manufacturing" 
                  className="w-full aspect-square object-cover"
                  referrerPolicy="no-referrer"
                />
                <img 
                  src="https://picsum.photos/seed/industrial-line/600/400" 
                  alt="Assembly" 
                  className="w-full h-48 object-cover brightness-50"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <div className="absolute -bottom-8 -left-8 bg-brand-red text-white p-12 max-w-xs hidden md:block">
              <div className="text-4xl font-display font-bold mb-2 tracking-tighter">B2B Core</div>
              <p className="text-sm opacity-80 leading-relaxed font-medium">Chuyên sâu giải pháp cho doanh nghiệp, FDI và đối tác OEM quốc tế.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const SolutionEcosystem = () => {
    return (
        <section id="solutions" className="py-24 bg-zinc-50 border-y border-zinc-200">
            <div className="max-w-[1400px] mx-auto px-6">
                <div className="flex flex-col items-center text-center max-w-3xl mx-auto mb-20">
                    <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4">Hệ sinh thái PKG</span>
                    <h2 className="text-4xl md:text-6xl font-display font-bold tracking-tighter mb-8 italic">Từ cell pin đơn lẻ đến giải pháp vận hành hoàn chỉnh</h2>
                    <p className="text-zinc-600">PKG Battery xây dựng giải pháp pin lithium công nghiệp theo bài toán thực tế của doanh nghiệp — từ khảo sát nhu cầu, cấu hình pin và sạc phù hợp, đến triển khai và hỗ trợ kỹ thuật.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    {[
                        { icon: <Search />, title: "Đánh giá nhu cầu", desc: "Khảo sát thực tế cường độ vận hành" },
                        { icon: <Settings />, title: "Cấu hình chuẩn", desc: "Đề xuất thông số pin & sạc tối ưu" },
                        { icon: <Zap />, title: "Tùy chỉnh kỹ thuật", desc: "Tích hợp BMS & Firmware chuyên biệt" },
                        { icon: <Truck />, title: "Triển khai lắp đặt", desc: "Hỗ trợ lắp đặt & test thực tế" },
                        { icon: <ShieldCheck />, title: "Hành trình hậu mãi", desc: "Bảo trì & hỗ trợ kỹ thuật 24/7" }
                    ].map((step, i) => (
                        <div key={i} className="bg-white p-8 border border-zinc-100 flex flex-col items-center text-center group hover:bg-brand-red hover:text-white transition-all duration-500">
                            <div className="w-14 h-14 rounded-full bg-zinc-50 flex items-center justify-center mb-6 group-hover:bg-white/10 group-hover:text-white transition-colors">
                                {React.cloneElement(step.icon as React.ReactElement, { className: "w-6 h-6" })}
                            </div>
                            <h3 className="text-lg font-display font-bold mb-3">{step.title}</h3>
                            <p className="text-xs opacity-60 leading-relaxed">{step.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

const ProductShowcase = () => {
  const products = [
    {
      id: 'xe-nang',
      title: "Pin Lithium cho Xe Nâng Điện",
      desc: "Giải pháp tối ưu cho kho vận với khả năng sạc nhanh, không cần bảo trì và hỗ trợ cường độ vận hành 3 ca liên tục.",
      image: "https://picsum.photos/seed/forklift-p-1/800/600",
      app: "Kho vận, Nhà máy, Cảng biển"
    },
    {
      id: 'du-lich',
      title: "Pin Lithium cho Xe Điện Du Lịch",
      desc: "Thiết kế cho xe golf, buggy và phương tiện resort cần độ ổn định, tuổi thọ cao và trải nghiệm vận hành êm ái.",
      image: "https://picsum.photos/seed/golf-p-2/800/600",
      app: "Resort, Khu du lịch, Sân golf"
    },
    {
      id: 'agv',
      title: "Pin cho Xe AGV / Robot",
      desc: "Năng lượng cho hệ thống tự động hóa cần tính tương thích cao, độ ổn định BMS và khả năng tích hợp kỹ thuật phức tạp.",
      image: "https://picsum.photos/seed/robot-p-3/800/600",
      app: "Tự động hóa, Kho thông minh"
    },
    {
      id: 'charger',
      title: "Bộ Sạc – Trạm Sạc",
      desc: "Giải pháp sạc đồng bộ giúp tối ưu hiệu suất pin, rút ngắn thời gian chờ và phù hợp nhiều chuẩn công nghiệp.",
      image: "https://picsum.photos/seed/charge-p-4/800/600",
      app: "Toàn bộ hệ sinh thái pin"
    },
    {
      id: 'ess',
      title: "Hệ thống Lưu trữ Năng lượng ESS",
      desc: "Giải pháp lưu trữ cho doanh nghiệp cần chủ động nguồn điện, ổn định sản xuất và tối ưu chi phí tiền điện giờ cao điểm.",
      image: "https://picsum.photos/seed/ess-p-5/800/600",
      app: "Nhà máy, Tòa nhà, Trạm viễn thông"
    }
  ];

  return (
    <section id="products" className="py-24 bg-brand-black text-white">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 px-4 border-l-4 border-brand-red">
          <div className="max-w-2xl">
            <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Product Catalog</span>
            <h2 className="text-4xl md:text-6xl font-display font-bold tracking-tighter leading-none mb-4">
              Dòng giải pháp chủ lực
            </h2>
            <p className="text-white/40">Phân loại theo ứng dụng thực tế để doanh nghiệp dễ dàng lựa chọn.</p>
          </div>
          <Button variant="white" className="shrink-0 uppercase text-xs tracking-widest font-bold">Tải Catalog Kỹ Thuật</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-20 gap-x-12">
          {products.map((p, i) => (
            <motion.div 
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[16/10] overflow-hidden mb-8">
                <img 
                  src={p.image} 
                  alt={p.title} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 filter grayscale group-hover:grayscale-0" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-brand-black/40 group-hover:bg-transparent transition-colors"></div>
                <div className="absolute top-4 left-4 bg-brand-red text-white py-1.5 px-4 text-[10px] font-bold uppercase tracking-widest">
                  {p.app}
                </div>
              </div>
              <h3 className="text-2xl font-display font-bold mb-4 group-hover:text-brand-red transition-colors">{p.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed mb-8 line-clamp-2">
                {p.desc}
              </p>
              <div className="flex items-center gap-2 text-white font-bold text-xs tracking-widest group-hover:gap-4 transition-all uppercase">
                Khám phá giải pháp <ArrowRight className="w-4 h-4 text-brand-red" />
              </div>
            </motion.div>
          ))}
          
          <div className="lg:col-span-1 border border-white/10 p-12 flex flex-col justify-center items-start bg-zinc-900/40 backdrop-blur-sm group hover:border-brand-red transition-colors">
            <Settings className="w-14 h-14 text-white/20 mb-8 group-hover:text-brand-red group-hover:rotate-45 transition-all duration-700" />
            <h3 className="text-3xl font-display font-bold mb-6 tracking-tight italic">Tùy chỉnh kỹ thuật<br/>theo dự án thực tế</h3>
            <p className="text-white/40 mb-10 leading-relaxed text-sm">
              Sở hữu năng lực sản xuất và thiết kế riêng, chúng tôi nhận OEM / ODM các dòng pin lithium công nghiệp theo thông số chính xác từ đối tác.
            </p>
            <Button variant="white" className="w-full h-14 text-xs font-bold tracking-widest uppercase">Liên hệ OEM / ODM</Button>
          </div>
        </div>
      </div>
    </section>
  );
};

const OEMCapability = () => {
  return (
    <section id="oem" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-zinc-50 hidden lg:block opacity-50"></div>
      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div className="order-2 lg:order-1 relative">
            <div className="relative group">
              <img 
                src="https://picsum.photos/seed/tech-oem-custom/1000/1000" 
                alt="Technical Design" 
                className="w-full aspect-square object-cover shadow-2xl brightness-90 grayscale group-hover:grayscale-0 transition-all duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 border-[20px] border-white/40 pointer-events-none"></div>
            </div>
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-red/10 animate-pulse -z-10 rounded-full"></div>
          </div>
          
          <div className="order-1 lg:order-2">
            <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">B2B Customization</span>
            <h2 className="text-4xl md:text-6xl font-display font-bold leading-tight tracking-tighter mb-8">
              OEM / ODM & Tùy chỉnh giải pháp kỹ thuật
            </h2>
            <p className="text-xl text-zinc-600 mb-10 leading-relaxed font-medium">
              PKG Battery hướng tới khả năng hợp tác chuyên sâu với các đối tác FDI, doanh nghiệp quốc tế cần cấu hình pin lithium đặc thù về kích thước và điện áp.
            </p>
            
            <div className="space-y-6 mb-12">
              {[
                { title: "Standard Cells", desc: "Sử dụng cell pin tiêu chuẩn từ các hãng lớn nhất thế giới." },
                { title: "Custom BMS", desc: "Phát triển phần mềm quản lý pin tối ưu theo cường độ vận hành." },
                { title: "Form Factor", desc: "Thiết kế vỏ thùng pin phù hợp mọi không gian xe nâng/thiết bị." },
                { title: "Compliance", desc: "Hỗ trợ đầy đủ test report và chứng chỉ tương ứng từ bên thứ 3." }
              ].map((item, i) => (
                <div key={i} className="flex gap-4 group">
                    <div className="w-1 h-0 group-hover:h-12 bg-brand-red transition-all duration-500 mt-2"></div>
                    <div>
                        <h4 className="font-display font-bold text-lg mb-1">{item.title}</h4>
                        <p className="text-sm text-zinc-400">{item.desc}</p>
                    </div>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="px-10 h-14">Trao đổi về OEM / ODM</Button>
              <Button variant="outline" className="px-10 h-14">Gửi yêu cầu cấu hình</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const TrustSignals = () => {
  return (
    <section className="py-24 bg-brand-black text-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_30%,rgba(227,30,36,0.05),transparent_50%)]"></div>
      <div className="max-w-[1400px] mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-12 mb-24">
            <div className="max-w-2xl">
                <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Proven Excellence</span>
                <h2 className="text-4xl md:text-7xl font-display font-bold tracking-tighter mb-8 italic">Năng lực tạo dựng niềm tin</h2>
                <p className="text-white/40 text-lg leading-relaxed">Chúng tôi minh bạch về mọi tiêu chuẩn chất lượng và số liệu năng lực để xây dựng sự tin tưởng vững chắc nhất với đối tác B2B.</p>
            </div>
            <div className="grid grid-cols-2 gap-12">
                {[
                    { label: 'Năm Kinh Nghiệm', v: '10+' },
                    { label: 'Ứng Dụng Hỗ Trợ', v: '06+' }
                ].map((s, i) => (
                    <div key={i}>
                        <div className="text-5xl md:text-7xl font-display font-bold text-white mb-2">{s.v}</div>
                        <div className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold">{s.label}</div>
                    </div>
                ))}
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-24 border-y border-white/5 py-12">
          {[
            { label: 'ISO certified', i: <ShieldCheck /> },
            { label: 'IEC Global Standard', i: <Globe /> },
            { label: 'Safety Verified', i: <Award /> },
            { label: 'Dedicated Support', i: <Users /> }
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4 p-8 bg-white/5 backdrop-blur-sm border border-white/5">
                <div className="text-brand-red">{React.cloneElement(item.i as React.ReactElement, { className: "w-8 h-8" })}</div>
                <span className="text-xs font-bold uppercase tracking-widest">{item.label}</span>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-4">
            <h3 className="text-3xl font-display font-bold mb-6 italic">Chứng chỉ & Tiêu chuẩn</h3>
            <p className="text-white/40 mb-10 leading-relaxed">PKG Battery tuân thủ nghiêm ngặt các quy chuẩn quốc tế về an toàn pin lithium trong môi trường công nghiệp.</p>
            <Button variant="outline" className="!text-white border-white/20 hover:border-brand-red transition-all group">
                Xem Thư Viện Chứng Chỉ
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1" />
            </Button>
          </div>
          <div className="lg:col-span-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="aspect-[1/1.4] bg-white group p-4 relative overflow-hidden">
                    <img 
                      src={`https://picsum.photos/seed/cert-pkg-${i}/400/600`} 
                      alt="Certificate" 
                      className="w-full h-full object-cover grayscale opacity-10 group-hover:opacity-100 group-hover:grayscale-0 transition-all duration-700" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 p-8 flex flex-col justify-end">
                        <div className="text-brand-black text-xs font-bold uppercase tracking-[0.2em] mb-2 opacity-0 group-hover:opacity-100 transition-opacity">A4 Standard</div>
                        <div className="w-full h-0.5 bg-brand-red scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-500"></div>
                    </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const DealerMap = () => {
  return (
    <section id="dealers" className="py-32 bg-white relative">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-24 items-center">
          <div className="lg:col-span-5">
            <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Broad Coverage</span>
            <h2 className="text-4xl md:text-5xl font-display font-bold leading-[1.1] tracking-tighter mb-8">
              Mạng lưới đại lý và phân phối trên toàn Việt Nam
            </h2>
            <p className="text-lg text-zinc-500 mb-12 leading-relaxed">
              Với 08 đại lý hiện tại tại các khu vực trọng điểm như Hà Nội, TP.HCM, Hải Phòng, Bắc Ninh... đảm bảo cung ứng và hỗ trợ kỹ thuật nhanh nhất.
            </p>
            
            <div className="grid grid-cols-1 gap-1">
              {[
                { city: 'Hà Nội', addr: 'Khu công nghiệp Quang Minh' },
                { city: 'Bắc Ninh', addr: 'Khu công nghiệp VSIP' },
                { city: 'Hải Phòng', addr: 'Khu công nghiệp Đình Vũ' },
                { city: 'Đà Nẵng', addr: 'Quận Liên Chiểu (Coming Soon)' },
                { city: 'TP. Hồ Chí Minh', addr: 'Q7 & Khu chế xuất Tân Thuận' },
              ].map((loc, i) => (
                <div key={i} className="flex justify-between items-center p-6 border-b border-zinc-100 hover:bg-zinc-50 transition-colors cursor-pointer group">
                  <div>
                    <span className="text-brand-black font-display font-bold text-xl group-hover:text-brand-red transition-colors">{loc.city}</span>
                    <p className="text-[10px] text-zinc-400 mt-2 uppercase font-bold tracking-widest">{loc.addr}</p>
                  </div>
                  <div className="w-10 h-10 rounded-full border border-zinc-100 flex items-center justify-center group-hover:bg-brand-red group-hover:border-brand-red transition-all">
                     <ChevronRight className="w-4 h-4 text-zinc-300 group-hover:text-white" />
                  </div>
                </div>
              ))}
            </div>
            
            <Button variant="secondary" className="mt-12 px-12 h-14 uppercase text-xs tracking-widest font-bold">Hệ thống đại lý chi tiết</Button>
          </div>
          
          <div className="lg:col-span-7 bg-zinc-50 aspect-[4/5] md:aspect-square flex items-center justify-center p-12 relative overflow-hidden group">
            <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-brand-red/10 to-transparent top-1/4"></div>
            <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-brand-red/10 to-transparent top-3/4"></div>
            
            <div className="relative h-full w-full max-w-[450px] flex items-center justify-center pointer-events-none">
              <svg viewBox="0 0 200 600" className="w-full h-full fill-zinc-200 stroke-zinc-300 stroke-1 opacity-60">
                <path d="M70,30 L85,45 L110,60 L130,90 L140,130 L110,180 L90,220 L100,280 L130,340 L160,400 L170,480 L150,540 L110,570 L50,550 L30,500 L60,420 L90,340 L80,260 L60,180 L40,120 L50,60 Z" />
              </svg>
              
              {[
                { top: '12%', left: '48%', delay: 0 },
                { top: '24%', left: '62%', delay: 0.4 },
                { top: '28%', left: '52%', delay: 0.8 },
                { top: '78%', left: '72%', delay: 0.2 },
                { top: '88%', left: '62%', delay: 0.6 }
              ].map((pos, i) => (
                <motion.div 
                  key={i}
                  animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
                  transition={{ duration: 4, repeat: Infinity, delay: pos.delay }}
                  style={{ top: pos.top, left: pos.left }}
                  className="absolute w-5 h-5 bg-brand-red rounded-full flex items-center justify-center"
                >
                  <div className="absolute w-10 h-10 border-2 border-brand-red rounded-full opacity-0 animate-ping"></div>
                </motion.div>
              ))}
            </div>
            
            <div className="absolute right-12 bottom-12 p-8 bg-brand-black text-white max-w-xs shadow-2xl scale-0 group-hover:scale-100 transition-transform duration-700 origin-bottom-right">
                <BarChart3 className="text-brand-red w-8 h-8 mb-4" />
                <h4 className="text-2xl font-display font-bold mb-2 tracking-tighter leading-none italic">Chiếm Lĩnh 80%</h4>
                <p className="text-xs text-white/40 uppercase tracking-widest leading-relaxed">Độ phủ thị trường pin lithium xe nâng điện 2026</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const NewsSection = () => {
    const news = [
        { title: "Xu hướng tự động hóa 2026: Vai trò của xe AGV trong kho thông minh", date: "21.04.2026", cat: "KIẾN THỨC", img: "https://picsum.photos/seed/news-agv/600/400" },
        { title: "So sánh Pin Lithium và Acid Chì: Bài toán tối ưu TCO cho doanh nghiệp", date: "18.04.2026", cat: "B2B INSIGHT", img: "https://picsum.photos/seed/news-lithium/600/400" },
        { title: "PKG Battery ra mắt giải pháp ESS 500kWh cho nhà máy sản xuất", date: "15.04.2026", cat: "SỰ KIỆN", img: "https://picsum.photos/seed/news-ess/600/400" }
    ];

    return (
        <section className="py-32 bg-zinc-50">
            <div className="max-w-[1400px] mx-auto px-6">
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
                    <div className="max-w-2xl">
                        <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Knowledge Center</span>
                        <h2 className="text-4xl md:text-6xl font-display font-bold tracking-tighter italic">Kiến thức kỹ thuật & Cập nhật từ PKG</h2>
                    </div>
                    <Button variant="outline">Xem Tất Cả Bài Viết</Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    {news.map((item, i) => (
                        <div key={i} className="group cursor-pointer">
                            <div className="aspect-[16/10] overflow-hidden mb-8 relative">
                                <img src={item.img} alt={item.title} className="w-full h-full object-cover grayscale transition-all duration-1000 group-hover:scale-110 group-hover:grayscale-0" referrerPolicy="no-referrer" />
                                <div className="absolute top-4 left-4 bg-white px-3 py-1 text-[10px] font-bold text-brand-black tracking-widest uppercase">{item.cat}</div>
                            </div>
                            <div className="text-xs text-zinc-400 font-bold mb-4 uppercase tracking-[0.2em]">{item.date}</div>
                            <h3 className="text-2xl font-display font-bold leading-tight group-hover:text-brand-red transition-colors mb-6">{item.title}</h3>
                            <div className="w-12 h-1 bg-zinc-200 group-hover:w-full group-hover:bg-brand-red transition-all duration-500"></div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

const ContactSection = () => {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="bg-brand-black text-white p-8 md:p-24 grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div>
            <span className="text-brand-red text-sm font-bold tracking-[0.2em] uppercase mb-4 block">Connect with our Experts</span>
            <h2 className="text-5xl md:text-7xl font-display font-bold tracking-tighter leading-[0.9] mb-12 italic">
              Nhận tư vấn kỹ thuật cho bài toán năng lượng
            </h2>
            <p className="text-lg text-white/40 mb-16 max-w-md">Trao đổi trực tiếp để được đánh giá nhu cầu vận hành, đề xuất cấu hình pin tối ưu cho hiệu quả dài hạn.</p>
            
            <div className="space-y-12">
              <div className="flex gap-8 items-start">
                <div className="w-16 h-16 bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                  <Phone className="w-8 h-8 text-brand-red" />
                </div>
                <div>
                  <div className="text-[10px] text-white/30 uppercase font-bold tracking-widest mb-2">B2B Hotline 24/7</div>
                  <div className="text-3xl font-display font-bold tracking-tight">09x xxx xxxx</div>
                </div>
              </div>
              <div className="flex gap-8 items-start">
                <div className="w-16 h-16 bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                  <Mail className="w-8 h-8 text-brand-red" />
                </div>
                <div>
                  <div className="text-[10px] text-white/30 uppercase font-bold tracking-widest mb-2">Email Kỹ Thuật</div>
                  <div className="text-3xl font-display font-bold tracking-tight">tech@pkgbattery.vn</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-8 md:p-14 text-brand-black relative">
            <div className="absolute -top-12 -right-12 w-24 h-24 bg-brand-red flex items-center justify-center -z-10 hidden md:flex">
                <Search className="text-white w-10 h-10" />
            </div>
            <form className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Họ và tên</label>
                  <input type="text" className="w-full border-b-2 border-zinc-100 py-4 focus:outline-none focus:border-brand-red transition-colors font-medium text-lg" placeholder="Họ và tên của bạn" />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Số điện thoại</label>
                  <input type="tel" className="w-full border-b-2 border-zinc-100 py-4 focus:outline-none focus:border-brand-red transition-colors font-medium text-lg" placeholder="090..." />
                </div>
              </div>
              <div className="space-y-3">
                <label className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Đơn vị / Doanh nghiệp</label>
                <input type="text" className="w-full border-b-2 border-zinc-100 py-4 focus:outline-none focus:border-brand-red transition-colors font-medium text-lg" placeholder="CÔNG TY TNHH ABC" />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Lĩnh vực hoạt động</label>
                <select className="w-full border-b-2 border-zinc-100 py-4 focus:outline-none focus:border-brand-red transition-colors bg-transparent font-medium text-lg">
                  <option>Logistics & Kho vận</option>
                  <option>Sản xuất & Nhà máy</option>
                  <option>Tự động hóa / AGV / Robot</option>
                  <option>Dịch vụ du lịch / Resort</option>
                  <option>Khác / Đối tác quốc tế</option>
                </select>
              </div>
              <div className="space-y-3">
                <label className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Ghi chú nhu cầu kỹ thuật</label>
                <textarea rows={3} className="w-full border-2 border-zinc-100 p-6 focus:outline-none focus:border-brand-red transition-colors bg-zinc-50 font-medium" placeholder="Mô tả ngắn gọn nhu cầu thực tế..."></textarea>
              </div>
              <Button className="w-full h-16 text-xs uppercase font-bold tracking-[0.2em]">Gửi Yêu Cầu Tư Vấn Ngay</Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-white border-t border-zinc-100 pt-32 pb-16">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-20 mb-32">
          <div className="lg:col-span-1">
            <a href="/" className="flex items-center gap-2 mb-8">
              <div className="w-10 h-10 bg-brand-red flex items-center justify-center">
                <Battery className="text-white w-6 h-6" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-2xl font-display font-bold tracking-tighter">PKG BATTERY</span>
                <span className="text-[10px] font-bold tracking-[0.2em] text-zinc-400 uppercase">Energy Excellence</span>
              </div>
            </a>
            <p className="text-zinc-500 text-sm leading-relaxed mb-10 max-w-xs">
              Giải pháp pin lithium công nghiệp cao cấp, bộ sạc và hệ thống lưu trữ năng lượng cho hạ tầng doanh nghiệp hiện đại.
            </p>
            <div className="flex gap-4">
              {['FB', 'LN', 'YT'].map(s => (
                <div key={s} className="w-12 h-12 border border-zinc-100 flex items-center justify-center hover:bg-brand-red hover:text-white transition-all cursor-pointer font-bold text-xs">
                    {s}
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] mb-10 text-zinc-400">Giải pháp & Sản phẩm</h4>
            <ul className="space-y-6 text-sm text-zinc-600 font-bold uppercase tracking-[0.1em]">
              <li><a href="#" className="hover:text-brand-red transition-colors">Pin Xe Nâng Điện</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Pin Xe Điện Du Lịch</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Pin Robot / AGV</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Bộ Sạc & Trạm Sạc</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Hệ Thống ESS</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] mb-10 text-zinc-400">Menu Hệ Thống</h4>
            <ul className="space-y-6 text-sm text-zinc-600 font-bold uppercase tracking-[0.1em]">
              <li><a href="#" className="hover:text-brand-red transition-colors">Về PKG Battery</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Hồ Sơ Năng Lực</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Hệ Thống Đại Lý</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">OEM / ODM Partner</a></li>
              <li><a href="#" className="hover:text-brand-red transition-colors">Tin Tức Kỹ Thuật</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] mb-10 text-zinc-400">Thông tin liên hệ</h4>
            <div className="space-y-8 text-sm text-zinc-500 leading-relaxed font-medium">
              <div className="flex gap-4 items-start">
                <MapPin className="w-5 h-5 text-brand-red shrink-0" />
                <span>Trụ sở chính & Showroom:<br/>Quận 7, TP. Hồ Chí Minh, Việt Nam</span>
              </div>
              <div className="flex gap-4">
                <Mail className="w-5 h-5 text-brand-red shrink-0" />
                <span>contact@pkgbattery.vn</span>
              </div>
              <div className="flex gap-4">
                <Phone className="w-5 h-5 text-brand-red shrink-0" />
                <span>09x xxx xxxx</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-16 border-t border-zinc-100 flex flex-col md:flex-row justify-between gap-8 items-center">
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-300">
            © 2026 PKG BATTERY CO., LTD. LEADING INDUSTRIAL ENERGY SOLUTIONS.
          </p>
          <div className="flex gap-12 text-[10px] font-bold uppercase tracking-widest text-zinc-400">
            <a href="#" className="hover:text-brand-black transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-brand-black transition-colors">English Version</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  return (
    <main className="relative selection:bg-brand-red selection:text-white">
      <Header />
      <Hero />
      <TrustStrip />
      <PainPoints />
      <AboutEnterprise />
      <SolutionEcosystem />
      <ProductShowcase />
      <OEMCapability />
      <TrustSignals />
      <DealerMap />
      <NewsSection />
      <ContactSection />
      <Footer />
    </main>
  );
}
