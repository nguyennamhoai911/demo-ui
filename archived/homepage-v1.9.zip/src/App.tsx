/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  Battery, 
  Zap, 
  ShieldCheck, 
  Settings, 
  MapPin, 
  ChevronRight, 
  Menu, 
  X, 
  Globe, 
  Cpu, 
  Warehouse, 
  Truck, 
  Terminal,
  Factory,
  BarChart3,
  HardHat,
  MessageSquare,
  FileText,
  Mail,
  Phone,
  Clock,
  CheckCircle2,
  AlertCircle,
  Search
} from 'lucide-react';

// --- Types ---
interface Product {
  id: string;
  title: string;
  description: string;
  application: string;
  image: string;
}

interface Stat {
  label: string;
  value: string;
  suffix?: string;
}

// --- Components ---

const Button = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  ...props 
}: { children: React.ReactNode, variant?: 'primary' | 'secondary' | 'outline' | 'ghost', className?: string } & React.ButtonHTMLAttributes<HTMLButtonElement>) => {
  const baseStyles = "relative px-6 py-3 font-medium transition-all duration-300 flex items-center justify-center gap-2 group overflow-hidden";
  const variants = {
    primary: "bg-brand-red text-white hover:bg-red-700",
    secondary: "bg-industrial-black text-white hover:bg-black",
    outline: "border border-industrial-black text-industrial-black hover:bg-industrial-black hover:text-white",
    ghost: "text-industrial-black hover:bg-industrial-gray",
  };

  return (
    <button className={`${baseStyles} ${variants[variant]} ${className}`} {...props}>
      <span className="relative z-10">{children}</span>
      <motion.div 
        className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[0%] transition-transform duration-300" 
      />
    </button>
  );
};

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <div className="flex items-center gap-2 mb-6">
    <div className="w-8 h-[1px] bg-brand-red" />
    <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-red font-semibold">
      {children}
    </span>
  </div>
);

// --- Section Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white/90 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-brand-red flex items-center justify-center">
            <span className="text-white font-bold text-xl">P</span>
          </div>
          <span className={`text-2xl font-display font-bold tracking-tighter ${isScrolled ? 'text-industrial-black' : 'text-industrial-black'}`}>
            PKG<span className="text-brand-red">BATTERY</span>
          </span>
        </div>

        <div className="hidden lg:flex items-center gap-8">
          {['Giải pháp', 'Sản phẩm', 'Ứng dụng', 'OEM / ODM', 'Về PKG'].map((item) => (
            <a key={item} href="#" className="text-sm font-medium hover:text-brand-red transition-colors">
              {item}
            </a>
          ))}
          <Button className="hidden xl:flex">Nhận tư vấn kỹ thuật</Button>
        </div>

        <button className="lg:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-white shadow-xl lg:hidden p-6 flex flex-col gap-4 border-t"
          >
            {['Giải pháp', 'Sản phẩm', 'Ứng dụng', 'OEM / ODM', 'Về PKG'].map((item) => (
              <a key={item} href="#" className="text-lg font-medium p-2">{item}</a>
            ))}
            <Button>Nhận tư vấn kỹ thuật</Button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-industrial-gray">
      {/* Background Video/Image placeholder */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/industrial-battery/1920/1080?grayscale" 
          className="w-full h-full object-cover opacity-20" 
          alt="Industrial Automation"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-industrial-gray via-transparent to-transparent" />
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10 w-full">
        <div className="lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <SectionLabel>GIẢI PHÁP PIN LITHIUM CÔNG NGHIỆP</SectionLabel>
            <h1 className="text-6xl md:text-8xl font-bold leading-[0.9] mb-8">
              Đối tác pin <br />
              <span className="text-brand-red">lithium & sạc</span> <br />
              toàn diện
            </h1>
            <p className="text-lg text-gray-600 max-w-xl mb-10 leading-relaxed">
              Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp vận hành ổn định, 
              giảm downtime và tối ưu chi phí sở hữu dài hạn. Tư vấn kỹ thuật thực chiến 
              cho mọi ứng dụng công nghiệp.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="px-10 h-16 text-lg">Nhận tư vấn kỹ thuật <ArrowRight size={20} /></Button>
              <Button variant="outline" className="px-10 h-16 text-lg">Xem giải pháp</Button>
            </div>
          </motion.div>
        </div>

        <div className="lg:col-span-5 relative hidden lg:block">
          <motion.div
            style={{ y: y1 }}
            className="relative"
          >
            <div className="aspect-[4/5] bg-industrial-black rounded-sm overflow-hidden shadow-2xl relative">
              <img 
                src="https://picsum.photos/seed/battery-pack/800/1000" 
                className="w-full h-full object-cover opacity-80" 
                alt="PKG Battery Solution"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <div className="absolute bottom-8 left-8 right-8">
                <div className="flex items-center gap-2 mb-2">
                  <Cpu className="text-brand-red" size={24} />
                  <span className="text-white font-mono text-xs tracking-widest">BMS INTEGRATED</span>
                </div>
                <h3 className="text-white text-2xl font-bold">PKG SERIES INDUSTRIAL</h3>
              </div>
            </div>

            {/* Floating UI elements */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-10 -right-10 bg-white p-6 shadow-xl w-48 border-l-4 border-brand-red"
            >
              <div className="text-3xl font-bold text-industrial-black mb-1">99.9%</div>
              <div className="text-[10px] font-mono text-gray-500 uppercase tracking-wider leading-tight">System Reliability Rate</div>
            </motion.div>

            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute -bottom-10 -left-10 bg-industrial-black text-white p-6 shadow-xl w-56"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-[10px] font-mono uppercase tracking-widest">Global Standards</span>
              </div>
              <div className="text-sm font-medium leading-snug">ISO, IEC Compliance <br/> & Industrial Grade Safety</div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Decorative Grid */}
      <div className="absolute bottom-0 right-0 w-1/3 h-1/2 opacity-10 pointer-events-none">
        <div className="w-full h-full" style={{ backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
      </div>
    </section>
  );
};

const TrustStrip = () => {
  return (
    <div className="bg-white border-y border-industrial-border py-12 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-16">
          <div className="whitespace-nowrap flex flex-col">
            <span className="text-[10px] font-mono text-gray-400 uppercase tracking-[0.2em] mb-1">Industrial Sectors</span>
            <span className="text-sm font-semibold text-industrial-black uppercase tracking-wider">Trusted by Industry Leaders</span>
          </div>
          <div className="flex-1 overflow-hidden relative">
            <motion.div 
              animate={{ x: [0, -1000] }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              className="flex items-center gap-20 opacity-40"
            >
              {['LOGISTICS', 'MANUFACTURING', 'AUTOMATION', 'ENERGY STORAGE', 'REHABILITY', 'OEM SQUAD', 'LOGISTICS', 'MANUFACTURING', 'AUTOMATION', 'ENERGY STORAGE'].map((item, idx) => (
                <span key={idx} className="text-2xl font-display font-bold tracking-tighter shrink-0">{item}</span>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

const PainPointSection = () => {
  const points = [
    { title: "Thời gian sạc dài", desc: "Ảnh hưởng trực tiếp đến năng suất vận hành 3 ca liên tục." },
    { title: "Downtime liên tục", desc: "Vấn đề bảo trì ắc quy chì truyền thống gây gián đoạn chuỗi cung ứng." },
    { title: "Chi phí bảo trì cao", desc: "Thay thế định kỳ và nhân sự vận hành gây gánh nặng tài chính." },
    { title: "Khó đảm bảo an toàn", desc: "Rủi ro cháy nổ và rò rỉ hóa chất từ các hệ thống cũ." },
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div>
            <SectionLabel>VẤN ĐỀ VẬN HÀNH</SectionLabel>
            <h2 className="text-5xl font-bold leading-tight mb-8">
              Downtime và chi phí ẩn <br /> đang làm vận hành kém hiệu quả
            </h2>
            <p className="text-gray-600 mb-8 max-w-lg">
              Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện năng mà còn mất thời gian, năng suất và khả năng kiểm soát chi phí dài hạn.
            </p>
            <div className="aspect-[16/9] overflow-hidden rounded-sm bg-industrial-gray">
              <img 
                src="https://picsum.photos/seed/factory-issues/800/450" 
                className="w-full h-full object-cover opacity-60" 
                alt="Industrial Downtime"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-6">
            {points.map((p, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group p-8 border border-industrial-border hover:border-brand-red transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 border border-industrial-border flex items-center justify-center text-brand-red group-hover:bg-brand-red group-hover:text-white transition-colors duration-300 shrink-0">
                    <span className="text-xs font-mono">0{i+1}</span>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold mb-2">{p.title}</h4>
                    <p className="text-gray-500 text-sm">{p.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
            <div className="p-8 bg-industrial-black text-white mt-4">
              <h4 className="text-lg font-bold mb-4">Bạn đang gặp bài toán năng lượng cụ thể?</h4>
              <Button variant="primary" className="w-full py-4">Trao đổi với chuyên gia kỹ thuật</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const AboutSection = () => {
  return (
    <section className="py-24 bg-industrial-gray relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img src="https://picsum.photos/seed/pkg-1/400/500" alt="PKG Team" className="w-full aspect-[4/5] object-cover rounded-sm" referrerPolicy="no-referrer" />
                <img src="https://picsum.photos/seed/pkg-2/400/300" alt="PKG Testing" className="w-full aspect-[4/3] object-cover rounded-sm" referrerPolicy="no-referrer" />
              </div>
              <div className="pt-8 space-y-4">
                <img src="https://picsum.photos/seed/pkg-3/400/300" alt="PKG Warehouse" className="w-full aspect-[4/3] object-cover rounded-sm" referrerPolicy="no-referrer" />
                <img src="https://picsum.photos/seed/pkg-4/400/500" alt="PKG Product" className="w-full aspect-[4/5] object-cover rounded-sm" referrerPolicy="no-referrer" />
              </div>
            </div>
          </div>
          <div className="lg:w-1/2">
            <SectionLabel>VỀ PKG BATTERY</SectionLabel>
            <h2 className="text-5xl font-bold leading-tight mb-8">
              Đối tác năng lượng lithium <br /> cho doanh nghiệp hiện đại
            </h2>
            <div className="space-y-6 text-gray-600 text-lg">
              <p>
                PKG Battery được định hướng như một doanh nghiệp B2B chuyên pin lithium công nghiệp, bộ sạc, trạm sạc và giải pháp kỹ thuật theo ứng dụng.
              </p>
              <p>
                Không chỉ cung cấp sản phẩm, PKG Battery hướng tới việc đồng hành cùng doanh nghiệp trong việc lựa chọn cấu hình phù hợp, tối ưu hiệu quả vận hành và hỗ trợ triển khai thực tế trong nhiều môi trường công nghiệp khác nhau.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mt-12 py-8 border-y border-industrial-border">
              <div>
                <div className="text-3xl font-bold text-brand-red mb-1">08+</div>
                <div className="text-xs font-mono uppercase tracking-widest text-gray-400">Hệ thống đại lý</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-brand-red mb-1">24/7</div>
                <div className="text-xs font-mono uppercase tracking-widest text-gray-400">Hỗ trợ kỹ thuật</div>
              </div>
            </div>

            <Button variant="outline" className="mt-12">Tìm hiểu thêm về năng lực PKG</Button>
          </div>
        </div>
      </div>
    </section>
  );
};

const EcosystemSection = () => {
  const steps = [
    { icon: <Search size={24} />, title: "Khảo sát & Đánh giá", desc: "Xác định cường độ vận hành và môi trường thực tế." },
    { icon: <Settings size={24} />, title: "Thiết kế & Cấu hình", desc: "Đề xuất dung lượng pin và bộ sạc đồng bộ tối ưu." },
    { icon: <Cpu size={24} />, title: "Tùy chỉnh kỹ thuật", desc: "Tích hợp BMS và chuẩn kết nối theo thiết bị gốc." },
    { icon: <CheckCircle2 size={24} />, title: "Triển khai & Vận hành", desc: "Hỗ trợ lắp đặt, hướng dẫn quy trình sạc & xả an toàn." },
  ];

  return (
    <section className="py-24 bg-industrial-black text-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <SectionLabel>HỆ SINH THÁI GIẢI PHÁP</SectionLabel>
          <h2 className="text-5xl font-bold mb-6">Từ pin đến giải pháp vận hành hoàn chỉnh</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            PKG Battery xây dựng giải pháp theo bài toán thực tế của doanh nghiệp — từ khảo sát nhu cầu đến đồng hành vận hành.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connector Line */}
          <div className="hidden lg:block absolute top-[40%] left-0 w-full h-[1px] bg-industrial-border z-0" />
          
          {steps.map((step, i) => (
            <div key={i} className="relative z-10 group">
              <div className="w-16 h-16 bg-brand-red flex items-center justify-center mb-8 mx-auto md:mx-0 group-hover:scale-110 transition-transform duration-300">
                {step.icon}
              </div>
              <h4 className="text-xl font-bold mb-4">{step.title}</h4>
              <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const ProductsSection = () => {
  const products: Product[] = [
    {
      id: "1",
      title: "Pin Lithium Xe Nâng Điện",
      description: "Giải pháp tối ưu cho xe nâng điện với khả năng sạc nhanh, giảm bảo trì và hỗ trợ cường độ vận hành cao.",
      application: "Công nghiệp, Logistics, Nhà máy",
      image: "https://picsum.photos/seed/forklift-battery/600/800"
    },
    {
      id: "2",
      title: "Pin Lithium Xe Điện Du Lịch",
      description: "Thiết kế cho xe buggy, xe golf cần độ ổn định, tuổi thọ cao và trải nghiệm vận hành bền bỉ.",
      application: "Resort, Sân Golf, Khu du lịch",
      image: "https://picsum.photos/seed/buggy-battery/600/801"
    },
    {
      id: "3",
      title: "Pin cho AGV / Robot",
      description: "Năng lượng cho hệ thống tự động hóa cần độ ổn định, độ chính xác và khả năng tích hợp kỹ thuật cao.",
      application: "Nhà máy thông minh, Cảng hàng không",
      image: "https://picsum.photos/seed/agv-robot/600/802"
    },
    {
      id: "4",
      title: "Bộ Sạc – Trạm Sạc",
      description: "Giải pháp sạc đồng bộ giúp tối ưu hiệu suất pin, rút ngắn thời gian chờ và phù hợp mọi môi trường.",
      application: "Trạm sạc tập trung, Depot",
      image: "https://picsum.photos/seed/charger-station/600/803"
    },
    {
      id: "5",
      title: "Hệ thống Pin ESS",
      description: "Lưu trữ năng lượng cho doanh nghiệp cần tăng tính chủ động, ổn định nguồn điện và tiết kiệm chi phí.",
      application: "Tòa nhà, Nhà xưởng, Data Center",
      image: "https://picsum.photos/seed/ess-storage/600/804"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-xl">
            <SectionLabel>DANH MỤC SẢN PHẨM</SectionLabel>
            <h2 className="text-5xl font-bold leading-tight">5 dòng giải pháp <br /> chủ lực của PKG</h2>
          </div>
          <Button variant="outline">Xem tất cả sản phẩm</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((p, i) => (
            <motion.div 
              key={p.id}
              whileHover={{ y: -10 }}
              className={`group relative overflow-hidden bg-industrial-gray ${i === 3 || i === 4 ? 'lg:col-span-1.5' : ''}`}
            >
              <div className="aspect-[3/4] relative overflow-hidden">
                <img 
                  src={p.image} 
                  alt={p.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-industrial-black via-black/20 to-transparent opacity-90" />
              </div>
              
              <div className="absolute inset-0 p-8 flex flex-col justify-end text-white">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-1 h-1 bg-brand-red rounded-full" />
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] opacity-80">{p.application}</span>
                </div>
                <h3 className="text-3xl font-bold mb-4 leading-tight group-hover:text-brand-red transition-colors">{p.title}</h3>
                <p className="text-sm text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300 mb-6 translate-y-4 group-hover:translate-y-0">
                  {p.description}
                </p>
                <button className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-brand-red border-b border-brand-red self-start pb-1">
                  Xem chi tiết <ChevronRight size={16} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const OEMSection = () => {
  return (
    <section className="py-24 bg-industrial-black text-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div>
          <SectionLabel>OEM / ODM SERVICES</SectionLabel>
          <h2 className="text-5xl font-bold leading-tight mb-8">
            Giải pháp tùy chỉnh <br /> theo yêu cầu kỹ thuật
          </h2>
          <p className="text-gray-400 text-lg mb-10">
            PKG Battery hỗ trợ doanh nghiệp và đối tác FDI trong việc xây dựng cấu hình pin lithium theo đặc thù ứng dụng thực tế. Từ thiết kế module đến tích hợp hệ thống phần mềm quản lý năng lượng.
          </p>
          
          <ul className="space-y-4 mb-12">
            {[
              "Tùy chỉnh kích thước & Form factor",
              "Cấu hình điện áp & Dung lượng theo thiết bị",
              "Tích hợp giao thức kết nối CAN, RS485, SMBus",
              "Sản xuất OEM theo tiêu chuẩn quốc tế",
              "Đồng hành R&D cùng đối tác kỹ thuật"
            ].map((item, idx) => (
              <li key={idx} className="flex items-center gap-3">
                <CheckCircle2 className="text-brand-red" size={20} />
                <span className="text-gray-300">{item}</span>
              </li>
            ))}
          </ul>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Button className="px-10">Gửi yêu cầu dự án</Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-black">Trao đổi OEM / ODM</Button>
          </div>
        </div>

        <div className="relative">
          <div className="bg-gradient-to-br from-brand-red/20 to-transparent p-1">
             <div className="bg-industrial-black p-8 border border-white/10">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/5 flex items-center justify-center">
                      <Terminal className="text-brand-red" size={24} />
                    </div>
                    <div>
                      <div className="text-xs font-mono text-gray-500 uppercase tracking-widest">SYSTEM STATUS</div>
                      <div className="text-sm font-bold text-white">BMS CORE V2.42 ACTIVE</div>
                    </div>
                  </div>
                  <div className="text-brand-red text-xs font-mono animate-pulse">● LIVE DIAGNOSTIC</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-8">
                  {[
                    { l: "Voltage Range", v: "24V - 80V DC" },
                    { l: "Max Capacity", v: "1000 Ah+" },
                    { l: "Cycle Life", v: ">4500 Cycles" },
                    { l: "IP Rating", v: "IP65 / IP67" },
                  ].map((stat, i) => (
                    <div key={i} className="p-4 bg-white/5 border border-white/5">
                      <div className="text-[10px] font-mono text-gray-500 uppercase mb-1">{stat.l}</div>
                      <div className="text-lg font-bold">{stat.v}</div>
                    </div>
                  ))}
                </div>

                <div className="h-40 w-full relative">
                  <img src="https://picsum.photos/seed/technical-drawing/500/300?grayscale" className="w-full h-full object-cover opacity-20" alt="Technical Drawing" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 flex items-center justify-center">
                     <Settings className="text-white/20 animate-spin-slow" size={64} />
                  </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const DealerSection = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-center">
          <div className="lg:col-span-5">
            <SectionLabel>MẠNG LƯỚI ĐẠI LÝ</SectionLabel>
            <h2 className="text-5xl font-bold leading-tight mb-8">
              Bao phủ rộng khắp <br /> thị trường Việt Nam
            </h2>
            <p className="text-gray-600 mb-8">
              PKG Battery hiện có mạng lưới 08 đại lý chiến lược và đang tiếp tục mở rộng để hỗ trợ doanh nghiệp nhanh nhất tại mọi khu vực công nghiệp trọng điểm.
            </p>
            
            <div className="space-y-4">
              {['Miền Bắc (Hà Nội, Hải Phòng, Bắc Ninh)', 'Miền Trung (Đà Nẵng, Bình Định)', 'Miền Nam (TP.HCM, Bình Dương, Đồng Nai)'].map((reg, i) => (
                <div key={i} className="flex items-center gap-3 p-4 border border-industrial-border">
                  <MapPin className="text-brand-red" size={20} />
                  <span className="font-medium text-industrial-black">{reg}</span>
                </div>
              ))}
            </div>

            <Button variant="secondary" className="mt-10 w-full lg:w-auto">Xem danh sách đại lý chi tiết</Button>
          </div>

          <div className="lg:col-span-7 bg-industrial-gray p-12 relative overflow-hidden aspect-square flex items-center justify-center">
            {/* Minimalist Map Placeholder */}
            <div className="relative w-full h-full border border-industrial-border bg-white flex items-center justify-center">
               <div className="text-industrial-black/10 font-bold text-9xl absolute select-none">VIETNAM</div>
               
               {/* Animated markers */}
               <div className="absolute top-[20%] left-[60%]">
                 <motion.div animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }} className="w-4 h-4 bg-brand-red rounded-full flex items-center justify-center">
                   <div className="w-2 h-2 bg-white rounded-full" />
                 </motion.div>
               </div>
               <div className="absolute top-[50%] left-[50%]">
                 <motion.div animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity, delay: 0.5 }} className="w-4 h-4 bg-brand-red rounded-full flex items-center justify-center">
                   <div className="w-2 h-2 bg-white rounded-full" />
                 </motion.div>
               </div>
               <div className="absolute bottom-[20%] left-[40%]">
                 <motion.div animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity, delay: 1 }} className="w-4 h-4 bg-brand-red rounded-full flex items-center justify-center">
                   <div className="w-2 h-2 bg-white rounded-full" />
                 </motion.div>
               </div>

               <div className="absolute bottom-8 right-8 bg-industrial-black p-4 text-white">
                  <div className="text-[10px] font-mono mb-2 uppercase tracking-widest text-brand-red">Active Clusters</div>
                  <div className="text-xl font-bold">HCMC - HANOI - DANANG</div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const IndustriesSection = () => {
  const industries = [
    { title: "Logistics & Kho vận", icon: <Truck size={32} />, img: "https://picsum.photos/seed/ind-log/600/400" },
    { title: "Nhà máy & Sản xuất", icon: <Factory size={32} />, img: "https://picsum.photos/seed/ind-man/600/401" },
    { title: "Tự động hóa / AGV", icon: <Cpu size={32} />, img: "https://picsum.photos/seed/ind-agv/600/402" },
    { title: "Resort & Sân Golf", icon: <MapPin size={32} />, img: "https://picsum.photos/seed/ind-res/600/403" },
    { title: "Năng lượng tái tạo", icon: <Zap size={32} />, img: "https://picsum.photos/seed/ind-ess/600/404" },
    { title: "Xe điện chuyên dụng", icon: <Settings size={32} />, img: "https://picsum.photos/seed/ind-spe/600/405" },
  ];

  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <SectionLabel>LĨNH VỰC PHỤC VỤ</SectionLabel>
          <h2 className="text-5xl font-bold">Giải pháp cho nhiều bối cảnh vận hành</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-1">
          {industries.map((ind, i) => (
            <motion.div 
              key={i}
              whileHover={{ scale: 0.98 }}
              className="relative aspect-[4/3] group cursor-pointer overflow-hidden"
            >
              <img 
                src={ind.img} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                alt={ind.title} 
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-industrial-black/40 group-hover:bg-brand-red/80 transition-colors duration-500" />
              <div className="absolute inset-0 p-8 flex flex-col justify-between border border-white/10 group-hover:border-white/40">
                <div className="text-white opacity-60 group-hover:opacity-100 transition-opacity">{ind.icon}</div>
                <div>
                   <h4 className="text-white text-2xl font-bold mb-2">{ind.title}</h4>
                   <div className="flex items-center gap-2 text-white/0 group-hover:text-white transition-all duration-300 translate-y-4 group-hover:translate-y-0">
                      <span className="text-xs font-mono uppercase tracking-widest">Khám phá giải pháp</span>
                      <ArrowRight size={14} />
                   </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const WhyChoosePKG = () => {
  const reasons = [
    { title: "Giải pháp thiết kế theo nhu cầu", desc: "Không chỉ bán sản phẩm, chúng tôi xây dựng cấu hình dựa trên bài toán vận hành thực tế của từng doanh nghiệp." },
    { title: "Tư duy kỹ thuật & Đồng hành", desc: "Đội ngũ kỹ sư giàu kinh nghiệm hỗ trợ từ khâu khảo sát đến triển khai và bảo trì trọn đời." },
    { title: "Tối ưu hiệu quả & Chi phí", desc: "Giúp doanh nghiệp giảm downtime, sạc nhanh hơn và kéo dài tuổi thọ hệ thống năng lượng." },
    { title: "Năng lực tùy chỉnh (OEM/ODM)", desc: "Khả năng sản xuất và tùy biến linh hoạt cho cả khách hàng Việt Nam, FDI và quốc tế." },
  ];

  return (
    <section className="py-24 bg-industrial-gray">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          <div className="lg:col-span-4">
            <SectionLabel>TẠI SAO CHỌN PKG</SectionLabel>
            <h2 className="text-5xl font-bold leading-tight mb-8">Giá trị cốt lõi <br /> của đối tác</h2>
            <div className="w-16 h-1 w-full bg-brand-red mb-8" />
            <p className="text-gray-500">
               PKG Battery cam kết mang lại sự an tâm tuyệt đối về năng lượng công nghiệp thông qua chất lượng chuẩn quốc tế và dịch vụ tận tâm.
            </p>
          </div>
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            {reasons.map((r, i) => (
              <div key={i} className="bg-white p-8 border-l border-industrial-border hover:border-brand-red transition-all duration-500">
                <div className="text-brand-red font-mono text-sm mb-6">0{i+1}</div>
                <h4 className="text-xl font-bold mb-4">{r.title}</h4>
                <p className="text-gray-500 text-sm leading-relaxed">{r.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const TrustSignalsExpanded = () => {
  return (
    <section className="py-0 bg-white">
      {/* 1. Stats Block */}
      <div className="bg-industrial-black text-white py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none">
           <img src="https://picsum.photos/seed/tech-grid/1000/600?grayscale" className="w-full h-full object-cover" alt="Background" referrerPolicy="no-referrer" />
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center md:text-left">
            {[
              { v: "10+", l: "Năm kinh nghiệm chuyên sâu" },
              { v: "500+", l: "Dự án & Khách hàng doanh nghiệp" },
              { v: "08+", l: "Đại lý phân phối toàn quốc" },
              { v: "24/7", l: "Hỗ trợ & Đồng hành kỹ thuật" },
            ].map((s, i) => (
              <div key={i} className="group">
                <div className="text-6xl md:text-7xl font-display font-bold text-brand-red mb-4 group-hover:scale-110 transition-transform duration-500">
                   {s.v}
                </div>
                <div className="text-xs font-mono uppercase tracking-[0.2em] text-gray-400">
                   {s.l}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Certs & Gallery */}
      <div className="py-24 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
          <div className="lg:col-span-4">
             <SectionLabel>CHỨNG CHỈ & TIÊU CHUẨN</SectionLabel>
             <h3 className="text-4xl font-bold mb-8">Năng lực khẳng định qua các tiêu chuẩn</h3>
             <div className="grid grid-cols-2 gap-4">
                {[
                  { name: "ISO 9001:2015", img: "https://picsum.photos/seed/cert1/300/400?grayscale" },
                  { name: "IEC 62619", img: "https://picsum.photos/seed/cert2/300/400?grayscale" },
                  { name: "CE Compliance", img: "https://picsum.photos/seed/cert3/300/400?grayscale" },
                  { name: "Test Report V6", img: "https://picsum.photos/seed/cert4/300/400?grayscale" },
                ].map((c, i) => (
                  <div key={i} className="group relative aspect-[3/4] bg-industrial-gray overflow-hidden border border-industrial-border cursor-pointer">
                     <img src={c.img} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" alt={c.name} referrerPolicy="no-referrer" />
                     <div className="absolute inset-x-0 bottom-0 p-3 bg-industrial-black/80 text-white text-[10px] font-mono translate-y-full group-hover:translate-y-0 transition-transform">
                        {c.name}
                     </div>
                  </div>
                ))}
             </div>
             <Button variant="outline" className="mt-8 w-full">Xem Profile năng lực PDF</Button>
          </div>
          
          <div className="lg:col-span-8">
            <SectionLabel>HÌNH ẢNH THỰC TẾ</SectionLabel>
            <h3 className="text-4xl font-bold mb-8">Năng lực sản xuất và vận hành</h3>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-1">
               <div className="aspect-square relative overflow-hidden group">
                  <img src="https://picsum.photos/seed/real1/500/500" alt="PKG" className="w-full h-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-brand-red/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-6 text-center">
                    <span className="text-white font-bold text-xs">TRUNG TÂM KỸ THUẬT</span>
                  </div>
               </div>
               <div className="aspect-square relative overflow-hidden group">
                  <img src="https://picsum.photos/seed/real2/500/500" alt="PKG" className="w-full h-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-brand-red/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-6 text-center">
                    <span className="text-white font-bold text-xs">HỆ THỐNG KIỂM TRA</span>
                  </div>
               </div>
               <div className="aspect-square relative overflow-hidden group">
                  <img src="https://picsum.photos/seed/real3/500/500" alt="PKG" className="w-full h-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-brand-red/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-6 text-center">
                    <span className="text-white font-bold text-xs">KHO VẬN HIỆN ĐẠI</span>
                  </div>
               </div>
               <div className="aspect-square relative overflow-hidden group">
                  <img src="https://picsum.photos/seed/real4/500/500" alt="PKG" className="w-full h-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-brand-red/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-6 text-center">
                    <span className="text-white font-bold text-xs">ĐỘI NGŨ KỸ SƯ</span>
                  </div>
               </div>
               <div className="aspect-square relative overflow-hidden group">
                  <img src="https://picsum.photos/seed/real5/500/500" alt="PKG" className="w-full h-full object-cover transition-transform group-hover:scale-110" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-brand-red/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-6 text-center">
                    <span className="text-white font-bold text-xs">TRIỂN KHAI THỰC TẾ</span>
                  </div>
               </div>
               <div className="aspect-square bg-brand-red flex items-center justify-center p-8 text-center group cursor-pointer overflow-hidden relative">
                  <motion.div 
                    whileHover={{ scale: 1.1 }}
                    className="relative z-10"
                  >
                    <span className="text-white font-bold text-lg leading-tight uppercase tracking-widest">Xem thêm <br/> dự án tiêu biểu</span>
                    <ArrowRight className="mx-auto mt-4 text-white" />
                  </motion.div>
                  <div className="absolute top-0 right-0 p-4 opacity-20">
                     <Factory size={100} className="text-white" />
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const CaseStudySection = () => {
  return (
    <section className="py-24 bg-industrial-gray">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <SectionLabel>APPLICATION PROOF</SectionLabel>
          <h2 className="text-5xl font-bold">Các mô hình ứng dụng tiêu biểu</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
           {[
             { title: "Tối ưu hóa 3 ca vận hành cho Warehouse FDI", desc: "Chuyển đổi Ắc quy chì sang Lithium PKG 80V/500Ah, giảm 70% thời gian sạc.", img: "https://picsum.photos/seed/case1/800/400" },
             { title: "Hệ thống trạm sạc tập trung cho Resort Buggy", desc: "Triển khai trạm sạc nhanh tích hợp BMS giám sát từ xa cho 50 xe Buggy.", img: "https://picsum.photos/seed/case2/800/400" },
           ].map((c, i) => (
             <div key={i} className="bg-white border-b-4 border-brand-red group overflow-hidden">
                <div className="aspect-[2/1] overflow-hidden">
                  <img src={c.img} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={c.title} referrerPolicy="no-referrer" />
                </div>
                <div className="p-8">
                   <h4 className="text-2xl font-bold mb-4">{c.title}</h4>
                   <p className="text-gray-500 mb-6">{c.desc}</p>
                   <Button variant="ghost" className="px-0">Xem chi tiết Case Study <ChevronRight size={16}/></Button>
                </div>
             </div>
           ))}
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => {
  return (
    <section className="py-24 bg-industrial-black text-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div>
            <SectionLabel>LIÊN HỆ TƯ VẤN</SectionLabel>
            <h2 className="text-6xl font-bold leading-tight mb-8">
              Bắt đầu hành trình <br /> tối ưu năng lượng
            </h2>
            <p className="text-gray-400 text-lg mb-12 max-w-md">
              Trao đổi với đội ngũ PKG Battery để được đánh giá nhu cầu vận hành, đề xuất cấu hình phù hợp và tối ưu chi phí dài hạn.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center text-brand-red">
                   <Phone size={20} />
                </div>
                <div>
                   <div className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">Hotline Kỹ thuật</div>
                   <div className="text-lg font-bold">1900 XXXX</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center text-brand-red">
                   <Mail size={20} />
                </div>
                <div>
                   <div className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">Email Project</div>
                   <div className="text-lg font-bold">contact@pkgbattery.vn</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-12 text-industrial-black">
            <h3 className="text-2xl font-bold mb-8">Gửi yêu cầu giải pháp</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-gray-400">Họ và tên</label>
                  <input type="text" className="w-full border-b border-industrial-border py-2 focus:border-brand-red outline-none transition-colors" placeholder="Nguyễn Văn A" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-gray-400">Công ty</label>
                  <input type="text" className="w-full border-b border-industrial-border py-2 focus:border-brand-red outline-none transition-colors" placeholder="PKG Industrial" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-gray-400">Số điện thoại</label>
                  <input type="tel" className="w-full border-b border-industrial-border py-2 focus:border-brand-red outline-none transition-colors" placeholder="+84 ..." />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-gray-400">Lĩnh vực ứng dụng</label>
                  <select className="w-full border-b border-industrial-border py-2 focus:border-brand-red outline-none transition-colors bg-white">
                    <option>Xe nâng điện</option>
                    <option>AGV / Robot</option>
                    <option>Xe du lịch / Buggy</option>
                    <option>Lưu trữ ESS</option>
                    <option>Khác</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase tracking-widest text-gray-400">Nội dung chi tiết yêu cầu</label>
                <textarea rows={4} className="w-full border border-industrial-border p-4 focus:border-brand-red outline-none transition-colors" placeholder="Mô tả bài toán năng lượng hoặc yêu cầu OEM của bạn..." />
              </div>
              <Button className="w-full py-4 text-lg">Gửi thông tin tư vấn <ArrowRight size={20} /></Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-industrial-gray pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-brand-red flex items-center justify-center">
                <span className="text-white font-bold text-xl">P</span>
              </div>
              <span className="text-2xl font-display font-bold tracking-tighter">PKG<span className="text-brand-red">BATTERY</span></span>
            </div>
            <p className="text-sm text-gray-500 leading-relaxed mb-6">
              Đơn vị cung cấp giải pháp pin lithium công nghiệp, bộ sạc và hệ thống lưu trữ năng lượng chuyên dụng cho doanh nghiệp.
            </p>
            <div className="flex gap-4">
              <div className="w-8 h-8 flex items-center justify-center border border-industrial-border text-gray-400 hover:text-brand-red transition-colors cursor-pointer"><Globe size={18} /></div>
              <div className="w-8 h-8 flex items-center justify-center border border-industrial-border text-gray-400 hover:text-brand-red transition-colors cursor-pointer"><Mail size={18} /></div>
            </div>
          </div>

          <div>
             <h4 className="text-sm font-bold uppercase tracking-widest mb-6">Danh mục</h4>
             <ul className="space-y-4 text-sm text-gray-500">
               <li><a href="#" className="hover:text-brand-red transition-colors">Giải pháp Xe nâng</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Giải pháp AGV/Robot</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Giải pháp Xe du lịch</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Trạm sạc thông minh</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Lưu trữ ESS</a></li>
             </ul>
          </div>

          <div>
             <h4 className="text-sm font-bold uppercase tracking-widest mb-6">Về PKG</h4>
             <ul className="space-y-4 text-sm text-gray-500">
               <li><a href="#" className="hover:text-brand-red transition-colors">Năng lực doanh nghiệp</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Dịch vụ OEM / ODM</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Kiến thức kỹ thuật</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Hệ thống đại lý</a></li>
               <li><a href="#" className="hover:text-brand-red transition-colors">Tuyển dụng</a></li>
             </ul>
          </div>

          <div>
             <h4 className="text-sm font-bold uppercase tracking-widest mb-6">Văn phòng chính</h4>
             <div className="text-sm text-gray-500 space-y-4">
                <p>Số XX, Khu công nghiệp YY, <br/> Tỉnh ZZ, Việt Nam</p>
                <div className="flex items-center gap-2">
                   <Phone size={14} className="text-brand-red" />
                   <span>+84 1900 XXXX</span>
                </div>
                <div className="flex items-center gap-2">
                   <Mail size={14} className="text-brand-red" />
                   <span>info@pkgbattery.vn</span>
                </div>
             </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-industrial-border flex flex-col md:flex-row justify-between items-center gap-4">
           <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">© 2024 PKG BATTERY CO., LTD. ALL RIGHTS RESERVED.</span>
           <div className="flex gap-6 text-[10px] font-mono text-gray-400 uppercase tracking-widest">
              <a href="#" className="hover:text-brand-red transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-brand-red transition-colors">Terms of Service</a>
           </div>
        </div>
      </div>
    </footer>
  );
};

const NewsSection = () => {
  const news = [
    { cat: "KIẾN THỨC", title: "So sánh Pin Lithium và Ắc quy Chì: Giải bài toán TCO kho vận", date: "24.03.2024" },
    { cat: "ỨNG DỤNG", title: "Tối ưu hóa hành trình cho xe điện du lịch tại các resort cao cấp", date: "15.03.2024" },
    { cat: "TIN TỨC", title: "PKG Battery ra mắt dòng sạc nhanh thông minh cho AGV công nghiệp", date: "02.03.2024" },
  ];

  return (
    <section className="py-24 bg-industrial-gray">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-end mb-16">
          <div>
            <SectionLabel>TIN TỨC & KIẾN THỨC</SectionLabel>
            <h2 className="text-5xl font-bold">Cập nhật từ chuyên gia</h2>
          </div>
          <button className="text-sm font-bold uppercase tracking-widest border-b-2 border-industrial-black pb-1">Xem tất cả bài viết</button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {news.map((n, i) => (
            <div key={i} className="bg-white p-10 group hover:bg-brand-red transition-all duration-500 overflow-hidden relative">
              <div className="text-[10px] font-mono mb-4 text-brand-red group-hover:text-white/80 transition-colors uppercase tracking-[0.2em] font-bold">{n.cat}</div>
              <h4 className="text-2xl font-bold mb-8 group-hover:text-white transition-colors leading-tight">
                {n.title}
              </h4>
              <div className="flex items-center justify-between mt-auto">
                <span className="text-xs text-gray-400 group-hover:text-white/60 transition-colors uppercase font-mono tracking-widest">{n.date}</span>
                <div className="w-10 h-10 border border-industrial-border flex items-center justify-center group-hover:border-white transition-colors group-hover:text-white translate-x-12 group-hover:translate-x-0 transition-transform duration-500">
                  <ArrowRight size={16} />
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 text-industrial-gray/10 text-9xl font-bold group-hover:text-white/5">0{i+1}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --- Main Page ---

export default function App() {
  return (
    <main className="selection:bg-brand-red selection:text-white">
      <Navbar />
      <Hero />
      <TrustStrip />
      <PainPointSection />
      <AboutSection />
      <EcosystemSection />
      <ProductsSection />
      <WhyChoosePKG />
      <IndustriesSection />
      <OEMSection />
      <DealerSection />
      <TrustSignalsExpanded />
      <CaseStudySection />
      <NewsSection />
      <ContactSection />
      <Footer />

      {/* Floating Action Button for Contact */}
      <motion.div 
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-6 right-6 z-[100] hidden lg:block"
      >
        <button className="w-16 h-16 bg-brand-red text-white flex items-center justify-center rounded-full shadow-2xl hover:scale-110 transition-transform active:scale-95 group relative">
          <MessageSquare />
          <div className="absolute right-full mr-4 bg-industrial-black text-white px-4 py-2 text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            Tình yêu thương hiệu PKG
          </div>
        </button>
      </motion.div>
    </main>
  );
}
