import { motion } from "motion/react";
import { ArrowRight, CheckCircle2, ShieldCheck, Zap } from "lucide-react";

const Hero = () => {
  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
  };

  const staggerContainer = {
    animate: { transition: { staggerChildren: 0.1 } }
  };

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden bg-white pt-20">
      {/* Background Layer: Subtle Pattern & Image */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 dot-pattern opacity-40" />
        <motion.div 
          className="absolute right-0 top-0 w-1/2 h-full opacity-[0.03] grayscale"
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 0.03, scale: 1 }}
          transition={{ duration: 2 }}
        >
          <img 
            src="https://picsum.photos/seed/pkg-factory-bg/1920/1080?grayscale" 
            alt="" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>

      <div className="container mx-auto px-6 lg:px-12 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Side: Brand Content */}
          <motion.div 
            className="lg:col-span-6 xl:col-span-5"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            <motion.div 
              variants={fadeInUp}
              className="flex items-center gap-3 mb-8"
            >
              <div className="w-12 h-[2px] bg-pkg-red" />
              <span className="text-xs font-bold tracking-[0.2em] text-graphite uppercase">
                PKG BATTERY
              </span>
            </motion.div>

            <motion.h1 
              variants={fadeInUp}
              className="text-4xl md:text-5xl xl:text-6xl font-display font-extrabold text-graphite leading-[1.1] mb-6"
            >
              TIÊN PHONG GIẢI PHÁP <br />
              <span className="text-pkg-red">NĂNG LƯỢNG LITHIUM</span> <br />
              TẠI VIỆT NAM
            </motion.h1>

            <motion.p 
              variants={fadeInUp}
              className="text-lg text-slate-600 font-medium leading-relaxed mb-4 max-w-lg"
            >
              PKG Battery phát triển năng lực nghiên cứu, sản xuất và triển khai các giải pháp năng lượng Lithium phục vụ doanh nghiệp trong công nghiệp, logistics và hạ tầng vận hành hiện đại.
            </motion.p>

            <motion.p 
              variants={fadeInUp}
              className="text-base text-slate-500 leading-relaxed mb-10 max-w-lg"
            >
              Chúng tôi xây dựng giá trị từ công nghệ, đội ngũ kỹ thuật và cam kết đồng hành dài hạn, nhằm giúp doanh nghiệp nâng cao hiệu suất vận hành, tăng độ an toàn và sẵn sàng cho giai đoạn tăng trưởng mới.
            </motion.p>

            <motion.div 
              variants={fadeInUp}
              className="flex flex-col sm:flex-row items-center gap-4 mb-12"
            >
              <button className="w-full sm:w-auto px-8 py-4 bg-graphite text-white font-bold rounded-sm border border-graphite hover:bg-white hover:text-graphite transition-all duration-300 flex items-center justify-center gap-2 group">
                Khám phá doanh nghiệp
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="w-full sm:w-auto px-8 py-4 bg-white text-graphite font-bold rounded-sm border border-slate-200 hover:border-pkg-red transition-all duration-300">
                Xem năng lực triển khai
              </button>
            </motion.div>

            {/* Trust Bar */}
            <motion.div 
              variants={fadeInUp}
              className="flex flex-wrap items-center gap-x-8 gap-y-4 pt-8 border-t border-slate-100"
            >
              <div className="flex items-center gap-2 text-slate-400 group cursor-default">
                <ShieldCheck className="w-5 h-5 text-slate-300 group-hover:text-pkg-red transition-colors" />
                <span className="text-[11px] font-bold tracking-widest uppercase">IEC 62619</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 group cursor-default">
                <Zap className="w-5 h-5 text-slate-300 group-hover:text-pkg-red transition-colors" />
                <span className="text-[11px] font-bold tracking-widest uppercase">UN38.3</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 group cursor-default">
                <CheckCircle2 className="w-5 h-5 text-slate-300 group-hover:text-pkg-red transition-colors" />
                <span className="text-[11px] font-bold tracking-widest uppercase">ISO QUALITY</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Side: Layered Visual Composition */}
          <div className="lg:col-span-6 xl:col-span-7 relative">
            <div className="relative h-[600px] xl:h-[700px] w-full flex items-center justify-center">
              
              {/* Main Image: Technical Staff */}
              <motion.div 
                className="absolute z-20 w-4/5 h-[70%] rounded-sm overflow-hidden shadow-2xl"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, delay: 0.4 }}
              >
                <img 
                  src="https://picsum.photos/seed/pkg-tech/1200/900" 
                  alt="PKG Technical Staff" 
                  className="w-full h-full object-cover grayscale-[0.2] hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-graphite/40 to-transparent opacity-60" />
              </motion.div>

              {/* Supporting Image 1: Quality Inspection */}
              <motion.div 
                className="absolute z-30 -bottom-4 -left-4 md:-left-12 w-[240px] md:w-[320px] aspect-[4/3] rounded-sm overflow-hidden shadow-xl border-4 border-white"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.6 }}
              >
                <img 
                  src="https://picsum.photos/seed/pkg-qa-check/800/600" 
                  alt="Quality Control" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Supporting Image 2: Tools / Module */}
              <motion.div 
                className="absolute z-30 -top-8 -right-4 w-[180px] md:w-[240px] aspect-square rounded-sm overflow-hidden shadow-xl border-4 border-white"
                initial={{ opacity: 0, y: -30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.8 }}
              >
                <img 
                  src="https://picsum.photos/seed/pkg-module/600/600" 
                  alt="Technical Module Detail" 
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Technical Graphics / Background Overlays */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none opacity-20">
                <div className="absolute top-0 right-0 w-32 h-32 border-t-2 border-r-2 border-slate-200" />
                <div className="absolute bottom-0 left-0 w-32 h-32 border-b-2 border-l-2 border-slate-200" />
                
                {/* Vertical Text - Industrial Aesthetic */}
                <span className="absolute -left-12 top-1/2 -translate-y-1/2 vertical-text text-[10px] font-bold tracking-[0.5em] text-slate-300 uppercase whitespace-nowrap">
                  PRECISION ENGINEERING • INDUSTRIAL SOLUTIONS
                </span>
                
                {/* Graphic Element: Red Accent Square */}
                <motion.div 
                  className="absolute bottom-1/4 -right-8 w-16 h-16 bg-pkg-red/10 border border-pkg-red/30 backdrop-blur-sm"
                  animate={{ rotate: [0, 90, 180, 270, 360] }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                />
              </div>

              {/* Subtle Floating Data Pattern */}
              <motion.div 
                className="absolute -top-12 left-20 z-10 w-40 h-40 border border-slate-100 rounded-full"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              />
            </div>
          </div>

        </div>
      </div>

      {/* Corporate Trust Line / Footer Cue */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 opacity-50">
        <span className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">
          Đối tác năng lượng cho môi trường vận hành hiện đại
        </span>
        <motion.div 
          className="w-[1px] h-12 bg-gradient-to-b from-slate-200 to-transparent"
          animate={{ height: [48, 24, 48] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>

      <style>{`
        .vertical-text {
          writing-mode: vertical-rl;
          transform: rotate(180deg);
        }
      `}</style>
    </section>
  );
};

export default Hero;
