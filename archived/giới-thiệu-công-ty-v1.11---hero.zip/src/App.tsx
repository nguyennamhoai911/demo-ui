/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Hero from './components/Hero';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="min-h-screen font-sans selection:bg-pkg-red/10 selection:text-pkg-red">
      {/* Navigation */}
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="fixed top-0 left-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-slate-100"
      >
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-pkg-red flex items-center justify-center rounded-sm">
              <span className="text-white font-bold text-lg">P</span>
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-graphite group cursor-pointer">
              PKG <span className="group-hover:text-pkg-red transition-colors">BATTERY</span>
            </span>
          </div>
          
          <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-bold text-slate-500 hover:text-pkg-red transition-colors uppercase tracking-widest">Trang chủ</a>
            <a href="#" className="text-sm font-bold text-slate-500 hover:text-pkg-red transition-colors uppercase tracking-widest">Doanh nghiệp</a>
            <a href="#" className="text-sm font-bold text-slate-500 hover:text-pkg-red transition-colors uppercase tracking-widest">Giải pháp</a>
            <a href="#" className="text-sm font-bold text-slate-500 hover:text-pkg-red transition-colors uppercase tracking-widest">Dự án</a>
            <a href="#" className="text-sm font-bold text-slate-500 hover:text-pkg-red transition-colors uppercase tracking-widest">Liên hệ</a>
          </nav>

          <button className="px-6 py-2 border-2 border-graphite text-graphite font-bold text-xs uppercase tracking-widest hover:bg-graphite hover:text-white transition-all">
            Yêu cầu tư vấn
          </button>
        </div>
      </motion.header>

      <main>
        <Hero />
      </main>

      {/* Basic Footer placeholder for completeness */}
      <footer className="bg-slate-50 py-20 border-t border-slate-100">
        <div className="container mx-auto px-6 text-center">
          <p className="text-sm text-slate-400 font-medium tracking-widest uppercase mb-4">
            © 2026 PKG BATTERY CO., LTD. ALL RIGHTS RESERVED.
          </p>
          <div className="flex justify-center gap-8 text-xs font-bold text-slate-300">
            <a href="#" className="hover:text-pkg-red transition-colors">PRIVACY POLICY</a>
            <a href="#" className="hover:text-pkg-red transition-colors">TERMS OF SERVICE</a>
            <a href="#" className="hover:text-pkg-red transition-colors">LEGAL INFO</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
