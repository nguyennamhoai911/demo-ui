import { motion } from "motion/react";
import { ArrowRight, Box, ShieldCheck, Zap } from "lucide-react";

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen pt-20 overflow-hidden bg-soft-white flex">
      {/* Background Accents - High Density style */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-[45%] h-full bg-linear-to-br from-transparent to-silver/50 z-0" />
      </div>

      <div className="flex-1 container mx-auto relative z-10 flex flex-col lg:flex-row">
        {/* Left Content */}
        <div className="flex-[1.2] flex flex-col justify-center py-20 pl-[60px] pr-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="text-pkg-red text-[12px] font-extrabold tracking-[0.4em] mb-4 uppercase">
              PKG BATTERY
            </div>

            <h1 className="text-[54px] font-black text-graphite leading-[1.05] mb-8 max-w-[620px]">
              ĐỒNG HÀNH CÙNG <br />
              <span className="relative">
                TƯƠNG LAI NĂNG LƯỢNG
                <motion.span 
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ delay: 1, duration: 1.5, ease: "easeInOut" }}
                  className="absolute bottom-1 left-0 h-[8px] bg-pkg-red/10 -z-10"
                />
              </span> <br />
              CÔNG NGHIỆP VIỆT NAM
            </h1>

            <div className="space-y-6 mb-12 max-w-[520px]">
              <p className="text-[18px] leading-[1.6] text-graphite font-bold opacity-90">
                PKG Battery phát triển năng lực nghiên cứu, sản xuất và triển khai các giải pháp năng lượng Lithium phục vụ doanh nghiệp trong công nghiệp, logistics và hạ tầng vận hành hiện đại.
              </p>
              <p className="text-[15px] leading-[1.7] text-graphite opacity-60">
                Chúng tôi xây dựng giá trị từ công nghệ, đội ngũ kỹ thuật và cam kết đồng hành dài hạn, nhằm giúp doanh nghiệp nâng cao hiệu suất vận hành, tăng độ an toàn và sẵn sàng cho giai đoạn tăng trưởng mới.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-5 mb-14">
              <button className="group relative bg-graphite text-white px-10 py-4 text-[14px] font-bold uppercase tracking-[0.1em] rounded-[2px] transition-all duration-500 hover:bg-pkg-red hover:shadow-[0_10px_20px_rgba(214,31,38,0.2)] flex items-center gap-3">
                <span>Khám phá doanh nghiệp</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
              
              <button className="px-10 py-4 border border-silver text-graphite text-[14px] font-bold uppercase tracking-[0.1em] rounded-[2px] hover:border-graphite transition-all">
                Xem năng lực triển khai
              </button>
            </div>

            {/* Trust Bar */}
            <div className="pt-6 border-t border-silver flex items-center gap-10">
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-[0.15em] font-bold opacity-30 mb-1">Standard Compliance</span>
                <div className="flex items-center gap-3">
                  <span className="text-[13px] font-bold text-graphite/70">IEC 62619</span>
                  <div className="w-1 h-1 rounded-full bg-silver"></div>
                  <span className="text-[13px] font-bold text-graphite/70">UN38.3</span>
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-[0.15em] font-bold opacity-30 mb-1">Quality Management</span>
                <span className="text-[13px] font-bold text-graphite/70">ISO Quality Standard</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right Visuals */}
        <div className="flex-1 relative h-screen lg:h-auto overflow-hidden">
          <div className="absolute inset-y-[5%] right-0 w-full lg:w-[115%] bg-white rounded-l-[10px] shadow-[-30px_30px_80px_rgba(0,0,0,0.04)] overflow-hidden flex items-center justify-center">
            
            {/* Soft Ambient Background */}
            <div className="absolute inset-0 bg-linear-to-tr from-soft-white via-white to-silver/10" />
            
            {/* Tech Grid Background */}
            <div className="absolute inset-0 opacity-[0.1] bg-[linear-gradient(var(--color-silver)_1px,transparent_1px),linear-gradient(90deg,var(--color-silver)_1px,transparent_1px)] bg-[size:50px_50px]" />
            
            {/* Layered Composition */}
            <div className="relative w-full h-full flex items-center justify-center p-12">
              
              {/* Secondary Layer: R&D Environment */}
              <motion.div 
                initial={{ opacity: 0, scale: 1.1, x: 20 }}
                animate={{ opacity: 0.4, scale: 1, x: 0 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                className="absolute top-[10%] left-[10%] w-[50%] aspect-video rounded-[4px] overflow-hidden grayscale brightness-110"
              >
                <img 
                  src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800" 
                  alt="Team Discussion" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Main Enterprise Image: Professional staff working */}
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.2, delay: 0.4, ease: "easeOut" }}
                className="relative z-20 w-[85%] aspect-[4/5] bg-silver p-[1px] shadow-2xl"
              >
                <div className="w-full h-full bg-white relative overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1600" 
                    alt="Technical Specialist" 
                    className="w-full h-full object-cover grayscale-[15%] brightness-105 hover:grayscale-0 transition-all duration-1000"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-graphite/40 via-transparent to-transparent opacity-60" />
                  
                  {/* Subtle Technical Overlay */}
                  <div className="absolute inset-0 border-[30px] border-white/10 pointer-events-none" />
                </div>
              </motion.div>

              {/* Floating Mini Layer: Quality Inspection */}
              <motion.div 
                initial={{ opacity: 0, x: -40 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, delay: 0.8 }}
                className="absolute top-[45%] -left-[5%] z-30 w-[40%] aspect-square bg-white p-2 shadow-2xl border border-silver"
              >
                <img 
                  src="https://images.unsplash.com/photo-1581092580497-e03e59c9ed4a?auto=format&fit=crop&q=80&w=800" 
                  alt="Quality Testing" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              {/* Data Overlay Graphic */}
              <div className="absolute right-10 bottom-20 z-30 flex flex-col items-end gap-2 text-right">
                <div className="w-24 h-[1px] bg-pkg-red" />
                <span className="text-[10px] font-bold text-graphite/40 uppercase tracking-[0.3em]">Smart Energy Matrix</span>
                <span className="text-[20px] font-thin text-graphite">Operational Efficiency</span>
              </div>

              {/* Index Number */}
              <div className="absolute left-8 top-8 text-[140px] font-black text-silver opacity-10 leading-none select-none">
                01
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Scroll indicator */}
      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-20"
      >
        <span className="text-[8px] font-bold uppercase tracking-[0.4em] text-graphite/20">Scroll</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-graphite/20 to-transparent"></div>
      </motion.div>
    </section>
  );
}
