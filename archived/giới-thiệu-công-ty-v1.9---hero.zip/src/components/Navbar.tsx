import { motion } from "motion/react";

export default function Navbar() {
  return (
    <motion.nav 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-[60px] h-20 bg-white border-b border-silver"
    >
      <div className="flex items-center">
        <span className="font-black text-2xl tracking-tighter text-graphite uppercase">
          PKG<span className="text-pkg-red">BATTERY</span>
        </span>
      </div>

      <div className="hidden md:flex items-center gap-8">
        {["Doanh nghiệp", "Giải pháp", "Dự án", "Liên hệ"].map((item) => (
          <a 
            key={item} 
            href="#" 
            className="text-[13px] uppercase tracking-[0.05em] font-bold text-graphite opacity-70 hover:opacity-100 transition-opacity duration-300"
          >
            {item}
          </a>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <button className="bg-graphite text-white text-[14px] uppercase tracking-[0.05em] font-bold px-8 py-3 rounded-[2px] transition-all hover:bg-pkg-red">
          Hợp tác
        </button>
      </div>
    </motion.nav>
  );
}
