import { Navigation } from './components/sections/Navigation';
import { Hero } from './components/sections/Hero';
import { TrustedBy } from './components/sections/TrustedBy';
import { PainPoint } from './components/sections/PainPoint';
import { About } from './components/sections/About';
import { Solutions } from './components/sections/Solutions';
import { Products } from './components/sections/Products';
import { OEMODM } from './components/sections/OEMODM';
import { Industries } from './components/sections/Industries';
import { WhyChoose } from './components/sections/WhyChoose';
import { CapabilityTheater } from './components/sections/CapabilityTheater';
import { Process } from './components/sections/Process';
import { DealerMap } from './components/sections/DealerMap';
import { News } from './components/sections/News';
import { CaseStudy } from './components/sections/CaseStudy';
import { Contact } from './components/sections/Contact';
import { Footer } from './components/sections/Footer';

export default function App() {
  return (
    <div className="antialiased min-h-screen bg-white">
      <Navigation />
      
      <main>
        {/* Layered Content Sections following 75-15-10 Rhythm */}
        <Hero />                 {/* Section 02 - Home/Hero */}
        <TrustedBy />            {/* Section 03 - Social Proof */}
        <PainPoint />            {/* Section 04 - Relevance (Dark) */}
        <About />                {/* Section 05 - Brand depth */}
        <Solutions />            {/* Section 06 - Ecosystem */}
        <Products />             {/* Section 07 - Core portfolio (5 Groups) */}
        <OEMODM />               {/* Section 08 - Power (Red Statement) */}
        <Industries />           {/* Section 09 - Contextual relevance */}
        <WhyChoose />            {/* Section 10 - USP logic */}
        <CapabilityTheater />    {/* Section 11 - Mass Proof Experience */}
        <Process />              {/* Section 12 - Order & Reliability */}
        <DealerMap />            {/* Section 13 - Network & Coverage */}
        <News />                 {/* Section 14 - Technical SEO & Authority */}
        <CaseStudy />            {/* Section 15 - Success Proof */}
        <Contact />              {/* Section 16 - Ultimate Conversion */}
      </main>

      <Footer />                 {/* Section 17 - Stability */}
    </div>
  );
}
