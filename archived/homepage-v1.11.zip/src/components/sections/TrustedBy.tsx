import { motion } from "motion/react";
import { Container } from "../UI";

export const TrustedBy = () => {
  const logos = [
    "LOGISTICS", "WAREHOUSE", "AUTOMOTIVE", "MANUFACTURING", "FDI PARTNER", "INDUSTRIAL", "ENERGY"
  ];

  return (
    <section className="py-24 bg-white border-b border-industrial-gray overflow-hidden">
      <Container>
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/4 shrink-0">
            <h5 className="text-[10px] font-mono tracking-[0.4em] uppercase text-gray-400 font-bold mb-4">Trusted By</h5>
            <p className="text-sm font-medium text-gray-600 leading-relaxed">
              Đồng hành cùng doanh nghiệp trong nhiều môi trường vận hành trọng yếu tại Việt Nam và khu vực.
            </p>
          </div>

          <div className="lg:w-3/4 overflow-hidden relative">
            {/* Fade Masks */}
            <div className="absolute inset-y-0 left-0 w-20 bg-gradient-to-r from-white to-transparent z-10" />
            <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-white to-transparent z-10" />

            <div className="flex flex-col gap-12">
              <motion.div 
                animate={{ x: [0, -1000] }}
                transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                className="flex items-center gap-24 whitespace-nowrap"
              >
                {[...logos, ...logos].map((logo, idx) => (
                  <div key={idx} className="flex items-center gap-4 opacity-30 hover:opacity-100 transition-all cursor-pointer group">
                    <div className="w-12 h-12 bg-industrial-gray rounded-sm flex items-center justify-center font-black italic text-gray-400 group-hover:bg-brand-red group-hover:text-white group-hover:border-transparent transition-all">P</div>
                    <span className="text-xl font-black tracking-tighter text-gray-900">{logo}</span>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
