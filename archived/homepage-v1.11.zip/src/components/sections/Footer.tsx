import { Container } from "../UI";
import { Globe, Mail, Phone, MapPin } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-deep-black text-white pt-32 pb-16 overflow-hidden">
      <Container>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-20 mb-32 border-b border-white/5 pb-32">
          <div className="lg:col-span-1">
            <a href="/" className="flex items-center gap-3 group mb-12">
              <div className="w-10 h-10 bg-brand-red flex items-center justify-center font-bold text-white italic">PKG</div>
              <div className="flex flex-col">
                <span className="text-xl font-black tracking-tighter leading-none text-white">BATTERY</span>
                <span className="text-[8px] font-mono tracking-[0.3em] font-medium text-white/40 uppercase leading-none mt-1">Industrial Energy</span>
              </div>
            </a>
            <p className="text-white/30 text-sm leading-relaxed max-w-xs mb-10 font-light">
              PKG Battery – Đối tác năng lượng lithium công nghiệp hàng đầu, 
              cam kết nâng tầm hiệu quả vận hành doanh nghiệp bằng công nghệ hiện đại 
              và tư duy giải pháp thực tế.
            </p>
            <div className="flex gap-4">
              {[Globe, Mail, Phone].map((Icon, idx) => (
                <div key={idx} className="w-10 h-10 border border-white/10 rounded-full flex items-center justify-center text-white/40 hover:text-brand-red hover:border-brand-red transition-all cursor-pointer">
                  <Icon size={16} />
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xs font-mono font-bold text-brand-red uppercase tracking-[0.3em] mb-12">Hệ sinh thái</h4>
            <ul className="space-y-5 text-white/40 text-sm font-light">
              <li className="hover:text-white transition-colors cursor-pointer">Giải pháp Pin Xe Nâng</li>
              <li className="hover:text-white transition-colors cursor-pointer">Pin cho Xe Điện Du Lịch</li>
              <li className="hover:text-white transition-colors cursor-pointer">Hệ thống AGV / Robot</li>
              <li className="hover:text-white transition-colors cursor-pointer">Lưu trữ năng lượng ESS</li>
              <li className="hover:text-white transition-colors cursor-pointer">Bộ Sạc & Trạm Sạc</li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono font-bold text-brand-red uppercase tracking-[0.3em] mb-12">Doanh nghiệp</h4>
            <ul className="space-y-5 text-white/40 text-sm font-light">
              <li className="hover:text-white transition-colors cursor-pointer">Về PKG Battery</li>
              <li className="hover:text-white transition-colors cursor-pointer">Năng lực & Chứng chỉ</li>
              <li className="hover:text-white transition-colors cursor-pointer">Tuyển dụng kỹ sư</li>
              <li className="hover:text-white transition-colors cursor-pointer">Chương trình Đại lý</li>
              <li className="hover:text-white transition-colors cursor-pointer">Liên hệ trực tiếp</li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono font-bold text-brand-red uppercase tracking-[0.3em] mb-12">Văn phòng chính</h4>
            <ul className="space-y-6">
              <li className="flex items-start gap-4">
                <MapPin size={18} className="text-brand-red shrink-0" />
                <span className="text-white/40 text-[13px] leading-relaxed font-light">TP. Hồ Chí Minh<br />Khu Công Nghệ Cao, Quận 9</span>
              </li>
              <li className="flex items-start gap-4">
                <MapPin size={18} className="text-brand-red shrink-0" />
                <span className="text-white/40 text-[13px] leading-relaxed font-light">Hà Nội<br />Tòa nhà Enterprise, Cầu Giấy</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center gap-8 text-[10px] font-mono uppercase tracking-[0.2em] text-white/20">
          <p>© 2024 PKG BATTERY. ALL RIGHTS RESERVED.</p>
          <div className="flex gap-10">
            <a href="#" className="hover:text-white/40 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white/40 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white/40 transition-colors">Cookie Policy</a>
          </div>
        </div>
      </Container>
    </footer>
  );
};
