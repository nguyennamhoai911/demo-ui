import { motion } from "motion/react";
import { Container, Button, SectionHeader } from "../UI";

export const About = () => {
  return (
    <section className="py-32 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full industrial-grid opacity-50" />
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div className="relative">
            <div className="grid grid-cols-12 gap-4">
              <div className="col-span-8 aspect-[4/5] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1590986321272-3f1190bc2875?auto=format&fit=crop&q=80&w=1000" 
                  alt="PKG Team" 
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700" 
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="col-span-4 aspect-[2/3] self-end overflow-hidden mt-20">
                <img 
                  src="https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&q=80&w=600" 
                  alt="Industrial Tech" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-brand-red p-8 flex flex-col justify-end text-white">
                <span className="text-4xl font-black mb-2">10+</span>
                <span className="text-[10px] uppercase font-bold tracking-widest leading-tight">Năm kinh nghiệm trong ngành pin Lithium</span>
              </div>
            </div>
          </div>

          <div>
            <SectionHeader 
              eyebrow="About PKG Battery"
              title="Đối tác chiến lược về giải pháp năng lượng Lithium công nghiệp"
              description="PKG Battery được định hướng như một doanh nghiệp B2B chuyên pin lithium công nghiệp, bộ sạc và giải pháp kỹ thuật theo ứng dụng. Chúng tôi không chỉ cung cấp sản phẩm, chúng tôi đồng hành cùng doanh nghiệp trong việc tối ưu hiệu quả vận hành thực tế."
            />
            
            <div className="space-y-8 mb-12">
              <div className="flex gap-6">
                <div className="shrink-0 w-12 h-12 border border-industrial-gray flex items-center justify-center font-bold text-gray-200">01</div>
                <div>
                  <h4 className="font-bold mb-2">Tư duy giải pháp kỹ thuật</h4>
                  <p className="text-sm text-gray-500">Khảo sát và tư vấn cấu hình pin dựa trên bài toán vận hành thật của khách hàng.</p>
                </div>
              </div>
              <div className="flex gap-6">
                <div className="shrink-0 w-12 h-12 border border-industrial-gray flex items-center justify-center font-bold text-gray-200">02</div>
                <div>
                  <h4 className="font-bold mb-2">Năng lực phục vụ đa ngành</h4>
                  <p className="text-sm text-gray-500">Từ Logistics, Sản xuất đến Tự động hóa và Lưu trữ năng lượng tái tạo.</p>
                </div>
              </div>
            </div>

            <Button variant="outline">Tìm hiểu thêm về chúng tôi</Button>
          </div>
        </div>
      </Container>
    </section>
  );
};
