import { motion } from "motion/react";
import { Container, SectionHeader, Button } from "../UI";

export const News = () => {
  const posts = [
    { title: "Giải pháp Pin Lithium thay thế cho xe nâng chì axit: Bài toán ROI thực tế", date: "Apr 2024", cat: "Technical Insight", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=600" },
    { title: "Tối ưu hóa thời gian sạc cho đội xe AGV trong nhà máy 4.0", date: "Mar 2024", cat: "Automation", img: "https://images.unsplash.com/photo-1485081666476-02085c545624?auto=format&fit=crop&q=80&w=600" },
    { title: "PKG Battery đạt chứng chỉ IEC 62619 cho dòng sản phẩm công nghiệp", date: "Feb 2024", cat: "News", img: "https://images.unsplash.com/photo-1542744094-24638eff58bb?auto=format&fit=crop&q=80&w=600" }
  ];

  return (
    <section className="py-32 bg-industrial-gray border-y border-gray-100">
      <Container>
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <SectionHeader 
            eyebrow="Technical Knowledge"
            title="Tin tức & Kiến thức chuyên gia"
            description="Cung cấp các thông tin kỹ thuật chuyên sâu và cập nhật mới nhất từ môi trường năng lượng lithium công nghiệp."
          />
          <Button variant="outline" className="mb-16">Xem tất cả bài viết</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {posts.map((post, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="aspect-video bg-gray-200 mb-8 overflow-hidden relative">
                <img src={post.img} alt={post.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-white text-[9px] font-black uppercase tracking-widest text-brand-red">{post.cat}</span>
                </div>
              </div>
              <p className="text-[10px] font-mono text-gray-400 mb-3 tracking-widest uppercase">{post.date}</p>
              <h3 className="text-xl font-bold leading-[1.3] group-hover:text-brand-red transition-colors mb-4">{post.title}</h3>
              <div className="w-12 h-[1px] bg-gray-300 group-hover:w-20 group-hover:bg-brand-red transition-all" />
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
};
