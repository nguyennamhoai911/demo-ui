import { motion } from "motion/react";
import { Container, SectionHeader, TechLine } from "../UI";
import { MapPin, ShieldCheck, Milestone, Factory } from "lucide-react";

export const CapabilityTheater = () => {
  return (
    <section className="py-32 bg-industrial-gray overflow-hidden">
      <Container>
        {/* Cinematic Metric Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-32">
          {[
            { tag: "Mạng lưới", val: "08+", label: "Đại lý toàn quốc", desc: "Hệ thống phân phối và hỗ trợ kỹ thuật rộng khắp." },
            { tag: "Giải pháp", val: "05", label: "Nhóm giải pháp lõi", desc: "Đáp ứng đa dạng ứng dụng công nghiệp trọng yếu." },
            { tag: "Đối tác", val: "20+", label: "Đơn vị cung ứng & FDI", desc: "Kết nối sâu rộng với các đơn vị hạ tầng." },
            { tag: "OEM/ODM", val: "Active", label: "Custom Solution", desc: "Năng lực tùy biến cấu hình theo yêu cầu riêng." }
          ].map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="relative p-10 bg-white border border-gray-100 hover:border-brand-red/20 transition-all group"
            >
              <span className="text-[9px] font-mono font-bold text-brand-red uppercase tracking-widest mb-6 block">{item.tag}</span>
              <h3 className="text-5xl font-black text-gray-900 mb-2">{item.val}</h3>
              <h5 className="font-bold text-sm mb-4">{item.label}</h5>
              <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
              <div className="absolute bottom-0 left-0 w-0 h-[3px] bg-brand-red group-hover:w-full transition-all duration-700" />
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          {/* Map Section */}
          <div className="lg:col-span-7 bg-white p-12 relative overflow-hidden">
            <TechLine className="opacity-20" />
            <SectionHeader 
              eyebrow="Distribution Network"
              title="Độ phủ vận hành toàn Việt Nam"
              description="Bản đồ đại lý của PKG Battery tập trung tại các trọng điểm Logistics và công nghiệp, đảm bảo tính sẵn sàng tối đa cho khách hàng."
            />
            {/* Stylized Map Visualization Placeholder */}
            <div className="aspect-[4/3] bg-industrial-gray relative flex items-center justify-center overflow-hidden">
               <MapPin className="text-brand-red animate-bounce" size={48} />
               <div className="absolute inset-0 border-[20px] border-white/50" />
               <p className="relative z-10 text-[10px] font-mono font-bold uppercase tracking-widest text-gray-400">Vietnam Market Visualization Layer</p>
               {/* Pulsating Nodes */}
               <div className="absolute top-1/4 left-1/2 w-4 h-4 bg-brand-red rounded-full animate-ping opacity-50" />
               <div className="absolute bottom-1/3 right-1/4 w-3 h-3 bg-brand-red rounded-full animate-ping opacity-30" />
            </div>
          </div>

          {/* Proofs Section */}
          <div className="lg:col-span-5 flex flex-col gap-8">
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: ShieldCheck, title: "ISO 9001:2015", meta: "Quality Standard" },
                { icon: Milestone, title: "IEC Certified", meta: "Safety Standard" }
              ].map((cert, idx) => (
                <div key={idx} className="bg-white border border-gray-100 p-8 flex flex-col items-center text-center group cursor-pointer hover:bg-industrial-gray transition-colors">
                  <cert.icon className="text-brand-red mb-4 opacity-50 group-hover:opacity-100 transition-opacity" size={32} />
                  <h4 className="font-bold text-sm mb-1">{cert.title}</h4>
                  <p className="text-[10px] text-gray-400 uppercase tracking-widest">{cert.meta}</p>
                </div>
              ))}
            </div>

            <div className="flex-grow bg-white p-12 group cursor-pointer relative overflow-hidden">
              <div className="absolute inset-0 bg-gray-900 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1558444479-2753ada76676?auto=format&fit=crop&q=80&w=600" 
                  alt="Production Capability" 
                  className="w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-[2s]"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="relative z-10 h-full flex flex-col justify-end">
                <Factory className="text-brand-red mb-6" size={40} />
                <h4 className="text-white text-3xl font-bold mb-4">Năng lực nhà máy & Đội ngũ</h4>
                <p className="text-white/40 text-sm leading-relaxed">Chúng tôi duy trì hệ thống kiểm tra và test cell nghiêm ngặt trước khi đóng module và triển khai cho khách hàng.</p>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
