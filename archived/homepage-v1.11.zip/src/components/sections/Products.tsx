import { motion } from "motion/react";
import { Container, SectionHeader, Button } from "../UI";
import { Truck, Battery, Cpu, Zap, Database } from "lucide-react";

export const Products = () => {
  const products = [
    {
      id: "forklift",
      title: "Pin Lithium cho Xe Nâng Điện",
      desc: "Giải pháp tối ưu kho vận với khả năng sạc nhanh, giảm bảo trì và hỗ trợ cường độ vận hành 3 ca liên tục.",
      icon: Truck,
      app: "Logistics, Warehousing, FDI Factories"
    },
    {
      id: "tourist",
      title: "Pin Lithium cho Xe Điện Du Lịch",
      desc: "Thiết kế cho buggy và xe golf cần độ ổn định tuyệt đối và tuổi thọ cao trong môi trường resort, khu du lịch.",
      icon: Battery,
      app: "Resorts, Golf Courses, Mobility"
    },
    {
      id: "agv",
      title: "Pin cho Xe AGV / Robot",
      desc: "Năng lượng thông minh cho hệ thống tự động hóa, độ chính xác điện áp cao và tích hợp chuẩn BMS chuyên sâu.",
      icon: Cpu,
      app: "Automated Factories, Smart Logistic"
    },
    {
      id: "charger",
      title: "Bộ Sạc – Trạm Sạc",
      desc: "Hệ thống sạc đồng bộ đa cấu hình giúp rút ngắn thời gian sạc, kéo dài vòng đời cell pin lên mức tối đa.",
      icon: Zap,
      app: "Industrial Hubs, Charging Stations"
    },
    {
      id: "ess",
      title: "Hệ thống Lưu Trữ Năng Lượng ESS",
      desc: "Giải pháp UPS quy mô lớn và lưu trữ năng lượng tái tạo, tăng tính chủ động nguồn điện cho doanh nghiệp.",
      icon: Database,
      app: "Factories, Renewable Projects, Microgrids"
    }
  ];

  return (
    <section className="py-32 bg-white relative">
      <Container>
        <SectionHeader 
          eyebrow="Key Offerings"
          title="Sản phẩm & Giải pháp chiến lược"
          description="PKG Battery tập trung vào những dòng sản phẩm lõi có hiệu suất cao, tương thích hoàn toàn với các hạ tầng công nghiệp hiện đại."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {products.map((product, idx) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -12 }}
              className="group relative bg-industrial-gray p-10 border border-transparent hover:border-brand-red/20 transition-all duration-500 overflow-hidden"
            >
              <div className="relative z-10">
                <div className="w-16 h-16 bg-white flex items-center justify-center text-brand-red mb-8 border border-gray-100 group-hover:bg-brand-red group-hover:text-white transition-all duration-500">
                  <product.icon size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-4 leading-tight group-hover:text-brand-red transition-colors">{product.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-8">{product.desc}</p>
                <div className="flex flex-col gap-2 mb-10">
                  <span className="text-[10px] font-mono font-bold uppercase text-gray-400 tracking-widest">Applications:</span>
                  <span className="text-xs font-semibold text-deep-black">{product.app}</span>
                </div>
                <button className="flex items-center gap-3 text-[11px] font-black uppercase tracking-[0.2em] text-deep-black group-hover:text-brand-red transition-colors">
                  <span>Khám phá giải pháp</span>
                  <div className="w-6 h-[1px] bg-deep-black group-hover:bg-brand-red transition-colors" />
                </button>
              </div>

              {/* Background watermark */}
              <div className="absolute top-[-20px] right-[-20px] w-48 h-48 opacity-[0.03] group-hover:opacity-[0.06] grayscale pointer-events-none transition-all duration-1000 rotate-12">
                <product.icon size={192} />
              </div>
            </motion.div>
          ))}
          
          {/* Showcase Project Card */}
          <div className="bg-deep-black p-10 flex flex-col justify-between group overflow-hidden relative">
            <div className="absolute inset-0 dark-industrial-grid opacity-20" />
            <div className="relative z-10">
              <SectionHeader 
                dark
                title="Tận tâm cho từng yêu cầu kỹ thuật đặc thù"
              />
            </div>
            <div className="relative z-10 mt-auto">
              <Button variant="white" className="w-full justify-between">Gửi yêu cầu cấu hình riêng</Button>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
