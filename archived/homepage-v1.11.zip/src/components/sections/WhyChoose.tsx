import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";
import { CheckCircle2 } from "lucide-react";

export const WhyChoose = () => {
  const USP = [
    { title: "Thiết kế đo ni đóng giày", desc: "Giải pháp không rập khuôn, được tinh chỉnh theo chính xác cơ sở hạ tầng của doanh nghiệp bạn." },
    { title: "Năng lực tích hợp cao", desc: "Am hiểu sâu về hệ thống điện, BMS và các giao thức kết nối công nghiệp hiện đại." },
    { title: "Tối ưu hóa chi phí dài hạn", desc: "Đảm bảo uptime tối đa, giảm thiểu bảo trì và kéo dài thời gian hoàn vốn đầu tư (ROI)." },
    { title: "Phục vụ quy mô doanh nghiệp", desc: "Quy trình làm việc chuyên nghiệp, sẵn sàng đáp ứng yêu cầu từ các tập đoàn và đơn vị FDI." }
  ];

  return (
    <section className="py-32 bg-white relative">
      <div className="absolute right-0 top-0 w-2/3 h-full industrial-grid opacity-30" />
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-center">
          <div className="lg:col-span-5">
            <SectionHeader 
              eyebrow="Value Proposition"
              title="Tại sao doanh nghiệp chọn PKG Battery?"
              description="Chúng tôi bước vào bài toán năng lượng của bạn bằng tư duy của một chuyên gia giải pháp, không phải tư duy của một người bán hàng thương mại."
            />
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16 relative z-10">
            {USP.map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="group"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-8 h-8 rounded-full bg-brand-red flex items-center justify-center text-white">
                    <CheckCircle2 size={16} />
                  </div>
                  <h4 className="text-xl font-bold tracking-tight">{item.title}</h4>
                </div>
                <p className="text-gray-500 text-sm leading-relaxed pl-12">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
};
