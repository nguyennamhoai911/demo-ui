import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";

export const Process = () => {
  const steps = [
    { title: "Khảo sát thực địa", desc: "Đánh giá môi trường vận hành và cấu hình thiết bị hiện tại." },
    { title: "Phân tích & Đề xuất", desc: "Đề xuất cấu hình Pin & Sạc tối ưu nhất cho hiệu suất ca làm việc." },
    { title: "Sản xuất & Tùy chỉnh", desc: "Lắp ráp module và tùy chỉnh phần mềm BMS theo yêu cầu." },
    { title: "Triển khai & Training", desc: "Lắp đặt tại chỗ và hướng dẫn đội ngũ kỹ thuật vận hành đúng cách." },
    { title: "Đồng hành Hậu mãi", desc: "Bảo trì định kỳ và hỗ trợ kỹ thuật 24/7 suốt vòng đời sản phẩm." }
  ];

  return (
    <section className="py-32 bg-white overflow-hidden">
      <Container>
        <SectionHeader 
          centered
          eyebrow="Workflow"
          title="Quy trình tư vấn và triển khai minh bạch"
          description="Chúng tôi tối giản hóa sự phức tạp để đảm bảo quá trình chuyển đổi sang pin lithium của bạn diễn ra mượt mà nhất."
        />

        <div className="relative mt-24">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-12 relative z-10">
            {steps.map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="group relative"
              >
                <div className="text-6xl font-black text-industrial-gray group-hover:text-brand-red/10 transition-colors mb-6 leading-none tracking-tighter">0{idx + 1}</div>
                <h4 className="font-bold text-lg mb-4 text-deep-black tracking-tight">{step.title}</h4>
                <p className="text-xs text-gray-400 leading-relaxed">{step.desc}</p>
              </motion.div>
            ))}
          </div>
          {/* Subtle Progress Line */}
          <div className="hidden lg:block absolute bottom-[-40px] left-0 w-full h-[1px] bg-gray-100">
            <motion.div 
              initial={{ width: 0 }}
              whileInView={{ width: "100%" }}
              transition={{ duration: 2, ease: "easeInOut" }}
              className="h-full bg-brand-red opacity-30"
            />
          </div>
        </div>
      </Container>
    </section>
  );
};
