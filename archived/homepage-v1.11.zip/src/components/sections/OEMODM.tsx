import { motion } from "motion/react";
import { Container, SectionHeader, Button } from "../UI";
import { Settings, Cpu, Layers, Activity } from "lucide-react";

export const OEMODM = () => {
  return (
    <section className="py-32 red-statement-gradient relative overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 dark-industrial-grid opacity-20" />
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-black/20 to-transparent" />
      
      {/* Technical Linework Overlay */}
      <svg className="absolute inset-0 w-full h-full opacity-10" pointerEvents="none">
        <pattern id="technicalPattern" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1" fill="white" />
          <path d="M0 50 L100 50 M50 0 L50 100" stroke="white" strokeWidth="0.5" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#technicalPattern)" />
      </svg>

      <Container className="relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div>
            <SectionHeader 
              dark
              eyebrow="Tùy chỉnh & Sản xuất"
              title="OEM / ODM và giải pháp tùy chỉnh kỹ thuật sâu"
              description="PKG Battery không chỉ bán pin có sẵn. Chúng tôi hướng tới khả năng đồng sáng tạo cùng các đối tác kỹ thuật để xây dựng cấu hình pin lithium hoàn hảo nhất cho từng thiết bị đặc thù."
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
              {[
                { icon: Layers, title: "Form factor linh hoạt", desc: "Tối ưu hóa kích thước theo hộc chứa đặc thù của thiết bị." },
                { icon: Settings, title: "Cấu hình điện áp", desc: "Từ 12V đến 600V+, đáp ứng mọi tải trọng vận hành nhà máy." },
                { icon: Cpu, title: "Tích hợp IoT/BMS", desc: "Giao thức CANbus, RS485 tùy chỉnh theo hệ thống quản lý có sẵn." },
                { icon: Activity, title: "Hỗ trợ R&D", desc: "Đồng hành cùng doanh nghiệp từ bản vẽ đến mẫu thử nghiệm." }
              ].map((item, idx) => (
                <div key={idx} className="group">
                  <div className="flex items-center gap-4 mb-3">
                    <item.icon size={20} className="text-white opacity-60 group-hover:opacity-100 transition-opacity" />
                    <h4 className="text-white font-bold text-sm tracking-tight">{item.title}</h4>
                  </div>
                  <p className="text-white/50 text-xs leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-6 border-t border-white/10 pt-12">
              <Button variant="white" className="h-16 px-10">Trao đổi về OEM / ODM</Button>
              <Button variant="outline" className="h-16 px-10 border-white/20 text-white hover:bg-white hover:text-brand-red">Gửi yêu cầu dự án</Button>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square bg-black/20 backdrop-blur-3xl rounded-sm p-12 border border-white/5">
              {/* Technical Drawing Effect */}
              <div className="w-full h-full border border-white/10 relative overflow-hidden group">
                <img 
                  src="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1000" 
                  alt="High Tech Production" 
                  className="w-full h-full object-cover opacity-30 group-hover:scale-110 transition-transform duration-[2s]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 p-8 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-mono text-white/40 tracking-[0.3em]">PROTOTYPE_v0.2</span>
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-brand-red rounded-full animate-pulse" />
                      <div className="w-1.5 h-1.5 bg-white/20 rounded-full" />
                    </div>
                  </div>
                  <div className="py-4 border-l-2 border-brand-red pl-6">
                    <h5 className="text-white font-bold mb-1">Thiết kế module tích hợp</h5>
                    <p className="text-white/40 text-[10px] leading-relaxed uppercase tracking-widest">Efficiency: 99.8% / Density: Max</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Subtle glow behind card */}
            <div className="absolute -inset-10 bg-brand-red/20 blur-[100px] rounded-full pointer-events-none -z-10" />
          </div>
        </div>
      </Container>
    </section>
  );
};
