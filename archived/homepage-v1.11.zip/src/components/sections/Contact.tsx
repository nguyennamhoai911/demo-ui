import { motion } from "motion/react";
import { Container, Button, TechLine } from "../UI";
import { Phone, Mail } from "lucide-react";

export const Contact = () => {
  return (
    <section className="py-32 bg-white relative">
      <Container>
        <div className="bg-deep-black rounded-sm p-12 lg:p-24 overflow-hidden relative">
          <div className="absolute inset-0 dark-industrial-grid opacity-10 pointer-events-none" />
          <TechLine className="top-10 opacity-30" />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 relative z-10">
            <div>
              <div className="flex items-center gap-3 mb-8">
                <div className="h-[1px] w-8 bg-brand-red" />
                <span className="text-[10px] font-mono tracking-[0.4em] uppercase text-brand-red font-bold">CONTACT & CONSULTANCY</span>
              </div>
              <h2 className="text-4xl md:text-6xl font-black text-white leading-[1.05] tracking-tight mb-10">
                Chuyển đổi <span className="text-gradient-red text-brand-red">vận hành</span> bằng năng lượng Lithium ngay hôm nay
              </h2>
              <p className="text-white/50 text-lg font-light leading-relaxed mb-12">
                Trao đổi với đội ngũ kỹ sư PKG Battery để khảo sát môi trường thực tế, 
                đề xuất cấu hình pin tối ưu và lộ trình triển khai mượt mà nhất cho doanh nghiệp của bạn.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12 border-t border-white/5 pt-12">
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="w-14 h-14 bg-white/5 border border-white/10 flex items-center justify-center text-brand-red group-hover:bg-brand-red group-hover:text-white transition-all">
                    <Phone size={24} />
                  </div>
                  <div>
                    <label className="text-[9px] uppercase font-bold text-white/30 tracking-widest block mb-1">Hotline tư vấn</label>
                    <span className="text-white font-bold text-xl">090X XXX XXX</span>
                  </div>
                </div>
                <div className="flex items-center gap-6 group cursor-pointer">
                  <div className="w-14 h-14 bg-white/5 border border-white/10 flex items-center justify-center text-brand-red group-hover:bg-brand-red group-hover:text-white transition-all">
                    <Mail size={24} />
                  </div>
                  <div>
                    <label className="text-[9px] uppercase font-bold text-white/30 tracking-widest block mb-1">Email liên kết</label>
                    <span className="text-white font-bold text-lg">info@pkgbattery.vn</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-10 lg:p-16 shadow-2xl relative">
              <div className="absolute top-0 right-0 w-20 h-2 bg-brand-red" />
              <h3 className="text-2xl font-bold text-deep-black mb-10 tracking-tight">Gửi yêu cầu giải pháp</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <input type="text" placeholder="Họ tên" className="w-full px-6 py-5 bg-industrial-gray border-none focus:ring-1 focus:ring-brand-red outline-none text-sm" />
                  <input type="text" placeholder="Số điện thoại" className="w-full px-6 py-5 bg-industrial-gray border-none focus:ring-1 focus:ring-brand-red outline-none text-sm" />
                </div>
                <input type="text" placeholder="Công ty / Doanh nghiệp" className="w-full px-6 py-5 bg-industrial-gray border-none focus:ring-1 focus:ring-brand-red outline-none text-sm" />
                <select className="w-full px-6 py-5 bg-industrial-gray border-none focus:ring-1 focus:ring-brand-red outline-none text-sm appearance-none text-gray-500">
                  <option value="">Ứng dụng thực tế quan tâm</option>
                  <option value="logistics">Xe nâng / Kho vận</option>
                  <option value="automation">AGV / Robot</option>
                  <option value="ess">Lưu trữ năng lượng</option>
                  <option value="resort">Khu du lịch / Buggy</option>
                  <option value="oem">Yêu cầu OEM / ODM</option>
                </select>
                <textarea rows={4} placeholder="Mô tả bài toán vận hành (Không bắt buộc)" className="w-full px-6 py-5 bg-industrial-gray border-none focus:ring-1 focus:ring-brand-red outline-none text-sm resize-none"></textarea>
                <Button className="w-full !px-0 bg-brand-red text-white py-6 h-auto tracking-[0.2em]">Khởi động dự án tư vấn</Button>
              </form>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
