import { motion } from "motion/react";
import { Zap, ChevronRight } from "lucide-react";
import { Button, Container, TechLine } from "../UI";

export const Hero = () => {
  return (
    <section className="relative min-h-screen bg-deep-black flex items-center pt-20 overflow-hidden">
      {/* Background System */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2070" 
          alt="Industrial Automation" 
          className="w-full h-full object-cover opacity-30 grayscale saturate-50"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-deep-black via-deep-black/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-deep-black via-transparent to-transparent" />
        <div className="absolute inset-0 dark-industrial-grid opacity-20" />
      </div>

      <TechLine className="top-1/3 opacity-30" />

      <Container className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
        <div className="lg:col-span-8">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="h-[1px] w-12 bg-brand-red" />
              <span className="text-[10px] font-mono tracking-[0.4em] uppercase text-brand-red font-bold">GIẢI PHÁP PIN LITHIUM CÔNG NGHIỆP</span>
            </div>
            
            <h1 className="text-5xl md:text-8xl font-black text-white leading-[1.05] tracking-tighter mb-10">
              Đối tác pin lithium & sạc <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-red via-brand-red to-white">toàn diện</span> cho doanh nghiệp
            </h1>

            <p className="text-xl text-white/50 max-w-2xl leading-relaxed font-light mb-12">
              Hệ sinh thái pin – sạc – giải pháp kỹ thuật giúp doanh nghiệp vận hành ổn định, 
              giảm downtime và tối ưu chi phí sở hữu dài hạn (TCO) trong môi trường công nghiệp khắc nghiệt.
            </p>

            <div className="flex flex-wrap gap-6">
              <Button variant="primary" className="h-20 px-12 group">
                Nhận tư vấn kỹ thuật
              </Button>
              <Button variant="outline" className="h-20 px-12 border-white/20 text-white hover:bg-white hover:text-deep-black" showIcon={false}>
                Xem nhóm giải pháp
              </Button>
            </div>
          </motion.div>
        </div>

        <div className="lg:col-span-4 self-end pb-20">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="flex flex-col gap-6"
          >
            <div className="glass-card p-8 group cursor-pointer transition-all hover:bg-brand-red/10 border-l-4 border-brand-red">
              <div className="flex justify-between items-start mb-4">
                <Zap className="text-brand-red" size={24} />
                <ChevronRight className="text-white/20 group-hover:text-brand-red transition-colors" size={20} />
              </div>
              <h4 className="text-white text-lg font-bold mb-2">OEM / ODM Available</h4>
              <p className="text-white/40 text-xs leading-relaxed">Hỗ trợ tùy chỉnh cấu hình theo yêu cầu kỹ thuật đặc thù cho doanh nghiệp nội địa và FDI.</p>
            </div>

            <div className="glass-card p-8 group cursor-pointer transition-all hover:bg-white/5 border-l-4 border-white/10">
              <h4 className="text-white text-lg font-bold mb-2">8+ Đại lý toàn quốc</h4>
              <p className="text-white/40 text-xs leading-relaxed">Hệ thống phân phối và trạm hỗ trợ kỹ thuật phủ rộng tại các trọng điểm Logistics & Nhà máy.</p>
            </div>
          </motion.div>
        </div>
      </Container>

      {/* Hero Visual Element */}
      <div className="absolute right-[-10%] bottom-[-10%] w-2/3 h-2/3 z-[1] opacity-20 pointer-events-none">
        <svg viewBox="0 0 500 500" className="w-full h-full text-brand-red">
          <circle cx="250" cy="250" r="200" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="10 20" />
          <circle cx="250" cy="250" r="150" fill="none" stroke="currentColor" strokeWidth="0.2" />
        </svg>
      </div>
    </section>
  );
};
