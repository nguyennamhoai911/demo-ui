import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";

export const CaseStudy = () => {
  const cases = [
    { client: "Logistics FDI Group", target: "Đội xe nâng 50 chiếc", result: "Giảm 30% chi phí vận hành sau 1 năm", img: "https://images.unsplash.com/photo-1512411996500-1123ce3e0315?auto=format&fit=crop&q=80&w=600" },
    { client: "Automotive Factory", target: "Hệ thống AGV tự động", result: "Hoàn vốn đầu tư (ROI) trong 18 tháng", img: "https://images.unsplash.com/photo-1590986064295-e23f81e35ca7?auto=format&fit=crop&q=80&w=600" }
  ];

  return (
    <section className="py-32 bg-white overflow-hidden">
      <Container>
        <SectionHeader 
          centered
          eyebrow="Application Proof"
          title="Thực chứng từ các dự án tiêu biểu"
          description="Chúng tôi bước vào bài toán vận hành của khách hàng và để lại những con số biết nói về hiệu năng và sự bền bỉ."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-20">
          {cases.map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, scale: 0.98 }}
              whileInView={{ opacity: 1, scale: 1 }}
              className="relative aspect-video group overflow-hidden cursor-pointer bg-gray-900"
            >
              <img src={item.img} alt={item.client} className="absolute inset-0 w-full h-full object-cover opacity-50 grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-105" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-deep-black via-transparent to-transparent opacity-80" />
              <div className="absolute inset-0 p-12 flex flex-col justify-end">
                <span className="text-[10px] font-mono text-brand-red uppercase font-black tracking-widest mb-4">Case Study 0{idx + 1}</span>
                <h4 className="text-white text-3xl font-bold mb-4 leading-tight group-hover:text-brand-red transition-colors">{item.client}</h4>
                <div className="flex gap-12 border-t border-white/10 pt-8">
                  <div>
                    <p className="text-white/40 text-[9px] uppercase font-bold tracking-widest mb-1">Mục tiêu</p>
                    <p className="text-white text-xs font-medium">{item.target}</p>
                  </div>
                  <div>
                    <p className="text-white/40 text-[9px] uppercase font-bold tracking-widest mb-1">Kết quả</p>
                    <p className="text-brand-red text-xs font-black">{item.result}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
};
