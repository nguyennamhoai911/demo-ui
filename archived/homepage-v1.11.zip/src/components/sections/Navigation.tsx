import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Globe } from 'lucide-react';
import { Button, Container } from '../UI';

export const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Giải pháp', href: '#' },
    { name: 'Sản phẩm', href: '#' },
    { name: 'Ứng dụng', href: '#' },
    { name: 'OEM / ODM', href: '#' },
    { name: 'Về PKG Battery', href: '#' },
    { name: 'Đại lý', href: '#' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-[100] transition-all duration-500 ${isScrolled ? 'bg-white py-4 shadow-sm' : 'bg-transparent py-8'}`}>
      <Container className="flex items-center justify-between">
        <a href="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 bg-brand-red flex items-center justify-center font-bold text-white italic transition-transform group-hover:rotate-12">PKG</div>
          <div className="flex flex-col">
            <span className={`text-xl font-black tracking-tighter leading-none ${isScrolled ? 'text-deep-black' : 'text-white'}`}>BATTERY</span>
            <span className={`text-[8px] font-mono tracking-[0.3em] font-medium ${isScrolled ? 'text-gray-400' : 'text-white/40'}`}>INDUSTRIAL ENERGY</span>
          </div>
        </a>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center gap-10">
          {menuItems.map((item) => (
            <a 
              key={item.name} 
              href={item.href} 
              className={`text-[11px] font-bold uppercase tracking-widest transition-colors hover:text-brand-red ${isScrolled ? 'text-deep-black' : 'text-white'}`}
            >
              {item.name}
            </a>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-6">
          <button className={`flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest ${isScrolled ? 'text-deep-black' : 'text-white'}`}>
            <Globe size={14} className="text-brand-red" />
            <span>VI / EN</span>
          </button>
          <Button variant={isScrolled ? 'primary' : 'white'} className="py-3 px-6 text-[10px]">
            Nhận tư vấn kỹ thuật
          </Button>
        </div>

        {/* Mobile Toggle */}
        <button className="lg:hidden text-brand-red" onClick={() => setIsMobileOpen(!isMobileOpen)}>
          {isMobileOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </Container>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 bg-white z-[90] lg:hidden flex flex-col p-12"
          >
            <div className="flex flex-col gap-8 mt-12">
              {menuItems.map((item, idx) => (
                <motion.a 
                  key={item.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  href={item.href}
                  className="text-4xl font-bold tracking-tighter text-deep-black"
                  onClick={() => setIsMobileOpen(false)}
                >
                  {item.name}
                </motion.a>
              ))}
            </div>
            <div className="mt-auto">
              <Button className="w-full py-6">Nhận tư vấn kỹ thuật</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
