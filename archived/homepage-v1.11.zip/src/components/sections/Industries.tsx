import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";

export const Industries = () => {
  const industries = [
    { title: "Logistics & Kho vận", img: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1000" },
    { title: "Nhà máy & Sản xuất", img: "https://images.unsplash.com/photo-1565608438257-fac3c27beb36?auto=format&fit=crop&q=80&w=1000" },
    { title: "AGV / Robot tự động", img: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=1000" },
    { title: "Resort & Khu du lịch", img: "https://images.unsplash.com/photo-1540333563391-645511093153?auto=format&fit=crop&q=80&w=1000" },
    { title: "Khu công nghiệp", img: "https://images.unsplash.com/photo-1554469384-e58fac16e23a?auto=format&fit=crop&q=80&w=1000" },
    { title: "Lưu trữ ESS", img: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=1000" }
  ];

  return (
    <section className="py-32 bg-white overflow-hidden">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-end mb-16">
          <div className="lg:col-span-8">
            <SectionHeader 
              eyebrow="Target Industries"
              title="Giải pháp cho nhiều bối cảnh vận hành công nghiệp trọng yếu"
              description="Năng lực của PKG Battery được thực chứng trong các môi trường vận hành từ Logistics quy mô lớn đến các chuỗi resort cao cấp nhất."
            />
          </div>
          <div className="lg:col-span-4 lg:text-right pb-16">
            <p className="text-xs font-mono font-black uppercase text-gray-400 tracking-[0.2em]">6+ Primary Sectors</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-6 gap-2">
          {industries.map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ scale: 0.98 }}
              className="relative aspect-[3/4] overflow-hidden group cursor-pointer"
            >
              <img src={item.img} alt={item.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-110" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-deep-black via-transparent to-transparent opacity-80" />
              <div className="absolute inset-0 p-6 flex flex-col justify-end">
                <h4 className="text-white text-xs font-black uppercase tracking-widest leading-tight group-hover:text-brand-red transition-colors">{item.title}</h4>
              </div>
            </motion.div>
          ))}
        </div>
      </Container>
    </section>
  );
};
