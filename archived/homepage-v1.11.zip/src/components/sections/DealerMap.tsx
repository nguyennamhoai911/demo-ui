import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";
import { MapPin, Phone, Mail } from "lucide-react";

export const DealerMap = () => {
  const dealers = [
    { city: "Hà Nội", name: "Đại lý PKG Miền Bắc 01", location: "KCN Quang Minh, Mê Linh" },
    { city: "Bắc Ninh", name: "Đại lý PKG Miền Bắc 02", location: "KCN Quế Võ" },
    { city: "Đà Nẵng", name: "Đại lý PKG Miền Trung", location: "KCN Hòa Khánh" },
    { city: "TP. Hồ Chí Minh", name: "Trung tâm Giải pháp Miền Nam", location: "Quận 12, TP.HCM" },
    { city: "Bình Dương", name: "Đại lý PKG Bình Dương", location: "KCN VSIP II" }
  ];

  return (
    <section className="py-32 bg-white relative">
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
          <div className="bg-industrial-gray p-12 lg:p-20 relative">
            <SectionHeader 
              eyebrow="Network Presence"
              title="Hiện diện tại các trọng điểm công nghiệp"
              description="Hệ thống 8 đại lý phủ rộng giúp PKG Battery rút ngắn thời gian đáp ứng yêu cầu kỹ thuật và bảo hành."
            />
            
            <div className="flex flex-col gap-6">
              {dealers.map((dealer, idx) => (
                <div key={idx} className="group cursor-pointer border-b border-gray-200 pb-6 hover:translate-x-2 transition-transform">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-bold text-lg text-deep-black group-hover:text-brand-red transition-colors">{dealer.city}</h4>
                    <MapPin size={18} className="text-gray-300 group-hover:text-brand-red" />
                  </div>
                  <p className="text-xs text-gray-500 font-medium mb-1 uppercase tracking-wider">{dealer.name}</p>
                  <p className="text-xs text-gray-400">{dealer.location}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-12">
            <div className="aspect-square bg-gray-100 flex items-center justify-center relative overflow-hidden group">
               <div className="absolute inset-0 bg-gray-200 opacity-20 pointer-events-none industrial-grid" />
               <MapPin size={120} className="text-brand-red opacity-10 group-hover:opacity-20 transition-opacity" />
               <p className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-[0.4em] rotate-90 absolute right-0">Geographical Presence</p>
            </div>
            
            <div className="p-12 border border-industrial-gray">
              <h4 className="font-bold text-xl mb-6 tracking-tight leading-tight">Bạn muốn trở thành đối tác đại lý?</h4>
              <p className="text-sm text-gray-500 mb-10 leading-relaxed">PKG Battery luôn mở rộng mạng lưới phân phối và hỗ trợ kỹ thuật tại các tỉnh thành phát triển khu công nghiệp.</p>
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-4">
                  <Phone size={18} className="text-brand-red" />
                  <span className="font-bold text-deep-black">090X XXX XXX</span>
                </div>
                <div className="flex items-center gap-4">
                  <Mail size={18} className="text-brand-red" />
                  <span className="font-bold text-deep-black">dealer@pkgbattery.vn</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
