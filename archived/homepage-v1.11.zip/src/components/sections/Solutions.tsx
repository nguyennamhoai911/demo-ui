import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";
import { Search, Settings, Cpu, LineChart, ShieldCheck } from "lucide-react";

export const Solutions = () => {
  const steps = [
    { icon: Search, title: "Đánh giá nhu cầu", desc: "Khảo sát thực tế cường độ, môi trường và thiết bị hiện có." },
    { icon: Settings, title: "Cấu hình Pin & Sạc", desc: "Đề xuất dung lượng và phương án sạc giúp tối ưu downtime." },
    { icon: Cpu, title: "Tùy chỉnh kỹ thuật", desc: "Thiết kế module và tích hợp hệ thống quản lý năng lượng." },
    { icon: ShieldCheck, title: "Triển khai & Backup", desc: "Lắp đặt, hướng dẫn vận hành và kích hoạt bảo trì chủ động." }
  ];

  return (
    <section className="py-32 bg-industrial-gray overflow-hidden">
      <Container>
        <SectionHeader 
          centered
          eyebrow="Comprehensive Solutions"
          title="Từ pin đến giải pháp vận hành hoàn chỉnh"
          description="PKG Battery xây dựng giải pháp pin lithium công nghiệp theo bài toán thực tế của doanh nghiệp — không chỉ là cấp hàng, mà là đồng hành vận hành bền bỉ."
        />

        <div className="relative mt-24">
          {/* Connector Line (Desktop) */}
          <div className="hidden lg:block absolute top-[60px] left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-gray-300 to-transparent z-0" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 relative z-10">
            {steps.map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="text-center group"
              >
                <div className="w-[120px] h-[120px] bg-white rounded-full mx-auto flex items-center justify-center mb-8 shadow-sm group-hover:shadow-xl transition-all border border-gray-100 group-hover:border-brand-red/30">
                  <step.icon size={40} className="text-gray-900 group-hover:text-brand-red transition-colors" />
                </div>
                <h4 className="font-bold text-lg mb-4 text-deep-black tracking-tight">{step.title}</h4>
                <p className="text-sm text-gray-500 leading-relaxed px-4">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="mt-24 p-12 bg-white border border-gray-100 flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex items-center gap-8">
            <LineChart size={48} className="text-brand-red opacity-20" />
            <div>
              <h4 className="font-bold text-xl mb-2">Tư duy tối ưu hóa hạ tầng</h4>
              <p className="text-sm text-gray-500 italic">"Chúng tôi đo lường hiệu quả bằng thời gian hệ thống của bạn hoạt động mỗi ngày."</p>
            </div>
          </div>
          <div className="h-[1px] lg:h-12 w-full lg:w-[1px] bg-gray-200" />
          <div className="flex gap-4">
            <div className="text-center">
              <span className="block text-2xl font-black text-brand-red leading-none mb-1">-40%</span>
              <span className="text-[9px] uppercase font-bold tracking-widest text-gray-400">Chi phí bảo trì</span>
            </div>
            <div className="w-[1px] h-10 bg-gray-100" />
            <div className="text-center">
              <span className="block text-2xl font-black text-brand-red leading-none mb-1">+60%</span>
              <span className="text-[9px] uppercase font-bold tracking-widest text-gray-400">Hiệu suất sạc</span>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
};
