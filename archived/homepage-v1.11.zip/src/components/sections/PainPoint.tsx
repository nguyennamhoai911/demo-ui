import { motion } from "motion/react";
import { Container, SectionHeader } from "../UI";
import { AlertCircle, Clock, Zap, Wrench } from "lucide-react";

export const PainPoint = () => {
  const pains = [
    { 
      icon: Clock, 
      title: "Thời gian sạc dài", 
      desc: "Làm gián đoạn chu kỳ vận hành ca kíp, buộc doanh nghiệp phải dự phòng quá nhiều thiết bị." 
    },
    { 
      icon: AlertCircle, 
      title: "Downtime đột ngột", 
      desc: "Pin xuống cấp không cảnh báo gây dừng chuyền, ảnh hưởng trực tiếp đến năng suất kho vận." 
    },
    { 
      icon: Wrench, 
      title: "Chi phí bảo trì cao", 
      desc: "Việc châm nước, vệ sinh và thay thế pin chì truyền thống tiêu tốn nguồn lực vận hành đáng kể." 
    },
    { 
      icon: Zap, 
      title: "Hiệu suất sụt giảm", 
      desc: "Năng lượng không ổn định làm giảm tuổi thọ động cơ xe nâng và các thiết bị tự động hóa." 
    }
  ];

  return (
    <section className="py-32 bg-deep-black relative overflow-hidden">
      <div className="absolute inset-0 dark-industrial-grid opacity-10" />
      <Container>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <SectionHeader 
            dark
            eyebrow="Operational Challenges"
            title="Downtime và chi phí ẩn đang làm doanh nghiệp kém hiệu quả"
            description="Khi hệ thống pin không phù hợp với cường độ vận hành, doanh nghiệp không chỉ mất điện năng mà còn mất thời gian, năng suất và khả năng kiểm soát TCO dài hạn."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {pains.map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 bg-white/5 border border-white/10 hover:border-brand-red/30 transition-all group"
              >
                <div className="w-12 h-12 bg-brand-red/10 flex items-center justify-center text-brand-red mb-6 border border-brand-red/20 group-hover:bg-brand-red group-hover:text-white transition-colors">
                  <item.icon size={24} />
                </div>
                <h4 className="text-white text-lg font-bold mb-4">{item.title}</h4>
                <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
};
