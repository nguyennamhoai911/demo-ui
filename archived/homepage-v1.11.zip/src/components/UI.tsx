import { motion } from "motion/react";
import { ReactNode } from "react";
import { ArrowRight } from "lucide-react";

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'white';
  className?: string;
  onClick?: () => void;
  showIcon?: boolean;
}

export const Button = ({ children, variant = 'primary', className = "", onClick, showIcon = true }: ButtonProps) => {
  const variants = {
    primary: "bg-brand-red text-white hover:bg-brand-red-dark",
    secondary: "bg-deep-black text-white hover:bg-black/80",
    outline: "bg-transparent border border-deep-black text-deep-black hover:bg-deep-black hover:text-white",
    white: "bg-white text-deep-black hover:bg-white/90"
  };

  return (
    <motion.button 
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.98 }}
      className={`relative inline-flex items-center gap-3 px-10 py-5 font-semibold text-sm tracking-widest uppercase transition-all duration-300 ${variants[variant]} ${className}`}
      onClick={onClick}
    >
      <span className="relative z-10">{children}</span>
      {showIcon && <ArrowRight size={16} className="relative z-10" />}
    </motion.button>
  );
};

export const Container = ({ children, className = "" }: { children: ReactNode, className?: string }) => (
  <div className={`max-w-7xl mx-auto px-6 lg:px-12 ${className}`}>{children}</div>
);

export const SectionLabel = ({ children, dark = false }: { children: ReactNode, dark?: boolean }) => (
  <motion.span 
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    className={`section-label ${dark ? 'text-white/40' : ''}`}
  >
    {children}
  </motion.span>
);

export const TechLine = ({ className = "" }: { className?: string }) => (
  <svg className={`absolute pointer-events-none ${className}`} width="100%" height="200" viewBox="0 0 1000 200">
    <motion.path 
      d="M0 100 L200 100 L250 150 L400 150 L450 50 L600 50 L650 100 L1000 100" 
      fill="none" 
      stroke="url(#lineGradient)" 
      strokeWidth="1"
      className="energy-line-flow"
    />
    <defs>
      <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="transparent" />
        <stop offset="50%" stopColor="#E31E24" />
        <stop offset="100%" stopColor="transparent" />
      </linearGradient>
    </defs>
  </svg>
);

export const SectionHeader = ({ eyebrow, title, description, dark = false, centered = false }: {
  eyebrow?: string;
  title: string;
  description?: string;
  dark?: boolean;
  centered?: boolean;
}) => (
  <div className={`max-w-4xl mb-16 ${centered ? 'mx-auto text-center' : ''}`}>
    {eyebrow && <SectionLabel dark={dark}>{eyebrow}</SectionLabel>}
    <motion.h2 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className={`editorial-headline ${dark ? 'text-white' : 'text-deep-black'}`}
    >
      {title}
    </motion.h2>
    {description && (
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className={`text-lg leading-relaxed max-w-2xl ${centered ? 'mx-auto' : ''} ${dark ? 'text-white/60' : 'text-gray-600'}`}
      >
        {description}
      </motion.p>
    )}
  </div>
);
